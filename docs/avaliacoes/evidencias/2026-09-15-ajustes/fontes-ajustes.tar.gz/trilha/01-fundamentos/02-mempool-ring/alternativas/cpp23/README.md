# Alternativa — o mesmo problema em C++23 puro

> **Uso dos números históricos.** Os tempos e razões transcritos nesta página
> são registros didáticos das configurações descritas. Sem cadeia de coleta
> identificada, não sustentam previsão de desempenho nem escolha quantitativa
> da versão atual. Consulte o [inventário de dados](../../../../../docs/avaliacoes/inventario-dados.md)
> para distinguir registros históricos, cálculos e campanhas rastreáveis.

> Alternativa ao [tópico 02](../../) · Objetivo: tornar explícitos os **ganhos e
> as perdas** de cada abordagem, com o mesmo contrato verificado nas duas.

> **In English.** Independent comparisons of an in-memory pipeline, a local
> ring cycle and concurrent allocation. C++23 costs less in the pipeline;
> DPDK structures cost less in other measured protocols. The ring comparison
> uses one thread, not cross-core transfer. Physical-network results remain
> pending. Ratios apply to the stated workloads and configurations.

## 1. Fundamento: o que "C++23 puro" significa aqui

Uma confusão comum precisa ser desfeita antes de qualquer comparação:

> **"DPDK versus C++" é uma falsa oposição.** Programas DPDK *são* escritos em C
> e C++. A API do DPDK é C, chamável de C++23 sem intermediário.

O que realmente se compara não é linguagem contra biblioteca, e sim **duas
arquiteturas de gestão de memória e fluxo**:

| | Versão DPDK | Esta alternativa |
|---|---|---|
| Objetos | [`rte_mempool`][guiamempool] pré-alocado | `std::vector` com `reserve()` |
| Fila | [`rte_ring`][guiaring] (circular, fixa) | o próprio `std::vector` |
| Lote | [`rte_ring_dequeue_burst`][apiringdeq] | `std::views::chunk` |
| Erro | código de retorno | `std::expected` |
| Liberação | `put_bulk` explícito | destrutor (RAII) |

Ambas reservam capacidade antes do processamento. No C++, a ausência de
realocação depende de `reserve()` e da verificação do limite em `enqueue()`;
RAII cuida da liberação ao destruir a fila. O DPDK exige devolver explicitamente
os objetos emprestados. Nenhum desses mecanismos dispensa verificar a posse.

## 2. Mecanismo: recursos de C++23 em uso

```cpp
// std::expected — erro sem exceção no caminho crítico, visível na assinatura
[[nodiscard]] std::expected<void, Error> enqueue(Packet p);

// std::views::chunk — batching declarativo
for (auto chunk : std::span{packets_} | std::views::chunk(burst))
    process_burst(std::span<Packet>{chunk.data(), chunk.size()}, r);

// constexpr — o contrato é verificável em tempo de compilação
static_assert(checksum(7, 100) == (7u ^ 100u));
```

Os trechos usam os nomes de [`packet.hpp`](packet.hpp), dentro de `academy` e
da classe `Queue`. `std::expected` representa fila cheia como resultado explícito,
sem lançar exceção nesse caminho. `[[nodiscard]]` permite diagnosticar o retorno
ignorado; o chamador ainda precisa decidir se descarta, espera ou tenta novamente.

## 3. Medição — e por que ela **não** significa o que parece

Mesma máquina, 5 milhões de pacotes, melhor de três execuções, **com os dois
programas aquecidos do mesmo jeito**:

| Lote | DPDK (ns/pacote) | C++23 puro (ns/pacote) | Razão |
|---:|---:|---:|---:|
| 1 | 5,3 | 2,4 | 2,2× |
| 8 | 2,3 | 1,3 | 1,7× |
| 32 | 1,8 | 1,1 | 1,6× |
| 128 | 2,2 | 1,1 | 2,0× |

> **A simetria de método não é detalhe.** Os dois programas descartam uma
> passagem de 4096 pacotes antes de cronometrar, os dois se recusam a publicar
> tempo abaixo de 10 000 pacotes, e os dois imprimem a frequência do núcleo.
> Enquanto só um lado aquecia, a tabela media também a diferença de aquecimento —
> e uma comparação que não controla o método mede o método, não o objeto.

**Neste pipeline, a alternativa C++23 apresentou menor custo nos quatro lotes.**
O resultado compara programas completos em um núcleo, sem NIC, DMA ou
comunicação entre CPUs. Não mede o custo isolado de cada abstração.

### Por que o DPDK perde neste teste

As duas implementações processam os mesmos pacotes, mas percorrem estruturas
diferentes: o DPDK obtém objetos do pool e os passa pelo anel; a alternativa
percorre o vetor reservado. Isso oferece uma explicação plausível para a diferença.
O ensaio não desliga cada operação separadamente, portanto não atribui uma
fração exata do custo ao mempool, ao anel ou às barreiras de memória.

### O que a medição legitimamente mostra

- De lote 1 para 32, ambos reduzem o custo por pacote.
- De 32 para 128, o DPDK sobe de 1,8 para 2,2 ns; o C++ permanece em 1,1 ns
  **na precisão publicada**. A regressão não aparece nos dois lados.
- Pressão de cache é uma hipótese para a regressão do DPDK. Frequência,
  organização do loop e interferência também precisam ser controladas antes
  de atribuir causalidade.

Para a carga medida, lote 32 é o menor custo entre os pontos DPDK ensaiados.
Isso não determina o melhor lote de um receptor de rede, onde espera para
formar lote e latência por pacote também importam.

### Outros cenários, sem antecipar o resultado de rede

A comparação em memória não determina o vencedor com NIC. Para responder à
pergunta de rede é preciso implementar caminhos comparáveis e medir o mesmo
trabalho, com modos de driver, filas e recursos declarados.

Os experimentos abaixo são independentes; não acrescentam um único fator por
etapa. Cada linha mede uma operação diferente:

| Cenário | Operação | Medido | Limite |
|---|---|---|---|
| 1 — um núcleo, em memória | pipeline, ns/pacote, lote 32 | DPDK 1,8 · C++ 1,1 | Sem rede. |
| 2 — uma thread, sem disputa | enqueue + dequeue, ns/objeto, lote 128 | DPDK 0,289 · C++ 1,024 | Não mede repasse entre CPUs. |
| 3 — oito núcleos | get/put em lote versus malloc/free, ns/objeto | DPDK 0,41 · malloc 13,0 | APIs diferentes; não isola toda a origem da vantagem. |
| 4 — rede física | RX/TX e processamento | não medido | Próxima etapa com a ConnectX-4 Lx e fonte de tráfego. |

Há um pipeline DPDK entre núcleos no tópico principal, mas os números de anel
isolado desta comparação vêm de **uma thread**. Não há ainda um comparativo
correspondente de anéis C e C++ transferindo dados entre duas CPUs.

**Cenário 1 — o DPDK perde por 1,6×.** É o teste desta página, e a conclusão é
legítima *para este regime*: um núcleo, tudo em memória.

**Cenário 2 — custo local do anel em uma thread.**

O anel em C++23 agora existe: [`SpscRing`](packet.hpp) — índices atômicos com
`acquire`/`release`, em linhas de cache separadas, capacidade potência de dois.
Medido com **o mesmo protocolo** de
[`custo-anel.c`](../../../../../docs/03-mempool-ring-mbuf/medicoes/custo-anel.c)
por [`custo-anel-cpp.cpp`](custo-anel-cpp.cpp): um thread, sem disputa, ciclo
enfileirar+desenfileirar, 200 000 operações, mesma estatística.

| lote | `rte_ring` SP/SC | `SpscRing` C++23 | razão |
|---:|---:|---:|---:|
| 1 | 1,622 ns | 3,181 ns | 2,0× |
| 8 | 0,525 ns | 1,069 ns | 2,0× |
| 32 | 0,336 ns | 1,008 ns | 3,0× |
| 128 | **0,289 ns** | **1,024 ns** | **3,5×** |

Agregados históricos declarados de **10 execuções por ponto**, sem amostras
individuais preservadas junto desta tabela. As amplitudes entre
execuções: `rte_ring` 1,543–1,674 no lote 1 e 0,287–0,290 no lote 128;
`SpscRing` 3,048–3,954 e 1,003–1,229.

> **A coluna `rte_ring` desta tabela publicava números não reproduzidos na
> campanha posterior de dez execuções.** Ela dizia 2,078
> e 0,368 ns; dez execuções de `custo-anel.c` devolvem 1,622 (amplitude
> 1,543–1,674) e 0,289 (0,287–0,290) — os valores antigos estão **fora** da
> amplitude observada nos dois pontos. Isso não prova que fossem impossíveis:
> sem fontes e condições de ambas as campanhas, a causa não foi determinada.
>
> Duas coisas explicam como isso passou. A primeira: esta coluna nunca foi
> produzida por `custo-anel-cpp.cpp`, que mede **só** o anel em C++ — ela foi
> copiada à mão de uma execução de `custo-anel.c`, e cópia não tem quem a
> confira. A segunda: `custo-anel.c` reporta dispersão de ~1% **dentro** de uma
> execução, enquanto os extremos declarados entre execuções do lote 1 têm razão
> 1,674 / 1,543 = aproximadamente 1,085×. A dispersão interna não demonstra
> estabilidade entre campanhas. Estes agregados históricos não sustentam uma
> recomendação quantitativa atual; consulte o
> [inventário de evidências](../../../../../docs/avaliacoes/inventario-dados.md).
>
> A coluna em C++ não tinha o problema: 3,184 publicado contra 3,181 medido.
> E a correção vai contra a conveniência — a vantagem do `rte_ring` no lote 128
> **sobe** de 2,9× para 3,5×.
>
> <!-- retratado: 2,078 0,687 0,437 0,368 -->

**A diferença cresce com o lote, e é aí que está a explicação.** Em lote 1 os
dois estão na mesma ordem de grandeza — é de fato o mesmo algoritmo. Mas o
`rte_ring` tem operações **em bloco**: `rte_ring_enqueue_bulk` move *n* ponteiros
com **um** par de operações atômicas. O benchmark histórico C++ usa a API por
objeto: enfileirar 128 pacotes custa 128 publicações. O `SpscRing` atual também
oferece API de bloco, exercitada separadamente por `controle-anel.cpp`.

Por isso o C++ fica plano em ~1,02 ns a partir do lote 8 — ele não tem o que
amortizar — enquanto o `rte_ring` continua caindo até 0,289 ns.

> **Isto não é uma vantagem da linguagem.** Um anel em C++ com API de bloco
> permitiria testar a mesma amortização; o que falta é a API, não o compilador. O que o
> DPDK entrega aqui é **desenho de interface** — a decisão de expor
> `enqueue_bulk` em vez de só `enqueue`. É uma vantagem real e transferível, e
> é diferente de "o DPDK é mais rápido".

> O pipeline de dois lcores medido por `bench-ccd.sh` inclui mempool, anel e
> comunicação entre CPUs. Seu tempo não pode substituir o ciclo local do anel
> nesta tabela: a mesma unidade não basta para tornar duas operações comparáveis.

**Cenário 3 — o DPDK ganha por trinta e duas vezes.** Oito núcleos disputando a mesma
fonte de objetos, medido por
[`custo-contencao.c`](../../../../../docs/03-mempool-ring-mbuf/medicoes/custo-contencao.c)
com 9 repetições por ponto:

| threads | mempool | `malloc` | razão |
|---:|---:|---:|---:|
| 1 | 0,48 ns | 15,5 ns | 32× |
| 2 | 0,48 ns | 14,8 ns | 31× |
| 4 | 0,38 ns | 12,4 ns | 33× |
| 8 | **0,41 ns** | **13,0 ns** | **32×** |

**A razão é plana.** Nenhum dos dois degrada com o número de núcleos, porque
cada thread tem o seu: não há disputa por CPU, e a disputa que resta — pela
fonte de objetos — o cache por lcore resolve de um lado e o *arena* por thread
da glibc resolve do outro.

Então de onde vem a vantagem de 32×? Do cache, e dá para desligá-lo. Criando o
**mesmo** pool com `cache_size = 0`:

| threads | mempool sem cache | `malloc` | razão |
|---:|---:|---:|---:|
| 1 | 0,62 ns | 12,2 ns | 20× |
| 2 | 3,27 ns | 12,3 ns | 4× |
| 4 | 11,54 ns | 13,1 ns | 1× |
| 8 | **65,84 ns** | **12,9 ns** | **0,2×** — o mempool **perde** |

```mermaid
xychart-beta
    title "Custo por operação do mempool: com e sem cache por lcore"
    x-axis "threads, uma por núcleo" ["1", "2", "4", "8"]
    y-axis "ns por operação" 0 --> 70
    bar "sem cache (cache_size = 0)" [0.62, 3.27, 11.54, 65.84]
    line "com cache (cache_size = 512)" [0.48, 0.48, 0.38, 0.41]
```

*A linha do pool **com** cache fica colada no eixo: 0,4 ns numa escala de 70 ns
é indistinguível de zero. É esse o ponto do gráfico.*

Sem o cache, o mempool **degrada 106×** de 1 para 8 núcleos e passa a perder para
o `malloc`. Com o cache, fica plano. O controle demonstra a importância desse cache no protocolo. Não separa
quanto da vantagem frente ao malloc decorre da reserva local e quanto da API
em bloco.

> **Controle de afinidade:** as threads criadas depois da EAL podem herdar a
> máscara da thread principal. O comparativo fixa cada thread na CPU do lcore
> correspondente. Confira essa simetria antes de atribuir degradação à contenção
> do alocador; do contrário, o ensaio pode medir disputa pela mesma CPU.

**Cenário 4 — rede física pendente.** A próxima etapa está prevista para a
Mellanox ConnectX-4 Lx 25GbE dual-port SFP28, após confirmar capacidades e fonte
de tráfego. O [tópico de RX/TX](../../../../02-pipeline/01-rx-tx-burst/) registra
os preparativos; a placa atual não cobre os cenários avançados pretendidos.

> Cada experimento declara seu protocolo: o pipeline usa melhor de três, o
> anel usa a estatística compartilhada e a contenção usa nove repetições por
> ponto. Frequência e interferência podem alterar tanto tempos quanto razões.
> As tabelas são transcrições históricas, sem amostras brutas preservadas por
> execução. Novas coletas devem seguir os [critérios de dados](../../../../../docs/00-visao-geral/validacao.md).

## 4. Outros eixos de comparação

### Controles que faltam para explicar as diferenças

| Pergunta | Manter igual | Variar | O que o controle permitiria concluir |
|---|---|---|---|
| A API em bloco explica a vantagem do anel? | Capacidade, lote, thread, trabalho e estatística | Adicionar bulk ao SPSC C++ | Quanto da diferença diminui com publicação em bloco. Não promete tempos iguais. |
| A regressão no lote 128 vem do cache? | Afinidade, carga e ordem de coleta alternada | Lote; observar também frequência e contadores de cache | Se a regressão se repete e é acompanhada por mudança compatível nos contadores. Correlação isolada ainda não prova causa. |
| Quanto custa transferir entre CPUs? | Mesmos anéis, conteúdo e número de objetos | Uma thread versus produtor/consumidor em CPUs distintas | Separar custo local de comunicação; os dados atuais só cobrem o primeiro comparativo. |

A API em bloco e o controle em uma/duas CPUs agora estão implementados no
[`controle-anel.cpp`](controle-anel.cpp), com [coleta rastreável](../../../../../docs/avaliacoes/evidencias/2026-09-14-controle-anel/tabela.md).
O ensaio mantém o mesmo SPSC C++ e payload. Ainda não isola cache como causa
da regressão do pipeline DPDK nem compara os dois anéis entre CPUs.

### Critério de escolha para o problema atual

Para processamento inteiramente em memória em uma thread, use a fila C++ como
referência simples: capacidade limitada, tratamento de fila cheia e liberação
por RAII. Se o requisito passar a incluir produtores/consumidores concorrentes,
reavalie com o SPSC ou `rte_ring` conforme a topologia; `Queue` não implementa
sincronização entre threads. Com NIC, a decisão inclui RX/TX e deixa de ser
respondida por esse microbenchmark.

| Critério | DPDK | C++23 puro |
|---|---|---|
| Linhas de código | 190 | 114 |
| Tamanho do binário | 388 KB | 1,1 MB |
| Bibliotecas `librte_*` ligadas | 7 | 0 |
| Bibliotecas `librte_*` carregadas em execução | **191** | 0 |
| Roda em qualquer máquina | não (precisa de DPDK) | sim |
| Segurança de liberação | manual, `put_bulk` explícito | automática, RAII |
| Caminho para rede real | direto | inexistente |

> Como estes números foram obtidos, para que possam ser refeitos: linhas de
> código contadas do mesmo jeito nos dois lados (sem linhas em branco e sem
> comentários de linha inteira), somando o programa e a lógica pura —
> `pipeline_ring.c` + `packet.c` + `packet.h` de um lado, `packet_pipeline.cpp` +
> `packet.hpp` do outro. Tamanho do binário via `stat -c %s` no build
> `debugoptimized` padrão do projeto. Bibliotecas ligadas via `ldd`; carregadas
> em execução, contando `librte_*.so` distintas em `/proc/<pid>/maps` com o
> programa rodando.

Duas linhas dessa tabela merecem leitura cuidadosa, porque a intuição erra nas
duas.

**O binário C++ é quase três vezes maior, apesar de ter menos código.**
`std::print` e `<format>` trazem bastante instanciação de template para dentro do
executável. O binário DPDK é menor porque quase tudo que ele usa mora em
biblioteca compartilhada — e é exatamente por isso que ele não roda em máquina
sem DPDK instalado. Tamanho de arquivo não mede complexidade; mede onde o código
foi parar.

**Sete bibliotecas ligadas, cento e noventa e uma carregadas.** A diferença é a
EAL: na inicialização ela varre e carrega por `dlopen` todos os drivers
disponíveis, mesmo os que este programa jamais usará (drivers de NIC, de
criptografia, de barramento). É trabalho real, e é uma das coisas que o número da
[§2 do módulo 02](../../../../../docs/02-runtime-dpdk/README.md#2-o-custo-de-existir-quanto-a-eal-leva-para-nascer)
contabiliza. `--no-pci` e `-d` reduzem essa varredura quando se sabe de antemão o
que é preciso.

O eixo mais importante da tabela é o último. Esta alternativa é elegante e
rápida, e **não tem caminho para tratar um pacote de rede real**. Toda a
maquinaria que a faz parecer cara existe para atravessar essa ponte.

## 5. Implementação e validação

| Arquivo | Papel |
|---|---|
| [`packet.hpp`](packet.hpp) | lógica pura, `constexpr`, testável |
| [`packet_pipeline.cpp`](packet_pipeline.cpp) | montagem do pipeline |

```bash
./build/trilha/01-fundamentos/02-mempool-ring/alternativas/cpp23/packet_pipeline -n 10
```

```
Pacotes processados: 10
Total de bytes: 695
Lote (burst): 32 | lotes interrompidos por fila cheia: 0
Tempo medio: 23.1 ns/pacote
```

**Os dois primeiros valores são idênticos aos da versão DPDK.** Isso não é
coincidência: [`tests/test_l1.cpp`](tests/test_l1.cpp) é um espelho deliberado do
teste do lado DPDK — mesmos nomes de caso, mesmos valores esperados, incluindo o
mesmo teste parametrizado sobre tamanhos de lote.

```bash
./scripts/test-all.sh l1     # 16 casos deste lado, 13 do lado DPDK
```

Quando as duas suítes passam com as mesmas asserções, fica demonstrado que a
diferença entre as abordagens é de **arquitetura e custo**, não de
comportamento. Sem isso, a comparação seria retórica.

## 6. Limitações

- Não tem rede, e não tem como ter sem sair do "C++ puro" (o passo seguinte
  seria `AF_PACKET` ou `AF_XDP`, que já são interfaces do kernel).
- Produtor e consumidor são sequenciais no mesmo núcleo; não há concorrência
  real, então nada aqui exercita contenção.
- `std::vector` não garante memória adequada para DMA nem alinhamento de página.

## 7. Referências

- [Tópico 02 — versão DPDK](../../) · [Plano de estudo](../../../../../docs/plano-estudo-dpdk.md)
- `std::expected` (P0323R12), `std::views::chunk` (P2442R1) — <https://en.cppreference.com/w/cpp/23>

[guiamempool]: https://doc.dpdk.org/guides/prog_guide/mempool_lib.html
[guiaring]: https://doc.dpdk.org/guides/prog_guide/ring_lib.html
[apiringdeq]: https://doc.dpdk.org/api/rte__ring_8h.html#a9dd35643c4cdc6fa00ece3cafbcd94d2
