# Projeto final

> **Uso dos números históricos.** Os tempos e razões transcritos nesta página
> são registros didáticos das configurações descritas. Sem cadeia de coleta
> identificada, não sustentam previsão de desempenho nem escolha quantitativa
> da versão atual. Consulte o [inventário de dados](../../docs/avaliacoes/inventario-dados.md)
> para distinguir registros históricos, cálculos e campanhas rastreáveis.

> **Nível 10** do [plano de estudo](../../docs/plano-estudo-dpdk.md) ·
> Pré-requisito: os módulos anteriores.
>
> **Estado: síntese parcial escrita; sistema com rede pendente.** A máquina
> local ainda não tem a NIC-alvo. A próxima etapa está prevista para a
> **Mellanox ConnectX-4 Lx 25GbE dual-port SFP28**. Os dados abaixo descrevem
> componentes em memória, não o desempenho dessa futura arquitetura.

## Objetivo

Consolidar um sistema executável para investigar **em quais cenários o DPDK
compensa** frente a alternativas. Cada conclusão deve corresponder a uma carga,
a uma configuração e a um comportamento efetivamente medidos.

## O sistema

O candidato é um **receptor de market data**, com feed handler primário e
consumidor secundário. O [módulo de runtime](../../docs/02-runtime-dpdk/README.md)
já fornece livro de ofertas, detecção de lacunas de sequência e comunicação em
memória compartilhada. Ainda falta integrar recepção e transmissão físicas.

### Responsabilidades e ordem de integração

Os exemplos atuais são componentes separados. A arquitetura abaixo é a proposta
de integração, com fronteiras de responsabilidade e critérios de conclusão:

| Responsabilidade | Base existente | Próxima entrega e critério de conclusão |
|---|---|---|
| Receber e decodificar no primário | Gerador de ticks sintéticos | Integrar RX físico e validar formato antes de publicar; entradas inválidas devem ser contabilizadas e liberadas. Depende da etapa de rede. |
| Transferir posse e controlar capacidade | Pipeline de mempool/ring; exemplo multiprocesso com anel próprio | Escolher o mecanismo de cada fronteira e definir a ação quando não houver espaço; toda entrada deve ter destino ou motivo de descarte contabilizado. |
| Atualizar o livro no consumidor | Livro por instrumento e detecção de lacunas | Impedir uso de livro inválido após lacuna ou perda de atualidade; retomada exige reconstrução validada. |
| Coordenar encerramento e recuperação | Handshake de encerramento normal | Supervisor, heartbeat e geração implementados; falta validar o reinício real com EAL no host preparado. |

O `rte_ring` do pipeline e o anel de `feed.h` são implementações distintas;
integrá-los não significa encadeá-los obrigatoriamente. A escolha deve considerar
quem produz e consome, a posse dos objetos e o custo medido da fronteira.

Antes da NIC, podem avançar a [política de posse e espera limitada](../../docs/03-mempool-ring-mbuf/README.md#64-política-de-posse-e-progresso)
e a [detecção de ausência e recuperação](../../docs/02-runtime-dpdk/README.md#104-detecção-de-ausência-e-reconstrução-de-estado).
A espera limitada já tem teste L2; a política de saúde tem testes L1 e o
supervisor tem teste com subprocessos controlados. O reinício real com EAL
ainda precisa ser executado com hugetlbfs acessível. Depois, a integração física deve preservar esses contratos e
medir vazão, perdas e latência sob carga na ConnectX-4 Lx.

## As três comparações

| Abordagem | Evidência atual | Próxima validação |
|---|---|---|
| DPDK | EAL, estruturas, pipeline em memória e multiprocesso | RX/TX físico e comportamento do sistema sob carga. |
| C++23 puro | Pipeline em memória e anel SPSC | Comparação de rede exige implementar um caminho, por exemplo com sockets. |
| AF_XDP | Diagnóstico preparatório; sem benchmark comparativo | Confirmar suporte, implementar e medir o modo efetivamente utilizado. |

A preparação de AF_XDP está em [af-xdp-preparacao.md](af-xdp-preparacao.md).
Modelos de driver e modos de cópia devem ser nomeados: o caminho bifurcado do
mlx5 preserva o driver do kernel, conforme a [documentação do DPDK](https://doc.dpdk.org/guides-25.11/linux_gsg/linux_drivers.html#bifurcated-driver).

## A resposta que os dados já permitem

### O que aperta: o orçamento

Em 10GbE com quadros de 64 B, incluindo a ocupação de fio descrita nos
[fundamentos](../../docs/01-fundamentos/README.md#1-o-orçamento-quanto-tempo-existe-por-pacote),
o intervalo de chegada em taxa de linha é **67,2 ns**. É um orçamento de
**vazão para um fluxo de processamento**, não um limite de latência individual.

| Experimento histórico | Valor | Grandeza e unidade experimental |
|---|---:|---|
| Chamada de função | 0,924 ns | Custo amortizado por chamada. |
| Acesso sequencial à memória | 0,193 ns | Custo amortizado por acesso, com paralelismo da CPU. |
| Mempool com cache | 0,98 ns | Tempo por objeto no ciclo obter/devolver. |
| `rte_ring` SP/SC, lote 1 | 1,622 ns | Tempo por objeto no ciclo enqueue/dequeue, uma thread (mediana de 10 execuções; amplitude 1,543–1,674). |
| `malloc`/`free` | 2,18 ns | Tempo por par de operações. |
| Syscall | 33,55 ns | Custo amortizado por chamada no experimento. |
| Publicação → observação entre processos | 40,08 ns | p99 por mensagem; inclui o atraso da sondagem. |
| Pipeline entre núcleos do mesmo bloco L3, lote 1 | 16,0 ns | Tempo amortizado por pacote no pipeline completo. |
| Pipeline entre blocos L3 distintos, lote 1 | 64,3 ns | Mesma grandeza e operação da linha anterior. |
| Mesmo pipeline entre blocos, lote 256 | 9,3 ns | Tempo amortizado por pacote com outro lote. |

Essas linhas não devem ser somadas: misturam operações isoladas, pipeline e
percentil de observação. Nos cenários comparáveis do pipeline, a colocação
entre blocos elevou o custo em cerca de 4×; o lote reduziu o custo por pacote.
Isso motiva escolhas de afinidade e batching, sem demonstrar latência de rede.

### Onde o DPDK ganha e onde perde

São **experimentos independentes**, detalhados na
[alternativa C++23](../01-fundamentos/02-mempool-ring/alternativas/cpp23/README.md).
Não formam uma sequência que acrescenta um único fator por etapa.

| Cenário | Operação medida | DPDK | Alternativa | Resultado local |
|---|---|---:|---:|---|
| Um núcleo, em memória, lote 32 | Pipeline completo, ns/pacote | 1,8 | 1,1 | C++ tem menor custo. |
| Uma thread, sem disputa, lote 1 | Enqueue + dequeue, ns/objeto | 1,622 | 3,181 | `rte_ring` tem menor custo, por cerca de 2,0×. |
| Mesmo anel isolado, lote 128 | Enqueue + dequeue, ns/objeto | 0,289 | 1,024 | Vantagem de cerca de 3,5× para a API em bloco (medianas de 10 execuções). |
| Oito núcleos, alocação | Get/put em lote versus malloc/free, ns/objeto | 0,41 | 13,0 | Cerca de 32× neste protocolo. |
| Rede física | RX/TX e processamento | — | — | Não medido. |

O pipeline C++ vence no primeiro cenário; APIs em bloco e caches locais são
vantajosos nos outros. Isso não estabelece que vários núcleos e lote sejam
condições necessárias e suficientes para adotar DPDK. A decisão do sistema
exige medir também o caminho de rede e seus requisitos operacionais.

### Por que ganha, quando ganha

**Cache por lcore.** No experimento de alocação isolada, desativá-lo elevou o
custo de 0,98 para 10,45 ns. No experimento concorrente, o pool sem cache passou
de 0,62 para 65,84 ns entre 1 e 8 núcleos; com cache, ficou próximo de 0,4 ns.
Isso demonstra o efeito do cache naquele protocolo, sem decompor toda a
vantagem em relação ao alocador da biblioteca padrão.

**API em bloco.** O anel DPDK publica lotes, enquanto a alternativa SPSC publica
cada objeto. O experimento de uma thread mede essa diferença de interface;
não mede transferência entre CPUs. Uma alternativa C++ com API em bloco seria
outro controle útil, ainda não implementado.

**Limite da comparação.** A razão de cerca de 32× varia pouco de 1 a 8 núcleos.
Ela não prova que contenção gere a vantagem. O DPDK obtém 32 objetos numa chamada
bulk; o outro lado executa 32 alocações individuais. As interfaces entregam o
mesmo número de objetos, mas o teste não isola cada mecanismo interno.

### O que o runtime cobra antes da primeira linha

A coleta de referência registrou cerca de **123 ms** para `rte_eal_init()`, com
100 ms atribuídos à espera de calibração do relógio no ambiente estudado.
Isso favorece processos longevos nessa configuração; não é uma constante de
toda instalação DPDK. Consulte o [experimento de inicialização](../../docs/02-runtime-dpdk/README.md#2-o-custo-de-existir-quanto-a-eal-leva-para-nascer).

A medição [entre processos](../../docs/02-runtime-dpdk/README.md#46-quanto-custa-atravessar-a-fronteira)
registrou aproximadamente 10 ns no melhor caso e 40 ns no p99 de publicação até
observação. O consumidor faz sondagem: o resultado inclui a espera até observar
a publicação. Não equivale a latência de NIC, nem permite deduzir resolução
exata a partir de outra coleta do intervalo de sondagem. A interpretação como
latência absoluta também pressupõe TSCs comparáveis entre os núcleos; o teste
atual de amostras degeneradas não comprova essa sincronização.

## O que ainda não está respondido

**Rede física.** Faltam vazão, perda e latência de cauda com tráfego real.
Uma fila pode exercitar RX/TX básico; várias filas são necessárias aos cenários
de escala por filas/RSS. A próxima etapa está planejada para a ConnectX-4 Lx,
com fonte de tráfego e capacidades confirmadas na instalação.

**Sistema integrado.** Ainda não há aplicação que receba, processe e transmita
pela NIC. O [pipeline em memória](../01-fundamentos/02-mempool-ring/) valida
componentes, mas não substitui essa entrega.

**Falha e recuperação com rede.** Já existem testes de esgotamento de pool,
retorno parcial do anel e morte do primário. Permanecem pendentes a contrapressão
até a NIC, a contabilização integrada de perdas e a recuperação do sistema.
Parte dessa implementação pode avançar antes da chegada da placa.

**Rastreabilidade histórica.** As tabelas acima sintetizam transcrições dos
módulos; nem todas têm amostras brutas e configuração por execução preservadas.
As novas coletas seguirão os [critérios de validação e dados](../../docs/00-visao-geral/validacao.md),
com revisão, comando, ambiente, saída e método vinculados à tabela.

## Entregáveis

- Aplicação DPDK de rede, arquitetura e responsabilidades de posse documentadas.
- Testes L1, L2 e L3 conforme o comportamento e seus pré-requisitos.
- Cenários de carga, perda, latência e recuperação definidos antes da coleta.
- Benchmark com dados rastreáveis e modos de driver/offload declarados.
- Comparações com alternativas implementadas, no mesmo trabalho e com recursos explicitados.
- Análise que distinga resultados medidos, hipóteses e pendências por hardware.

## Navegação

| | |
|---|---|
| **Anterior** | [03 — Performance e observabilidade](../03-performance/) |
| **Índice** | [Trilha](../README.md) · [Plano de estudo](../../docs/plano-estudo-dpdk.md) · [Roadmap](../../ROADMAP.md) |
