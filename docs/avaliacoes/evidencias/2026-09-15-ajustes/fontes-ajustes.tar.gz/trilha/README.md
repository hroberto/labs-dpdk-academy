# Trilha de aprendizagem

Esta trilha organiza o estudo do DPDK em módulos progressivos, alinhados ao plano mestre em [docs/plano-estudo-dpdk.md](../docs/plano-estudo-dpdk.md).

## Teoria e prática, e como uma chama a outra

Os conceitos ficam em `docs/`; os tópicos executáveis, em `trilha/`.
Alguns módulos aprofundam uma primeira execução. Siga esta sequência:

1. [Visão geral e ferramentas](../docs/00-visao-geral/README.md), depois
   [Fundamentos](../docs/01-fundamentos/README.md).
2. [EAL mínima](01-fundamentos/01-eal-hello/), depois
   [Runtime](../docs/02-runtime-dpdk/README.md).
3. [Pipeline de mempool e ring](01-fundamentos/02-mempool-ring/), depois
   [Mempool, ring e mbuf](../docs/03-mempool-ring-mbuf/README.md).
4. [Alternativa C++23](01-fundamentos/02-mempool-ring/alternativas/cpp23/) e
   [síntese parcial](04-projeto-final/), observando os limites de cada comparação
   e as responsabilidades propostas para integrar os componentes.
5. Consulte os escopos futuros e os [critérios de validação](../docs/00-visao-geral/validacao.md)
   antes da próxima etapa de rede.

## Mapeamento com o plano mestre

| Nível | Teoria em `docs/` | Prática aqui | Estado |
|---|---|---|---|
| 1 — fundamentos de sistema | [01 — Fundamentos](../docs/01-fundamentos/README.md) | — | **escrito** |
| 2 — rede e plano de dados | [01 — Fundamentos](../docs/01-fundamentos/README.md) | — | **escrito** |
| 3 — [EAL][cEAL] e runtime | [02 — Runtime do DPDK](../docs/02-runtime-dpdk/README.md) | [01-eal-hello/](01-fundamentos/01-eal-hello/) | **escrito** |
| 4 — mempool, ring e mbuf | [03 — Mempool, ring e mbuf](../docs/03-mempool-ring-mbuf/README.md) | [02-mempool-ring/](01-fundamentos/02-mempool-ring/) | **escrito** |
| 5 — pipeline e design | — | [02-pipeline/](02-pipeline/) | esqueleto |
| 6 — RX/TX, burst e hardware | — | [02-pipeline/01-rx-tx-burst/](02-pipeline/01-rx-tx-burst/) | esqueleto |
| 7 — NUMA, cache e desempenho | [01 — Fundamentos §4 e §5](../docs/01-fundamentos/README.md#4-memória-onde-o-desempenho-realmente-se-decide) | a definir | teoria escrita; prática pendente |
| 8 — observabilidade e qualidade | — | [03-performance/](03-performance/) | controle de benchmark rastreável; observabilidade pendente |
| 9 — virtualização, SR-IOV, [vhost-user][cVhost] | — | — | não iniciado |
| 10 — projeto final e alternativas ([AF_XDP][cAfxdp]) | — | [04-projeto-final/](04-projeto-final/) | síntese parcial; sistema pendente |

## Estrutura atual

| Diretório | Conteúdo | Estado |
|---|---|---|
| [01-fundamentos/](01-fundamentos/) | inicialização da EAL; mempool, ring e batching, com alternativa em C++23 | **dois tópicos completos**, com testes L1 e L2 |
| [02-pipeline/](02-pipeline/) | batching, backpressure, RX/TX | esqueleto |
| [03-performance/](03-performance/) | controle de benchmark rastreável; observabilidade futura | parcial |
| [04-projeto-final/](04-projeto-final/) | síntese dos componentes e preparação da próxima etapa | síntese parcial; sistema de rede pendente |

## O cenário que atravessa os módulos

Onde ajuda a fixar o conceito, os exemplos se apoiam num mesmo cenário: um
**servidor de *market data***, que recebe o *feed* de uma bolsa. Ele aparece nos
[fundamentos](../docs/01-fundamentos/README.md#62-o-barramento-também-tem-orçamento)
como o caso extremo de latência ultrabaixa, e no
[módulo de runtime](../docs/02-runtime-dpdk/README.md) como o sistema que
justifica separar processos.

É **embasamento, não camisa de força**. O objeto de estudo é o DPDK, e quando um
conceito pede outro exemplo, o outro exemplo é usado — os tópicos de
`01-fundamentos/`, por exemplo, trabalham com pacotes genéricos, e está certo
assim: o que eles ensinam não fica mais claro chamando o pacote de *tick*.

## Filosofia

A trilha combina:

- didática técnica
- estudo progressivo
- comparação com C++23 puro
- aplicação direta em exemplos executáveis
- foco em engenharia real e trade-offs

## Objetivo pedagógico

A cada módulo, o estudante deve ser capaz de:

- compreender o conceito dentro do plano geral
- entender o mecanismo interno do DPDK
- reconhecer limitações e trade-offs
- implementar ou adaptar um exemplo
- documentar as conclusões técnicas

## Estado do material

Os níveis 1 a 4 têm teoria, código, testes e medições. Os módulos futuros
registram escopo; o projeto final já contém síntese parcial e preparação de
AF_XDP, mas não uma aplicação de rede. Esta página é o índice canônico de estado.

A próxima etapa com rede está prevista para a **Mellanox ConnectX-4 Lx 25GbE
dual-port SFP28**. Sua ausência não impede validar a versão atual: os testes
avançados que dependem dela ficam identificados como pendentes. L3 de runtime,
hugepages e contenção continua aplicável conforme os recursos locais.

[cEAL]: https://doc.dpdk.org/guides/prog_guide/env_abstraction_layer.html
[cVhost]: https://doc.dpdk.org/guides/nics/vhost.html
[cAfxdp]: https://doc.dpdk.org/guides/nics/af_xdp.html
