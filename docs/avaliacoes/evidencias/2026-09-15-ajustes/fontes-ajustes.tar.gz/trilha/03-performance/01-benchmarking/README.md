# Benchmarking e registros de medição

O [controle do anel SPSC](../../../docs/avaliacoes/evidencias/2026-09-14-controle-anel/tabela.md)
tem fontes preservadas, ambiente, comandos, amostras e tabela regenerável.
Ele varia API por objeto/bloco, lote e colocação em uma ou duas CPUs. Não compara
NICs nem substitui os microbenchmarks históricos do DPDK.

## Executar

```bash
python3 scripts/coletar-controle-anel.py /tmp/coleta-anel --cpus 0,2
python3 scripts/coletar-controle-anel.py /tmp/coleta-anel --regenerar
```

Escolha duas CPUs permitidas. O diretório da nova coleta não pode existir.
A coleta é serial, com 25 repetições por cenário e ordem embaralhada por seed
registrada. Cada processo descarta uma passagem de aquecimento e verifica FIFO.
`--regenerar` recalcula a tabela dos mesmos dados; não executa o benchmark.

## Interpretar

A unidade é custo amortizado por objeto, incluindo geração, verificação e relógio
de controle de prazo. Quartis descrevem repetições desse custo, não latência
individual. Uma mediana menor no ensaio não prova o custo isolado de uma atômica.
Na coleta registrada, o ganho da API em bloco depende de lote e colocação; com
duas CPUs os intervalos se sobrepõem em vários cenários. Frequência e turbo não
foram fixados. Não atribua a diferença ao cache sem um controle adicional.

## Pendências

Faltam controles de cache/frequência para explicar a regressão histórica do
pipeline DPDK e uma campanha que substitua todas as tabelas decisórias antigas.
A média de sondagem do runtime não determina resolução exata; a comparação
entre relógios de CPUs diferentes ainda exige justificar sua comparabilidade.
Os [critérios de dados](../../../docs/00-visao-geral/validacao.md) definem as
informações exigidas das próximas coletas.
