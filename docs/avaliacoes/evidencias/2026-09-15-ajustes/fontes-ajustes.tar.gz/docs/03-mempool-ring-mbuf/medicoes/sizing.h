/* SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Henrique M Roberto
 *
 * Dimensionamento de mempool — as regras, sem o DPDK.
 *
 * Distingue limites de criacao (teto e proporcao do cache) de recomendacoes
 * de tamanho e divisibilidade. As regras sao aritmeticas, sem incluir DPDK.
 *
 * n % cache_size nao mede objetos inacessiveis. No experimento pool-esgotado.c,
 * um consumidor unico obtem todos os objetos, inclusive para (4095, 256),
 * pelo caminho de acesso direto ao backend quando o cache nao reabastece.
 * O efeito da divisibilidade na eficiencia com varios caches ainda nao foi
 * isolado experimentalmente neste projeto.
 */
#ifndef DPDK_ACADEMY_SIZING_H
#define DPDK_ACADEMY_SIZING_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Avisos combináveis por OU. Zero significa dimensionamento sem ressalva. */
enum dim_warning {
    DIM_OK = 0,
    DIM_N_NOT_POW2_MINUS_ONE = 1u << 0, /* desperdiça memória */
    DIM_CACHE_ABOVE_MAX = 1u << 1,     /* rte_mempool_create FALHA */
    DIM_CACHE_OVER_N_DIV_1_5 = 1u << 2, /* rte_mempool_create FALHA */
    DIM_N_NOT_MULTIPLE_OF_CACHE = 1u << 3, /* resto aritmetico nao nulo */
};

/* Verifica o par (n, cache_size) contra as quatro regras.
 *
 * `cache_max` é PARÂMETRO, e não constante espelhada aqui, de propósito: copiar
 * RTE_MEMPOOL_CACHE_MAX_SIZE para dentro deste arquivo criaria uma cópia que
 * envelhece em silêncio se o DPDK mudar o valor. Quem chama a partir de código
 * ligado ao DPDK passa a constante real; o teste L1 passa o valor que quer
 * exercitar.
 */
unsigned dim_check(uint32_t n, uint32_t cache_size, uint32_t cache_max);

/* Menor valor da forma 2^q - 1 que comporta `minimo` objetos.
 * Devolve 0 se `minimo` não couber em uint32_t nessa forma. */
uint32_t dim_optimal_n(uint32_t minimum);

/* Maior cache válido para `n` que satisfaz as três regras de cache — inclusive
 * a divisibilidade. Devolve 0 quando nenhum valor não-nulo serve, o que é
 * resposta legítima: pool pequeno demais não comporta cache. */
uint32_t dim_recommended_cache(uint32_t n, uint32_t cache_max);

/* Quantos objetos sobram fora dos lotes cheios de reposição do cache, isto é,
 * n % cache_size. Zero quando n % cache == 0; zero também com cache_size == 0,
 * porque sem cache não há reposição em lote.
 *
 * NÃO são objetos inalcançáveis — `pool-esgotado.c` mede um consumidor único
 * obtendo todos eles, pelo caminho `driver_dequeue`. São os objetos que a
 * divisao por cache_size deixa como resto. Nao quantifica perda de eficiencia
 * nem objetos retidos por outros lcores. */
uint32_t dim_leftover_objects(uint32_t n, uint32_t cache_size);

/* Escreve em `buf` a lista de avisos, separados por "; ". Sempre termina em
 * '\0'. Devolve `buf`, para poder ser usada dentro de printf. */
const char *dim_describe(unsigned warnings, char *buf, size_t tam);

#ifdef __cplusplus
}
#endif

#endif /* DPDK_ACADEMY_SIZING_H */
