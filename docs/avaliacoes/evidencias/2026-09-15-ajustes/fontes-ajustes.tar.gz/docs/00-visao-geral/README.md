# Visão geral — o que este material é, e como lê-lo

Esta seção responde às perguntas que vêm antes do conteúdo técnico: **o que se
estuda aqui, o que se pressupõe do leitor, com que método, e em que máquina os
números foram obtidos.**

Comece pela [primeira execução e leitura dos resultados](execucao.md).

## Índice

1. [O que este material é](#1-o-que-este-material-é)
2. [O que se pressupõe do leitor](#2-o-que-se-pressupõe-do-leitor)
3. [O método](#3-o-método)
4. [Como ler os números](#4-como-ler-os-números)
5. [O ambiente de medição](#5-o-ambiente-de-medição)
6. [Nesta seção](#6-nesta-seção)

---

## 1. O que este material é

Este material usa o DPDK para estudar software de plano de dados por meio de
experimentos: custo, previsibilidade, gestão de memória e decisões de arquitetura.
Cada tópico parte de um problema, explica o mecanismo e relaciona o resultado
à implementação que o produziu.

A [alternativa C++23](../../trilha/01-fundamentos/02-mempool-ring/alternativas/cpp23/)
resolve o mesmo contrato do pipeline em memória e apresenta menor custo naquele
cenário. Outros experimentos favorecem estruturas do DPDK. O objetivo é delimitar
quando cada solução serve, sem transformar uma medição local em regra universal.

O [índice da trilha](../../trilha/README.md) indica a ordem de estudo e o estado
dos módulos. A versão atual cobre componentes em memória e runtime; os ensaios
avançados de rede aguardam a arquitetura com a ConnectX-4 Lx.

---

## 2. O que se pressupõe do leitor

A trilha vai de iniciante a avançado **em DPDK**, não em programação de sistemas.
Os conceitos específicos são introduzidos nos módulos; programação de
sistemas requer a familiaridade descrita abaixo.

Recomenda-se familiaridade com:

| Área | Nível esperado |
|---|---|
| C | ler e escrever; ponteiros, `struct`, alocação |
| C++ | opcional — só as alternativas comparativas o usam (C++23) |
| Linux | linha de comando, processos, permissões |
| Concorrência | o que é uma thread, e por que duas delas disputam |
| Memória | pilha, heap, e a noção de que existe memória virtual |
| Redes | pacote, cabeçalho, o que faz uma placa de rede |
| Build | compilar, ligar, ler uma mensagem de erro do compilador |

**O que não se pressupõe**, e o material ensina do zero: tradução de endereço e
TLB, hugepages, NUMA, coerência de cache, falso compartilhamento, afinidade de
CPU, IOMMU e DMA, orçamento por pacote, e naturalmente todo o DPDK.

> **Um conhecimento em falta não impede começar.** Os
> [fundamentos](../01-fundamentos/README.md) constroem a base de memória,
> execução e rede antes de o DPDK aparecer. Mas o material **não reexplica** C
> nem Linux em nível introdutório: quem precisar disso vai querer uma fonte
> paralela, e não vai encontrá-la aqui.

---

## 3. O método

Os tópicos desenvolvidos seguem este percurso. Os esqueletos registram apenas
o escopo futuro; não representam implementação ou medição concluída:

```mermaid
flowchart LR
    P["problema"] --> M["mecanismo"] --> T["trade-offs"]
    T --> I["implementação"] --> ME["medição"]
    ME --> C["confronto<br/>com a literatura"]
    C --> A["análise"] --> D["decisão de<br/>arquitetura"]

    classDef fim fill:#e8f6ef,stroke:#1e8449,color:#145a32
    class D fim
```

Em palavras:

1. **Problema** — que restrição real existe, antes de qualquer API.
2. **Mecanismo** — como a coisa funciona por dentro, e por que se comporta assim.
3. **Trade-offs** — o que ela custa, o que ela desliga, quando não serve.
4. **Implementação** — código executável, com testes.
5. **Medição** — número obtido nesta máquina, com método declarado.
6. **Confronto** — o número bate com a literatura? Se não, por quê?
7. **Análise e decisão** — o que isso mudaria num projeto real.

A conclusão de um experimento deve responder a quatro perguntas:

| Pergunta | Como responder |
|---|---|
| O que foi observado? | Identificar operação, carga, configuração e resultado. |
| Qual mecanismo explica o resultado? | Ligar à implementação ou à fonte; declarar o que não foi isolado. |
| Que outra causa poderia explicá-lo? | Nomear alternativas relevantes, como afinidade, lote e frequência. |
| Que decisão a evidência sustenta? | Escolher uma ação dentro daquele cenário e indicar quando revê-la. |

Afirmações normativas nomeiam a fonte e sua versão. Números experimentais apontam
para o programa e, quando preservado, para o registro da execução. Resultados
da literatura vêm identificados como externos. Os [critérios de dados](validacao.md#como-publicar-dados)
definem o que falta quando há apenas uma transcrição histórica.

---

## 4. Como ler os números

Separe observação, fonte e interpretação ao ler ou escrever uma conclusão.
Essa distinção evita generalizar o resultado de uma máquina.

A convenção, aplicada na linguagem em vez de em etiquetas:

| Quando o texto diz | Significa |
|---|---|
| "nesta máquina", "medimos", com tabela | **observação** — obtida pelo programa citado; a reexecução pode dar outro valor |
| "a documentação diz", com citação e link | **fato documentado** — verificável na fonte |
| "ou seja", "a leitura é", "a consequência" | **inferência** — interpretação, e pode estar errada |
| "não investigamos", "fica em aberto" | **pendência** — pode faltar execução, explicação causal ou implementação |

As seções **Limitações** dos módulos desenvolvidos delimitam o alcance das
conclusões. A indicação “proposta” descreve uma solução a implementar; não
equivale a comportamento demonstrado pelo código.

**Desempenho não é previsibilidade.** Uma média baixa não implica comportamento
estável. Para avaliar latência, procure percentis e dispersão, além do valor
típico. As tabelas históricas nem sempre preservam esses dados; quando só há
custo amortizado ou melhor execução, não se pode concluir sobre a cauda.
Num exemplo hipotético, média de 10 µs e p99,9 de 5 ms mostram que a média
esconde atrasos muito maiores; aceitá-los depende do requisito. O vocabulário está na
[§7 dos fundamentos](../01-fundamentos/README.md#7-métricas-o-vocabulário-para-não-se-enganar).

---

## 5. O ambiente de medição

**Resultado experimental sem contexto de hardware não é resultado universal.**
As medições locais vêm da máquina de referência. Valores citados da literatura
são externos e fórmulas de orçamento são cálculos, não medições do host.
Reexecutar um programa em outra máquina pode produzir outro valor.

O script abaixo descreve o ambiente **no momento da execução**. Preserve sua
saída junto da coleta; executá-lo hoje não recupera o ambiente de uma tabela antiga:

```bash
./scripts/ambiente.sh              # legível
./scripts/ambiente.sh --markdown   # tabela para colar num documento
```

Ele reporta o que efetivamente muda um resultado: modelo e topologia da CPU,
**domínios de cache L3**, sinalizadores de TSC, *governor* e turbo, hugepages,
kernel e sua linha de comando, mitigações de CPU, NIC e driver, e as versões de
DPDK, compilador e build.

Três desses campos já mudaram uma conclusão neste projeto:

- **`meltdown: Not affected`** é um dado de contexto para investigar o custo
  de syscall; sozinho não isola a configuração de KPTI nem toda a diferença
  frente a outra máquina.
- **ausência de `tsc_known_freq`** explicou os
  [100 ms de calibração](../02-runtime-dpdk/README.md#22-por-que-essa-espera-existe-e-quando-ela-não-acontece)
  dentro de `rte_eal_init()`.
- **os domínios de L3** (`0-5,12-17` e `6-11,18-23`) são o que separa "mesmo CCD"
  de "CCDs diferentes" nas medições de comunicação entre núcleos.

> Rode o script antes de comparar qualquer número seu com os daqui. Se o
> *governor* estiver em `powersave` e o turbo ligado — que é o padrão da maioria
> das distribuições, e o desta máquina — a frequência varia durante a medição, e
> é por isso que os documentos publicam mediana e dispersão em vez de um valor
> só.

---

## 6. Nesta seção

- **[Ferramental do projeto](ferramental.md)** — build, compilação e testes
  L1/L2/L3: quais ferramentas o projeto usa, por que cada uma foi escolhida, o que
  foi descartado (Conan, vcpkg, CMake) e os erros concretos que essas decisões
  evitam.

- **[Validação, dados e evolução com hardware](validacao.md)** — critérios de
  teste, rastreabilidade das medições e aceitação da etapa com a ConnectX-4 Lx.

## Navegação

| | |
|---|---|
| **Próximo** | [01 — Fundamentos](../01-fundamentos/README.md) |
| **Índice** | [Documentação](../README.md) · [Plano de estudo](../plano-estudo-dpdk.md) · [README do projeto](../../README.md) |
