#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Teste L3: morte por SIGKILL deve invalidar o livro e encerrar o consumidor.
# Requer hugetlbfs compartilhado; ausência do requisito retorna 77.
set -u

PRIMARIO=${1:?uso: l3_primario_morre.sh <feed-primario> <feed-secundario>}
SECUNDARIO=${2:?uso: l3_primario_morre.sh <feed-primario> <feed-secundario>}

PREFIXO="academia_morte_$$"
# Alto de propósito: o primário precisa continuar publicando quando for morto,
# senão o teste mediria um encerramento normal.
TOTAL=${DPDK_ACADEMY_TICKS:-4000000}
LCORE_PRIMARIO=${LCORE_PRIMARIO:-0}
LCORE_SECUNDARIO=${LCORE_SECUNDARIO:-1}
# Quanto tempo damos ao secundário para perceber sozinho que o primário morreu.
# O prazo externo inclui escalonamento e cleanup, além do timeout interno.
ESPERA_S=${DPDK_ACADEMY_ESPERA:-5}

SAIDA_P=$(mktemp) || exit 1
SAIDA_S=$(mktemp) || exit 1
pid_primario=""
pid_secundario=""

limpar() {
    local codigo=$?
    [ -n "$pid_secundario" ] && kill -9 "$pid_secundario" 2>/dev/null
    [ -n "$pid_primario" ] && kill -9 "$pid_primario" 2>/dev/null
    wait 2>/dev/null
    if declare -F preservar_log_l3 >/dev/null; then
        preservar_log_l3 "$PREFIXO" "$SAIDA_P" "$SAIDA_S" "$codigo" || codigo=1
    fi
    rm -f "$SAIDA_P" "$SAIDA_S"
    rm -rf "${XDG_RUNTIME_DIR:-/var/run}/dpdk/${PREFIXO}" 2>/dev/null
    rm -f "/dev/hugepages/${PREFIXO}"* 2>/dev/null
    [ -n "${DPDK_ACADEMY_HUGE_DIR:-}" ] && rm -f "${DPDK_ACADEMY_HUGE_DIR}/${PREFIXO}"* 2>/dev/null
    exit "$codigo"
}
trap limpar EXIT

falhas=0
check() {
    if [ "$2" -eq 0 ]; then
        echo "  ok    - $1"
    else
        echo "  FALHA - $1"
        falhas=$((falhas + 1))
    fi
}

pular() {
    echo "  PULADO - $1"
    echo ""
    echo "  Este teste exige hugetlbfs compartilhado entre processos, igual ao"
    echo "  l3_multiprocesso.sh. Habilite com:"
    echo ""
    echo "    sudo ./scripts/preparar-hugepages.sh"
    echo "    export DPDK_ACADEMY_HUGE_DIR=/mnt/huge-academia"
    echo ""
    echo "L3: pulado (ambiente sem memoria compartilhada entre processos)"
    exit 77
}

falhar() {
    echo "  FALHA - $1"
    sed 's/^/    | /' "$SAIDA_P" "$SAIDA_S"
    exit 1
}

echo "== L3: o primario morre, o secundario continua =="
echo "  prefixo de runtime: $PREFIXO"
echo ""

# Descobre o hugetlbfs em vez de exigir a variavel exportada a mao -- ver o
# porque em lib-hugetlbfs.sh. DPDK_ACADEMY_HUGE_DIR continua vencendo, quando
# definida, para permitir apontar uma montagem especifica.
# shellcheck source=lib-hugetlbfs.sh
. "$(dirname "$0")/lib-hugetlbfs.sh"
DPDK_ACADEMY_HUGE_DIR=$(descobrir_hugetlbfs)
export DPDK_ACADEMY_HUGE_DIR
hugetlbfs_disponivel "$DPDK_ACADEMY_HUGE_DIR" || pular "hugetlbfs gravavel com paginas livres indisponivel"
EXTRA_EAL=${DPDK_ACADEMY_HUGE_DIR:+--huge-dir=$DPDK_ACADEMY_HUGE_DIR}
[ -n "$DPDK_ACADEMY_HUGE_DIR" ] && echo "  hugetlbfs: $DPDK_ACADEMY_HUGE_DIR"

# --- 1. primário publicando -----------------------------------------------
# shellcheck disable=SC2086
"$PRIMARIO" -l "$LCORE_PRIMARIO" --file-prefix="$PREFIXO" --no-pci $EXTRA_EAL \
    -- "$TOTAL" cadencia >"$SAIDA_P" 2>&1 &
pid_primario=$!

for _ in $(seq 1 100); do
    grep -q "aguardando o assinante conectar" "$SAIDA_P" 2>/dev/null && break
    kill -0 "$pid_primario" 2>/dev/null || break
    sleep 0.2
done

if ! grep -q "aguardando o assinante conectar" "$SAIDA_P" ||
   ! kill -0 "$pid_primario" 2>/dev/null; then
    falhar "primario nao ficou pronto; falha de execucao ou tempo limite"
fi

# --- 2. secundário anexado -------------------------------------------------
# shellcheck disable=SC2086
"$SECUNDARIO" -l "$LCORE_SECUNDARIO" --file-prefix="$PREFIXO" --no-pci \
    --proc-type=secondary $EXTRA_EAL >"$SAIDA_S" 2>&1 &
pid_secundario=$!

for _ in $(seq 1 100); do
    grep -q "endereco virtual" "$SAIDA_S" 2>/dev/null && break
    kill -0 "$pid_secundario" 2>/dev/null || break
    sleep 0.2
done

if ! kill -0 "$pid_secundario" 2>/dev/null ||
   ! grep -q "endereco virtual" "$SAIDA_S"; then
    falhar "secundario nao confirmou o mapeamento da memoria compartilhada"
fi
check "secundario anexou-se a memoria do primario" 0

# Confirma consumo real antes da falha, evitando matar apenas na inicializacao.
for _ in $(seq 1 100); do
    grep -q 'Primeiro lote consumido:' "$SAIDA_S" && break
    kill -0 "$pid_secundario" 2>/dev/null || break
    sleep 0.05
done
grep -q 'Primeiro lote consumido:' "$SAIDA_S" || falhar 'nenhum tick consumido antes da morte'

# --- 3. a morte ------------------------------------------------------------
# SIGKILL, e não SIGTERM: queremos morte súbita, sem chance de encerramento
# ordenado. É o caso ruim -- OOM killer, falha de hardware, `kill -9` de um
# operador apressado.
echo ""
echo "  matando o primario (SIGKILL, sem encerramento ordenado)..."
kill -9 "$pid_primario" 2>/dev/null
wait "$pid_primario" 2>/dev/null
rc_primario=$?
pid_primario=""
check "primario terminou por SIGKILL (137)" "$([ "$rc_primario" -eq 137 ]; echo $?)"
# Aguarda o diagnóstico da política, não somente sobrevivência do processo.
for _ in $(seq 1 100); do
    grep -q 'ESTADO SUSPEITO:' "$SAIDA_S" && break
    kill -0 "$pid_secundario" 2>/dev/null || break
    sleep 0.05
done
grep -q 'ESTADO SUSPEITO:.*livro=INVALIDO' "$SAIDA_S"
check "ausencia detectada e livro invalidado" $?
for _ in $(seq 1 100); do
    kill -0 "$pid_secundario" 2>/dev/null || break
    sleep 0.05
done
if kill -0 "$pid_secundario" 2>/dev/null; then
    falhar 'secundario nao encerrou dentro do prazo externo'
fi
wait "$pid_secundario"; rc_s=$?
pid_secundario=""
check "secundario encerrou por ausencia (3)" "$([ "$rc_s" -eq 3 ]; echo $?)"
sed 's/^/    | /' "$SAIDA_S"

if [ $falhas -eq 0 ]; then
    echo ""
    echo "L3: todos os testes passaram"
else
    echo ""
    echo "L3: $falhas falha(s)"
    exit 1
fi
