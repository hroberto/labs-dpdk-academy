/* SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Henrique M Roberto
 *
 * Assinante do feed — o processo SECUNDÁRIO.
 *
 * É um BINÁRIO DIFERENTE, com main() próprio, compilado separadamente. Ele não
 * recebe nada por socket, pipe ou fila do sistema: ele se ANEXA à memória que o
 * primário já criou, encontrando-a pelo nome da memzone, e lê os ticks
 * diretamente de lá. Nenhuma cópia atravessa a fronteira de processo.
 *
 * O que este programa mede: quanto tempo um tick leva entre ser publicado pelo
 * primário e ser observado aqui. Publica-se por percentis (§7 dos fundamentos:
 * latência não se reporta por média), porque num feed de mercado o requisito
 * está na cauda — o tick da abertura que chegou tarde é o que custa dinheiro.
 *
 * USO:
 *   ./feed-secundario -l 1 --file-prefix=academia --proc-type=secondary
 */
#define _GNU_SOURCE
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

#include <rte_cycles.h>
#include <rte_eal.h>
#include <rte_errno.h>
#include <rte_lcore.h>
#include <rte_memzone.h>
#include <rte_pause.h>

#include "statistics.h"
#include "feed.h"
#include "feed-clock.h"
#include "feed-health.h"
#include <limits.h>

/* O primário pode ainda estar subindo a EAL quando este processo já está de pé. */
#define ESPERA_MEMZONE_S 15

int main(int argc, char **argv)
{
    const uint64_t timeout_ms = feed_env_number("DPDK_ACADEMY_TIMEOUT_MS", 1000, 60000);
    const uint64_t freshness_ms = feed_env_number("DPDK_ACADEMY_FRESHNESS_MS", 5000, 60000);
    const uint64_t expected_generation = feed_env_number("DPDK_ACADEMY_GENERATION", UINT64_MAX, UINT64_MAX);
    if (!timeout_ms || !freshness_ms || !expected_generation) return 2;
    int failed = 0;
    const int consumidos_pela_eal = rte_eal_init(argc, argv);
    if (consumidos_pela_eal < 0) {
        fprintf(stderr, "feed-secundario: EAL nao inicializou: %s\n", rte_strerror(rte_errno));
        fprintf(stderr, "  Confira: mesmo --file-prefix do primario, e --proc-type=secondary.\n");
        return 2;
    }

    if (rte_eal_process_type() != RTE_PROC_SECONDARY) {
        fprintf(stderr, "feed-secundario: este processo subiu como PRIMARIO.\n");
        fprintf(stderr, "  Faltou --proc-type=secondary, ou o primario nao estava no ar.\n");
        fprintf(stderr, "  Atencao: com --proc-type=auto a EAL vira primaria em silencio.\n");
        rte_eal_cleanup();
        return 2;
    }

    /* rte_memzone_lookup NÃO cria: um secundário não pode inicializar memória
     * compartilhada, só se anexar à que já existe. Se o primário ainda não
     * chegou a reservar a região, a busca falha — daí o laço. */
    const struct rte_memzone *mz = NULL;
    const uint64_t hz_local = rte_get_tsc_hz();
    const uint64_t limite = rte_rdtsc() + (uint64_t)ESPERA_MEMZONE_S * hz_local;
    while ((mz = rte_memzone_lookup(FEED_MEMZONE)) == NULL) {
        if (rte_rdtsc() > limite) {
            fprintf(stderr, "feed-secundario: memzone \"%s\" nao apareceu.\n", FEED_MEMZONE);
            rte_eal_cleanup();
            return 3;
        }
        rte_pause();
    }

    if (mz->len < sizeof(struct shared_feed)) { rte_eal_cleanup(); return 2; }
    struct shared_feed *f = (struct shared_feed *)mz->addr;
    while (!atomic_load_explicit(&f->ready, memory_order_acquire)) {
        if (rte_rdtsc() > limite) { rte_eal_cleanup(); return 3; }
        rte_pause();
    }
    if (mz->len < sizeof(*f) || f->layout_version != FEED_LAYOUT_VERSION || !f->generation ||
        (getenv("DPDK_ACADEMY_GENERATION") != NULL && expected_generation != f->generation) ||
        f->total_previsto == 0 || f->total_previsto > INT_MAX || f->tsc_hz == 0) {
        fprintf(stderr, "feed-secundario: layout, geracao ou tamanho invalidos\n");
        rte_eal_cleanup(); return 2;
    }
    printf("Geracao: %" PRIu64 "\n", f->generation);
    const uint64_t total = f->total_previsto;

    printf("\n== Assinante do feed (processo secundario) ==\n\n");
    printf("  memzone .............. \"%s\" (encontrada pelo NOME)\n", mz->name);
    printf("  endereco virtual ..... %p        <- compare com o do primario\n", mz->addr);
    printf("  endereco IOVA ........ 0x%" PRIx64 "\n", (uint64_t)mz->iova);
    printf("  lcore do consumidor .. %u (indice no no %d, no NUMA %u)\n", rte_lcore_id(),
           rte_lcore_to_cpu_id((int)rte_lcore_id()), rte_socket_id());
    printf("  ticks previstos ...... %" PRIu64 "\n\n", total);
    fflush(stdout);

    double *amostras_ns = (double *)malloc((size_t)total * sizeof(double));
    if (amostras_ns == NULL) {
        fprintf(stderr, "feed-secundario: sem memoria para %" PRIu64 " amostras\n", total);
        rte_eal_cleanup();
        return 1;
    }

    /* UM fluxo (a assinatura) e UM LIVRO POR INSTRUMENTO. A separação não é
     * estética: aplicar ticks de papéis diferentes ao mesmo livro compara a
     * compra de um com a venda de outro e produz spread negativo. */
    struct fluxo fl;
    fluxo_iniciar(&fl);

    struct order_book livros[FEED_INSTRUMENTOS];
    for (unsigned i = 0; i < FEED_INSTRUMENTOS; i++)
        order_book_init(&livros[i]);

    const double ns_por_ciclo = 1e9 / (double)f->tsc_hz;

    /* Média de um laço separado; não determina resolução nem sincronização. */
    const int calibragem = 20000;
    const uint64_t c0 = rte_rdtsc();
    for (int i = 0; i < calibragem; i++) {
        (void)atomic_load_explicit(&f->published, memory_order_acquire);
        rte_pause();
    }
    const double passo_ns = (double)(rte_rdtsc() - c0) * ns_por_ciclo / calibragem;

    /* Anuncia presença. release: o primário só deve ver este sinal depois de
     * tudo que este processo preparou estar de fato pronto. */
    atomic_store_explicit(&f->assinante_pronto, 1u, memory_order_release);

    struct feed_watch watcher;
    feed_watch_init(&watcher, f->generation, feed_now_ns());
    unsigned rebuild_mask = 0;
    uint64_t rebuilds = 0;
    uint64_t lidos = 0;
    uint64_t lacunas_vistas = 0;
    uint64_t degenerados = 0; /* amostras impossíveis: TSC desalinhado */
    int first_valid = 1;

    while (lidos < total) {
        /* acquire: emparelha com o release do produtor. Garante que, ao ver o
         * índice, o conteúdo do tick correspondente já está visível. */
        const uint64_t disponiveis = atomic_load_explicit(&f->published, memory_order_acquire);

        const uint64_t now = feed_now_ns();
        atomic_store_explicit(&f->consumer_heartbeat, now, memory_order_release);
        enum feed_health health = feed_watch_update(&watcher, f->generation,
            atomic_load_explicit(&f->heartbeat, memory_order_acquire), disponiveis, now,
            timeout_ms * 1000000ULL, freshness_ms * 1000000ULL);
        if (health != FEED_HEALTHY ||
            (disponiveis < total && atomic_load_explicit(&f->producer_stopped, memory_order_acquire))) {
            fprintf(stderr, "ESTADO SUSPEITO: motivo=%d ultimo_tick=%" PRIu64 " livro=INVALIDO\n", health, lidos);
            atomic_store_explicit(&f->consumer_failed, 1, memory_order_release);
            failed = 3;
            break;
        }
        if (disponiveis < lidos || disponiveis - lidos > FEED_CAPACIDADE || disponiveis > total) {
            failed = 3;
            atomic_store_explicit(&f->consumer_failed, 1, memory_order_release);
            break;
        }
        if (lidos == disponiveis) {
            rte_pause(); /* nada novo: girar sem queimar a linha de cache */
            continue;
        }

        while (lidos < disponiveis) {
            const struct tick *t = &f->ring[lidos & FEED_MASCARA];

            /* A latência é medida ANTES de qualquer trabalho sobre o tick: o
             * que se quer é o custo da travessia, não o do livro. */
            const uint64_t agora = rte_rdtsc();
            /* Deltas degenerados detectam algumas anomalias, não alinhamento. */
            const uint64_t delta = agora - t->tsc;
            if (delta == 0 || delta > f->tsc_hz) /* zero, ou mais de 1 segundo */
                degenerados++;
            amostras_ns[lidos] = (double)delta * ns_por_ciclo;

            /* Primeiro a integridade do FLUXO... */
            const enum fluxo_resultado r = fluxo_verificar(&fl, t->sequence);
            if (r == FLUXO_LACUNA) {
                lacunas_vistas++;
                rebuild_mask = 0;
                for (unsigned k = 0; k < FEED_INSTRUMENTOS; k++) order_book_init(&livros[k]);
            }

            /* ...e só então o preço, no livro DO PAPEL que veio no tick. */
            if (r != FLUXO_DESCARTADO && t->instrument < FEED_INSTRUMENTOS)
            {
                order_book_apply(&livros[t->instrument], t);
                unsigned before = rebuild_mask;
                rebuild_mask |= 1u << (2 * t->instrument + t->lado);
                if (before != 255u && rebuild_mask == 255u) rebuilds++;
                if (first_valid && rebuild_mask == 255u) {
                    printf("LIVRO ATIVO: geracao=%" PRIu64 " tick=%" PRIu64 " lados=8\n",
                           f->generation, lidos + 1);
                    fflush(stdout);
                    first_valid = 0;
                }
            }

            lidos++;
        }

        atomic_store_explicit(&f->consumidos, lidos, memory_order_release);
        static int first_batch = 1;
        if (first_batch) {
            printf("Primeiro lote consumido: %" PRIu64 "\n", lidos);
            fflush(stdout);
            first_batch = 0;
        }
    }

    if (failed) goto cleanup;
    printf("Validade do livro: %s; reconstrucoes: %" PRIu64 "\n", rebuild_mask == 255u ? "VALIDO" : "AGUARDANDO", rebuilds);
    const struct statistics lat = summarize(amostras_ns, (int)total);
    if (!collection_is_valid(lat, (int)total)) { failed = 1; goto cleanup; }

    printf("  --- travessia entre processos, por tick (nanossegundos) ---\n\n");
    print_header_tail();
    print_row_tail("publicacao -> observacao", lat);
    printf("\n    media do laco em calibracao separada: %.1f ns\n", passo_ns);
    printf("    amostras degeneradas: %" PRIu64 " de %" PRIu64 "\n", degenerados, total);
    printf("    TSCs comparaveis sao uma hipotese, nao comprovada por este contador.\n");
    printf("\n  --- integridade da assinatura ---\n\n");
    printf("    ticks aceitos ........... %" PRIu64 "\n", fl.recebidos);
    printf("    descartados (repetidos) . %" PRIu64 "\n", fl.dropped);
    printf("    lacunas detectadas ...... %" PRIu64 " (o primario injetou %" PRIu64 ")\n",
           fl.gaps, f->lacunas_injetadas);
    printf("    eventos com lacuna ...... %" PRIu64 "\n", lacunas_vistas);

    printf("\n  --- livro por instrumento (topo de mercado) ---\n\n");
    printf("    %-12s %10s %10s %8s %9s\n", "instrumento", "compra", "venda", "spread",
           "aplicados");
    printf("    %-12s %10s %10s %8s %9s\n", "-----------", "------", "-----", "------",
           "---------");
    int cruzados = 0;
    for (unsigned i = 0; i < FEED_INSTRUMENTOS; i++) {
        const struct order_book *lv = &livros[i];
        char bid[16], ask[16], spread[16];
        snprintf(bid, sizeof(bid), "%s", lv->best_bid == LIVRO_SEM_PRECO ? "-" : "");
        if (lv->best_bid != LIVRO_SEM_PRECO)
            snprintf(bid, sizeof(bid), "%d", lv->best_bid);
        snprintf(ask, sizeof(ask), "%s", lv->best_ask == LIVRO_SEM_PRECO ? "-" : "");
        if (lv->best_ask != LIVRO_SEM_PRECO)
            snprintf(ask, sizeof(ask), "%d", lv->best_ask);
        const int32_t sp = livro_spread(lv);
        snprintf(spread, sizeof(spread), "%s", sp == LIVRO_SEM_PRECO ? "-" : "");
        if (sp != LIVRO_SEM_PRECO)
            snprintf(spread, sizeof(spread), "%d", sp);
        cruzados += order_book_crossed(lv);
        printf("    papel %-6u %10s %10s %8s %9" PRIu64 "\n", i, bid, ask, spread,
               lv->aplicados);
    }
    printf("\n    livros cruzados ......... %d %s\n", cruzados,
           cruzados == 0 ? "(nenhum: compra sempre abaixo da venda)"
                         : "<- ANOMALIA: investigar");
    printf("    precos em centavos; spread e venda menos compra\n");

    printf("\n  Publicacao ate observacao inclui sondagem, comunicacao e relogio.\n");
cleanup:
    free(amostras_ns);

    /* Avisa o primário de que já terminou, ANTES do próprio cleanup: é ele que
     * mantém o socket de controle com que este processo ainda vai conversar. */
    atomic_store_explicit(&f->assinante_terminou, 1u, memory_order_release);

    rte_eal_cleanup();
    return failed;
}
