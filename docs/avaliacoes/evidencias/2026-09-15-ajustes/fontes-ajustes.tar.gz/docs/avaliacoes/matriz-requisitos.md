# Matriz de requisitos e evidências

Esta matriz cobre os contratos críticos selecionados da versão em memória e
as onze exigências adicionais do relatório. Não é percentual de cobertura do
projeto. A evidência de execução fica no [registro dos ajustes](execucao-ajustes.md).
Escrever um teste ou uma linha nesta matriz não altera seu estado para aprovado.

| ID | Contrato | Nível e estímulo | Teste / evidência | Limite |
|---|---|---|---|---|
| C01 | Amostra inválida não produz estatística utilizável | L1: negativo, NaN e infinito em cada posição | `test_l1_statistics.cpp` | Não valida desempenho histórico. |
| C02 | Publicação exige protocolo completo e registros correspondentes | L2: CLI com dados íntegros e 12 corrupções deliberadas | `scripts/tests/l2_publicacao.py` | Fixtures de campanha; nova coleta exercita o caminho produtor. |
| C03 | Controles de publicação detectam contratos removidos | L1: quatro mutações executáveis | `scripts/tests/l1_mutacoes_publicacao.py` | Conjunto de mutações selecionado, não exaustivo. |
| C04 | Falha esperada vem da coleta | L2: binário com sentinela injetada | `medicoes/tests/l2_coleta_invalida.sh` do módulo 03 | EAL malsucedida não é aprovação do controle. |
| C05 | Retorno parcial devolve objetos rejeitados | L2: anel reduzido e vazamento deliberado | `trilha/01-fundamentos/02-mempool-ring/tests/l2_failure.sh` | Conferir retorno, estímulo e invariante. |
| C06 | Consumidor parado termina e devolve objetos | L2: mesmo lcore e outro lcore | Mesmo runner de falhas | Limite de progresso, não garantia de tempo real rígido. |
| C07 | Heartbeat, atualidade e geração são distintos | L1: relógio controlado e fronteira do prazo | `test_l1_feed_health.cpp` | Não substitui integração EAL. |
| C08 | Nova sessão começa após terminar processos antigos | L2: subprocessos reais controlados | `scripts/tests/l2_feed_supervisor.py` | Confere eventos, PIDs e preservação de recurso alheio; sem EAL. |
| C09 | Falha só é injetada após consumo e estado ativo | L2/L3: logs de geração e consumo; cenários sem estado ativo/final | Teste do supervisor e `l3_recuperacao.sh` | L3 depende de hugetlbfs; L2 não o certifica. |
| C10 | Comunicação, invalidação e recuperação reais | L3: primário/secundário e SIGKILL | `l3_multiprocesso.sh`, `l3_primario_morre.sh`, `l3_recuperacao.sh` | Pendente de host preparado e execução real. |
| C11 | Dependência ausente não desaparece da suíte | L1: fixtures e marcadores Meson | `l1_xdp_dependencias.sh`, `l1_multiprocesso.sh`, ramos sem Python/GTest | Configuração Meson sem Python/GTest e execução dos 15 marcadores registradas; não é compilação completa nessa configuração. |
| C12 | Apuração parcial não termina como aprovação integral | L1: lacunas por privilégio/ferramenta | `l1_apuracao.sh`, retorno 77 no modo completo com lacunas | Execução sob uid 0 não demonstrada neste host. |
| C13 | Captura total preserva interface ativa/default | L1: flags, rotas IPv4/IPv6 e falhas de consulta | `scripts/tests/l1_bind_guard.sh` | Hardware não alterado; integração física pendente. |
| C14 | Documentação e inventário detectam mudanças | L1/docs: links, âncoras, contas, retratações, inventário | Verificadores em `scripts/` | Escopos e exclusões explícitos; não prova revisão semântica completa. |
| C15 | Percurso é compreendido sem orientação dos autores | Leitura independente das tarefas de aceitação | [Roteiro de leitura](leitura-aceitacao.md) | Aguardando execução por leitor independente. |

| Requisito adicional | Entrega associada | Estado de cobertura |
|---|---|---|
| RD01 Cobertura | C01–C15 e inventário de tabelas | Matriz delimitada criada; não é inventário exaustivo de todos os requisitos futuros. |
| RD02 Clareza | C15 | Roteiro pronto; leitura independente pendente. |
| RD03 Níveis de teste | C01–C14 | Níveis e limites explícitos; C10 ainda depende do host. |
| RD04 Testabilidade | C02–C10 | Novos estímulos e asserções; integração EAL pendente. |
| RD05 Acadêmica | Inventário D01–D09 e confronto de D09 | Hipótese e limites de D09 registrados; outras famílias exigem nova coleta para decisão quantitativa. |
| RD06 Segurança | C08, C13 e revisão da limpeza do supervisor | Fixtures implementadas; integração física e falhas reais de runtime não demonstradas. |
| RD07 Rigor | C01–C04, D09 | Contrato de publicação e nova campanha; não cobre todas as campanhas históricas. |
| RD08 Estrutura | C14, C15 | Índices e estados atualizados; aceitação pelo leitor pendente. |
| RD09 Prática | C05–C10 | Pipeline e supervisor controlado; runtime real e rede permanecem separados. |
| RD10 Manutenibilidade | C03, C14 | Mutações e inventário detectam mudanças selecionadas; exercício completo de manutenção ainda pendente. |
| RD11 Ferramental | C11, C12, C14 | Configuração sem Python/GTest exercitada; referências externas e execução sob uid 0 permanecem não verificadas. |

O escopo de rede física, RSS, perda e latência do receptor permanece futuro,
conforme a [política de validação](../00-visao-geral/validacao.md). Não se atribui
sucesso nem falha funcional a esse escopo por ausência da Mellanox atual.
