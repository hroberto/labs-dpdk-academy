# Roteiro de leitura de aceitação

Estado: **não executado por leitor independente**. Este documento prepara a
validação de clareza; não é seu resultado. O leitor não deve ter participado
da redação. Registrar revisão do projeto, pré-requisitos, intervenções e dúvidas.

| Tarefa | Resultado observável | Resultado do leitor |
|---|---|---|
| Seguir a primeira execução | Compilar e executar L1/L2; localizar logs | Pendente |
| Interpretar um SKIP | Identificar requisito ausente e comportamento não verificado | Pendente |
| Ler D09 | Explicar unidade, repetição, cenário e limite da comparação | Pendente |
| Localizar fila cheia | Explicar quem possui os objetos rejeitados e como termina | Pendente |
| Localizar recuperação | Separar lógica, supervisor e integração EAL | Pendente |
| Identificar próxima etapa | Distinguir memória, runtime e rede física | Pendente |

Usar [primeira execução](../00-visao-geral/execucao.md),
[inventário](inventario-dados.md) e [matriz](matriz-requisitos.md).
Para cada tarefa, anotar o comando ou trecho usado, o resultado e qualquer
intervenção necessária. Uma ambiguidade corrigida exige repetir a tarefa.
Não preencher respostas previstas como se fossem observações do leitor.
