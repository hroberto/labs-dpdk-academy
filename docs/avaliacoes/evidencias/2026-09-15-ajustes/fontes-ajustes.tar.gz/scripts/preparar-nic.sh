#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
#
# Prepara uma NIC física para o DPDK, com as travas que evitam perder a máquina.
#
# POR QUE ISTO É UM SCRIPT, E COM TANTA VERIFICAÇÃO
#
# Tirar uma placa de rede do kernel é a operação mais perigosa da trilha, e a
# falha é imediata e total: se a interface bindada for a que carrega o seu
# acesso, a sessão morre no meio do comando e a recuperação exige console
# físico. Nenhuma outra coisa que este projeto pede tem esse custo.
#
# O `dpdk-devbind.py` não protege contra isso -- ele avisa em alguns casos e
# obedece em todos. Este script recusa antes de tentar.
#
# AS TRAVAS, e o que cada uma impede:
#
#   0. modelo de driver -- placa bifurcada (Mellanox/NVIDIA) não vai para o
#      vfio-pci; bindá-la tira do PMD o driver de kernel de que ele depende.
#   1. rota default -- a interface que carrega o default gateway nunca é
#      bindada. É a trava que impede perder acesso remoto.
#   2. endereço configurado -- interface com IP ativo indica uso; exige --forcar.
#   3. IOMMU ligado -- sem ele o vfio-pci só funciona em modo no-IOMMU, que
#      remove o isolamento de DMA. O script recusa em vez de sugerir o modo
#      inseguro.
#   4. grupo IOMMU -- lista todos os membros e recusa se houver outro
#      *endpoint* além da NIC. Pontes (`pcieport`) não contam: o VFIO as
#      permite, e é por isso que um grupo "compartilhado com uma ponte" não é
#      impedimento -- premissa que este projeto já publicou errada.
#   5. PMD existe -- confere que há driver do DPDK para o par PCI, em vez de
#      bindar e descobrir depois que nenhum PMD reivindica o dispositivo.
#
# ===========================================================================
# A REGRA DE FALHA DESTE ARQUIVO, e ela é o INVERSO da dos diagnósticos
# ===========================================================================
#
# Um script de DIAGNÓSTICO, diante de um fato que não conseguiu apurar,
# DECLARA a não-apuração e segue: o leitor fica sabendo o que ficou desconhecido
# e decide. Uma TRAVA não pode fazer isso. Uma trava que não conseguiu verificar
# a condição que ela protege NÃO PODE LIBERAR -- falhar aberta é o pior modo de
# falha possível, e falhar aberta ANUNCIANDO que passou é pior ainda, porque
# empresta ao usuário uma confiança que ninguém apurou.
#
# Por isso, aqui, os dois códigos não-zero de `lib-apuracao.sh` são
# DELIBERADAMENTE tratados juntos em quase toda trava: tanto "não consegui ler"
# (NÃO APURADO) quanto "o arquivo não está lá" (AUSENTE) deixam a condição
# protegida desconhecida, e a decisão segura é a mesma -- recusar. O que muda
# entre os dois é a FRASE impressa, e ela vem de `$_APUR_MOTIVO`, que a
# biblioteca preenche com a verdade nos dois casos. Colapsar os códigos na
# DECISÃO é correto aqui; colapsar na EXPLICAÇÃO seria o defeito de volta.
#
# O ESTADO ANTERIOR, que esta versão fecha, e vale registrar porque cada linha
# abaixo é a lápide de uma trava que liberava sem ter verificado:
#
#   - TRAVA 1 comparava a interface alvo com o resultado de um comando cujo
#     erro era engolido. Sem `ip` no PATH a variável ficava vazia, a comparação
#     dava falsa, a trava LIBERAVA -- e imprimia "não carrega a rota default
#     (nenhuma)", afirmando sobre a máquina um fato que ninguém apurou. Rodado
#     contra a própria NIC do default gateway, chegava em "Todas as travas
#     passaram. Bindando...".
#   - TRAVA 3 contava grupos IOMMU com `ls | wc -l`. Sem `wc` no PATH a
#     comparação numérica errava, o `if` dava falso e a trava imprimia
#     "IOMMU ativo". Sem `ls`, contava zero e recusava pelo motivo ERRADO,
#     mandando o leitor mexer na linha de comando do kernel à toa.
#   - TRAVA 4 inteira DESAPARECIA em silêncio quando o grupo não podia ser
#     resolvido: o bloco era guardado por um teste de não-vazio. E, dentro
#     dela, um dispositivo vizinho cujo driver não pudesse ser lido era
#     publicado como "ponte ou livre, nao impede".
#   - TRAVA 0 classificava como "captura total" toda placa cujo vendor PCI não
#     pudesse ser lido -- isto é, mandava para o vfio-pci exatamente a placa
#     sobre a qual nada se sabia.
#   - TRAVA 5 dizia "nenhum PMD do DPDK reivindica <par>" quando o que havia
#     acontecido era `python3` não estar instalado.
#
# Uso:
#   ./scripts/preparar-nic.sh --status          # o que existe, sem alterar nada
#   sudo ./scripts/preparar-nic.sh 08:00.0      # binda ao vfio-pci
#   sudo ./scripts/preparar-nic.sh --desfazer 08:00.0
set -u

ACAO="bind"
FORCAR=0
BDF=""
DRIVER=""
for arg in "$@"; do
    case "$arg" in
        --status)   ACAO="status" ;;
        --desfazer) ACAO="desfazer" ;;
        --forcar)   FORCAR=1 ;;
        --driver=*) DRIVER="${arg#--driver=}" ;;
        -*)         echo "opcao desconhecida: $arg" >&2; exit 2 ;;
        *)          BDF="$arg" ;;
    esac
done

# O diretório do script sai de expansão do próprio shell, e não de `dirname`.
# Motivo apurado no repro desta rodada: com `dirname` fora do PATH o `source`
# abaixo falhava, e o script SEGUIA -- chamando funções inexistentes e
# imprimindo "ok" para travas que nunca rodaram. Um `source` que falha tem de
# abortar: sem a biblioteca não há como apurar nada, e sem apurar nada não há
# como travar coisa alguma.
AQUI=${0%/*}
[ "$AQUI" = "$0" ] && AQUI="."
# shellcheck source=lib-apuracao.sh
. "$AQUI/lib-apuracao.sh" || { echo "nao consegui carregar $AQUI/lib-apuracao.sh" >&2; exit 1; }
# shellcheck source=lib-nic.sh
. "$AQUI/lib-nic.sh" || { echo "nao consegui carregar $AQUI/lib-nic.sh" >&2; exit 1; }

erro() { printf '  RECUSADO - %s\n' "$1" >&2; }
ok()   { printf '  ok    - %s\n' "$1"; }
info() { printf '  info  - %s\n' "$1"; }

# recusar_sem_apurar <o que a trava protegia>
#
# O único destino legítimo de uma trava que não conseguiu apurar sua condição.
# Imprime o motivo que a biblioteca preencheu -- que é uma frase completa tanto
# no código NÃO APURADO quanto no AUSENTE -- e ABORTA. Nunca libera.
recusar_sem_apurar() {
    erro "$1"
    printf '           motivo: %s\n' "${_APUR_MOTIVO:-(nenhum motivo registrado -- a apuracao nem chegou a ser tentada)}" >&2
    printf '           Esta trava nao conseguiu verificar a condicao que ela protege.\n' >&2
    printf '           Recusar e o unico modo de falha seguro: liberar aqui seria\n' >&2
    printf '           afirmar, sem ter apurado, que bindar esta placa e seguro.\n' >&2
    exit 1
}

# Normaliza 08:00.0 -> 0000:08:00.0
normalizar() { case "$1" in *:*:*) printf '%s' "$1" ;; *) printf '0000:%s' "$1" ;; esac; }

# --- iface_de <bdf> ---------------------------------------------------------
#
# Devolve em $_IFACE o nome da interface de kernel do dispositivo, e distingue
# os dois vazios que a versão anterior confundia:
#
#   rc=0 com $_IFACE preenchido  -- há interface, e é esta.
#   rc=0 com $_IFACE vazio       -- FATO: o dispositivo não tem interface no
#                                   kernel. É o estado normal de uma placa já
#                                   bindada ao vfio-pci, e de todo dispositivo
#                                   PCI que não é de rede.
#   rc=1                         -- NÃO APURADO. Nada se sabe, e quem chama é
#                                   uma trava: tem de recusar.
#
# A versão anterior era um glob com `[ -e ]` dentro, e um glob que não casa nada
# é indistinguível de um diretório que este uid não pode abrir.
_IFACE=""
iface_de() {
    local bdf=$1
    _IFACE=""
    if apur_listar "/sys/bus/pci/devices/$bdf/net"; then
        [ "$_APUR_N" -eq 0 ] && return 0        # net/ existe e está vazio: fato
        _IFACE=${_APUR%%$'\n'*}                 # a primeira entrada
        return 0
    fi
    # AUSENTE: não existe .../net. Isso é um FATO sobre o dispositivo -- ele não
    # expõe interface de rede ao kernel -- e não uma falha de apuração.
    [ "$_APUR_ESTADO" = "ausente" ] && return 0
    return 1
}

# --- ifaces_da_rota_default -------------------------------------------------
#
# Todas as interfaces que carregam rota default, em $_IFACES_DEFAULT (separadas
# por espaço). rc=1 quando não se apurou.
#
# Duas mudanças de comportamento em relação à versão anterior, ambas na direção
# segura:
#
#   - antes se olhava só a PRIMEIRA linha de `ip route show default`. Numa
#     máquina com duas rotas default (duas uplinks, métricas diferentes,
#     multipath) a segunda passava despercebida, e a trava liberava a placa que
#     carregava justamente ela. Agora todas as linhas entram.
#   - antes o nome da interface era o 5º campo posicional, o que vale para
#     "default via <gw> dev <if> ..." e ERRA para "default dev <if> scope link".
#     Agora se procura o token `dev` e se lê o seguinte, que é o contrato do
#     `ip route`, não um acidente de colunas.
_IFACES_DEFAULT=""
ifaces_da_rota_default() {
    local linha
    _IFACES_DEFAULT=""
    apur_cmd ip route show default || return 1
    # Saída vazia com rc=0 é APURADO: "perguntei e não há rota default".
    while IFS= read -r linha; do
        [ -n "$linha" ] || continue
        set -- $linha
        while [ $# -gt 0 ]; do
            if [ "$1" = "dev" ] && [ $# -ge 2 ]; then
                _IFACES_DEFAULT="$_IFACES_DEFAULT $2"
            fi
            shift
        done
    done <<<"$_APUR"
    _IFACES_DEFAULT=${_IFACES_DEFAULT# }
    return 0
}

# contem_palavra <lista separada por espaco> <palavra>
contem_palavra() {
    local item
    for item in $1; do [ "$item" = "$2" ] && return 0; done
    return 1
}

# --- status: não altera nada, e é o modo padrão de inspeção ---------------
#
# Aqui vale a regra dos DIAGNÓSTICOS, não a das travas: o modo status não
# autoriza nada, então ele declara o que não apurou e continua. O que ele não
# pode fazer -- e fazia -- é imprimir "rota default sai por: " e "grupos IOMMU
# no sistema: 0" quando o que houve foi ferramenta ausente.
if [ "$ACAO" = "status" ] || [ -z "$BDF" ]; then
    echo "== NICs e o que o DPDK pode fazer com elas =="
    echo ""
    if ifaces_da_rota_default; then
        echo "  rota default sai por: ${_IFACES_DEFAULT:-(nenhuma rota default configurada)}"
    else
        echo "  rota default sai por: $_APUR"
    fi
    if apur_listar /sys/kernel/iommu_groups; then
        echo "  grupos IOMMU no sistema: $_APUR_N"
    else
        echo "  grupos IOMMU no sistema: $_APUR"
    fi
    echo ""
    echo "  modelo de driver por dispositivo:"
    if apur_listar /sys/bus/pci/devices; then
        for b in $_APUR; do
            # Só dispositivos de rede interessam aqui. A ausência de .../net é
            # fato; a não-apuração dela é o único caso em que se pula calado, e
            # nem isso: a linha do vendor abaixo denuncia.
            apur_listar "/sys/bus/pci/devices/$b/net" || continue
            if vendor_apurar "$b"; then
                vv=$_APUR
                printf '    %-14s %-10s %s\n' "$b" "$(modelo_de_driver "$vv")" \
                    "$(nome_do_vendor "$vv" | sed 's/^/-- /')"
            else
                # Sem vendor não há classificação. Imprimir "captura" aqui seria
                # exatamente a mentira que esta rodada existe para eliminar.
                printf '    %-14s %s\n' "$b" "modelo NAO APURADO: $_APUR_MOTIVO"
            fi
        done
    else
        echo "    NAO APURADO: $_APUR_MOTIVO"
    fi
    echo ""
    if apur_cmd dpdk-devbind.py --status-dev net; then
        sed 's/^/  /' <<<"$_APUR"
    else
        info "$_APUR"
    fi
    [ -z "$BDF" ] && { echo ""; echo "  Para preparar uma: sudo $0 <BDF>"; }
    exit 0
fi

BDF=$(normalizar "$BDF")

# Existência do dispositivo. `[ -e ]` respondia "não existe" tanto para ENOENT
# quanto para um ancestral não percorrível; a biblioteca caminha a cadeia e só
# afirma AUSENTE depois de provar que cada diretório do caminho era percorrível.
if ! apur_listar "/sys/bus/pci/devices/$BDF"; then
    if [ "$_APUR_ESTADO" = "ausente" ]; then
        erro "dispositivo $BDF nao existe"
        printf '           %s\n' "$_APUR_MOTIVO" >&2
    else
        recusar_sem_apurar "nao apurei se o dispositivo $BDF existe"
    fi
    exit 1
fi

# --- desfazer: devolve ao driver do kernel --------------------------------
#
# O driver de volta é DESCOBERTO, não fixo. A primeira versão desta função
# escrevia `--bind=r8169` literal: funcionava nesta máquina por coincidência, e
# religaria QUALQUER placa num driver de Realtek -- numa Intel ou Mellanox isso
# falha, e falha depois de a placa já estar fora do kernel.
#
# O `unused=` do devbind lista os drivers que o dispositivo aceita e que não
# estão em uso. É o próprio DPDK dizendo de onde a placa veio.
#
# A REVERSÃO É DA MESMA FAMÍLIA DAS TRAVAS, e por isso segue a mesma regra: uma
# reversão que não reverte é tão perigosa quanto uma trava que não trava. Ela
# falha fechado em três pontos, e os três eram falhos antes:
#   - a descoberta do driver distingue "o devbind não está instalado" de "o
#     devbind rodou e o dispositivo não tem driver de volta candidato";
#   - o `--bind` tem rc e stderr conferidos;
#   - e o resultado é VERIFICADO no sysfs depois, porque anunciar "religado"
#     com base só no código de saída do devbind é confiar num relatório em vez
#     de olhar o estado.
_DRIVER_VOLTA=""
driver_de_volta() { # <bdf> -> _DRIVER_VOLTA; rc=1 se nao apurou
    local bdf=$1 linha campo cand
    _DRIVER_VOLTA=""
    apur_cmd dpdk-devbind.py --status-dev net || return 1
    while IFS= read -r linha; do
        set -- $linha
        [ $# -ge 1 ] || continue
        [ "$1" = "$bdf" ] || continue
        for campo in "$@"; do
            case "$campo" in
                unused=*)
                    cand=${campo#unused=}
                    cand=${cand%%,*}
                    if [ -n "$cand" ] && [ "$cand" != "vfio-pci" ]; then
                        _DRIVER_VOLTA=$cand
                        return 0
                    fi
                    ;;
            esac
        done
    done <<<"$_APUR"
    # Rodou, leu a saída inteira e não há candidato: isso é FATO, e é diferente
    # de não ter conseguido perguntar. Quem chama distingue pelo rc.
    return 0
}

if [ "$ACAO" = "desfazer" ]; then
    echo "== Devolvendo $BDF ao kernel =="
    if [ -n "$DRIVER" ]; then
        alvo=$DRIVER
        info "driver de origem informado na linha de comando: $alvo"
    elif driver_de_volta "$BDF"; then
        alvo=$_DRIVER_VOLTA
        if [ -z "$alvo" ]; then
            erro "o dpdk-devbind rodou e NAO aponta driver de volta para $BDF"
            echo "         (a linha do dispositivo nao traz 'unused=' com um driver" >&2
            echo "          diferente de vfio-pci). Isto e um fato apurado, e nao" >&2
            echo "          uma falha de leitura: o modulo do driver original pode" >&2
            echo "          ter sido descarregado." >&2
            echo "         Informe explicitamente: $0 --desfazer --driver=<nome> $BDF" >&2
            exit 1
        fi
        info "driver de origem: $alvo"
    else
        erro "nao apurei o driver de origem de $BDF"
        printf '           motivo: %s\n' "$_APUR_MOTIVO" >&2
        echo "         Sem apurar isto a reversao nao pode ser tentada: religar" >&2
        echo "         num driver adivinhado e pior que nao religar." >&2
        echo "         Informe explicitamente: $0 --desfazer --driver=<nome> $BDF" >&2
        echo "         Candidatos: dpdk-devbind.py --status-dev net" >&2
        exit 1
    fi

    if ! apur_cmd dpdk-devbind.py --bind="$alvo" "$BDF"; then
        erro "falha ao religar em $alvo"
        printf '           %s\n' "$_APUR_MOTIVO" >&2
        exit 1
    fi
    # CONFERIR, e não apenas confiar no rc: o devbind pode sair 0 e o driver não
    # ter assumido. Anunciar "religado" sem olhar o sysfs é a versão benigna da
    # trava que não trava -- benigna até o dia em que a placa não voltar.
    if apur_link "/sys/bus/pci/devices/$BDF/driver"; then
        atual=${_APUR##*/}
        if [ "$atual" = "$alvo" ]; then
            ok "religado em $alvo; confira com 'ip link'"
            exit 0
        fi
        erro "o dpdk-devbind saiu 0, mas $BDF esta em '$atual' e nao em '$alvo'"
        exit 1
    fi
    erro "o dpdk-devbind saiu 0 e NAO apurei em qual driver $BDF ficou"
    printf '           motivo: %s\n' "$_APUR_MOTIVO" >&2
    printf '           Confira a mao: dpdk-devbind.py --status-dev net\n' >&2
    exit 1
fi

echo "== Preparando $BDF para o DPDK =="
echo ""

# TRAVA 0 -- o MODELO DE DRIVER, antes de tudo. Bindar uma placa bifurcada ao
# vfio-pci nao e "subotimo": tira do PMD o driver de kernel de que ele depende,
# e o dispositivo para de funcionar dos dois lados.
#
# O vendor vem pelo acessor de TRI-ESTADO de lib-nic.sh (`vendor_apurar`), e
# nunca pela função que devolve string por stdout. A razão é o defeito que esta
# rodada persegue: uma função que responde por string não tem como distinguir
# "não consegui ler o vendor" de "li, e o vendor não é 0x15b3". As duas saem
# vazias, o `case` de classificação manda vazio para o ramo `*` -- que é
# "captura total" -- e a placa sobre a qual NADA se sabe vira a que é entregue
# ao vfio-pci. Aqui os três estados chegam separados e só o apurado decide.
if ! vendor_apurar "$BDF"; then
    recusar_sem_apurar "nao apurei o vendor PCI de $BDF, e sem ele nao da para saber se a placa e de captura total (vfio-pci) ou bifurcada (mlx)"
fi
VENDOR=$_APUR
if [ "$(modelo_de_driver "$VENDOR")" = "bifurcado" ]; then
    erro "$BDF nao deve ser bindado ao vfio-pci"
    echo "" >&2
    explicar_bifurcado "$BDF" "$VENDOR" >&2
    exit 1
fi
ok "modelo de driver: captura total (vfio-pci) -- bind se aplica (vendor $VENDOR)"

# TRAVA 1 -- a mais importante: a interface que carrega o seu acesso.
#
# As duas fontes agora falham fechado. Antes, qualquer uma delas vazia fazia a
# comparação dar falsa, e uma comparação falsa LIBERAVA: o caminho preguiçoso
# era o caminho perigoso. Agora o caminho preguiçoso não existe -- não há como
# chegar na comparação sem ter os dois lados apurados.
iface_de "$BDF" || recusar_sem_apurar "nao apurei qual interface de kernel pertence a $BDF"
IFACE=$_IFACE
ifaces_da_rota_default || recusar_sem_apurar "nao apurei quais interfaces carregam rota default"

if [ -n "$IFACE" ] && contem_palavra "$_IFACES_DEFAULT" "$IFACE"; then
    erro "$IFACE carrega a rota default. Bindar isto derruba o acesso a maquina."
    echo "         Use outra NIC, ou mova a rota antes. Este script nao forca isso." >&2
    exit 1
fi
if [ -z "$IFACE" ]; then
    ok "$BDF nao tem interface no kernel (apurado), logo nao carrega rota default"
elif [ -z "$_IFACES_DEFAULT" ]; then
    ok "$IFACE nao carrega rota default (apurado: nao ha rota default nesta maquina)"
else
    ok "$IFACE nao carrega a rota default (quem carrega: $_IFACES_DEFAULT)"
fi

# TRAVA 2 -- endereço configurado indica uso.
#
# O teste continua sendo sobre IPv4, como antes. Ampliar para IPv6 pareceria
# mais rigoroso e seria pior: TODA interface up tem endereço link-local fe80::,
# então a trava passaria a barrar tudo e a ser desligada com --forcar por
# hábito -- uma trava que sempre dispara é uma trava que ninguém lê.
if [ -n "$IFACE" ]; then
    if apur_cmd ip -br addr show "$IFACE"; then
        if [[ $_APUR =~ [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+ ]]; then
            if [ "$FORCAR" -eq 0 ]; then
                erro "$IFACE tem endereco IP configurado. Use --forcar se for mesmo isso."
                exit 1
            fi
            info "$IFACE tem IP, mas --forcar foi passado"
        else
            ok "$IFACE sem endereco IPv4 configurado"
        fi
    elif [ "$FORCAR" -eq 1 ]; then
        # --forcar é uma decisão HUMANA explícita, e é o único caso em que esta
        # trava cede sem ter apurado. O que ela não faz, nem aqui, é imprimir
        # "sem endereco IP configurado": segue dizendo que não apurou.
        info "NAO APURADO se $IFACE tem IP ($_APUR_MOTIVO); --forcar foi passado, seguindo mesmo assim"
    else
        recusar_sem_apurar "nao apurei se $IFACE tem endereco IP configurado"
    fi
else
    ok "$BDF nao tem interface no kernel (apurado); nao ha endereco para conferir"
fi

# TRAVA 3 -- IOMMU. Sem ele o vfio-pci exige no-IOMMU, que remove o isolamento
# de DMA: o dispositivo passa a poder escrever em qualquer lugar da memoria.
#
# Os três desfechos são distintos de propósito, e antes os três saíam como um
# só número: diretório vazio (IOMMU realmente desligado) é FATO e recusa com o
# conselho certo; diretório inexistente é FATO e recusa dizendo outra coisa; e
# não ter conseguido listar recusa SEM inventar causa -- porque mandar alguém
# editar a linha de comando do kernel por causa de um `wc` ausente é fazer o
# leitor caçar o problema errado.
if apur_listar /sys/kernel/iommu_groups; then
    if [ "$_APUR_N" -eq 0 ]; then
        erro "IOMMU desligado. Ligue no kernel (intel_iommu=on ou amd_iommu=on)."
        echo "         (apurado: /sys/kernel/iommu_groups existe e esta VAZIO)" >&2
        echo "         Sem IOMMU o vfio-pci so funciona em modo no-IOMMU, sem" >&2
        echo "         isolamento de DMA -- exceção de laboratorio, nunca padrao." >&2
        exit 1
    fi
    ok "IOMMU ativo ($_APUR_N grupos)"
elif [ "$_APUR_ESTADO" = "ausente" ]; then
    erro "IOMMU desligado: nao ha /sys/kernel/iommu_groups neste kernel."
    echo "         Ligue com intel_iommu=on ou amd_iommu=on na linha de comando." >&2
    exit 1
else
    recusar_sem_apurar "nao apurei se o IOMMU esta ativo"
fi

# TRAVA 4 -- os outros membros do grupo. Pontes nao impedem; endpoints sim.
#
# Esta trava era a que sumia: o bloco inteiro ficava dentro de um `if` sobre o
# nome do grupo, e nome de grupo vazio -- `readlink` ausente, `basename`
# ausente, diretório não percorrível -- pulava a verificação sem uma linha de
# aviso. Silêncio é o pior relatório possível para uma trava: quem lê a saída
# não tem como distinguir "verifiquei e está tudo bem" de "não verifiquei".
if ! apur_link "/sys/bus/pci/devices/$BDF/iommu_group"; then
    recusar_sem_apurar "nao apurei a qual grupo IOMMU $BDF pertence"
fi
GRUPO=${_APUR##*/}
if ! apur_listar "/sys/kernel/iommu_groups/$GRUPO/devices"; then
    recusar_sem_apurar "nao apurei quais dispositivos compartilham o grupo IOMMU $GRUPO com $BDF"
fi
MEMBROS=$_APUR
bloqueadores=""
for d in $MEMBROS; do
    [ "$d" = "$BDF" ] && continue
    if apur_link "/sys/bus/pci/devices/$d/driver"; then
        drv=${_APUR##*/}
    elif [ "$_APUR_ESTADO" = "ausente" ]; then
        # Não há symlink `driver`: o dispositivo está sem driver ligado. FATO, e
        # é o caso "livre" -- não impede.
        drv=""
    else
        # NÃO APURADO. Antes isto caía no mesmo ramo do "livre" e era publicado
        # como "ponte ou livre, nao impede": um vizinho de grupo sobre o qual
        # nada se sabia era anunciado como inofensivo. Um endpoint desconhecido
        # no grupo é exatamente o que esta trava existe para pegar.
        erro "grupo $GRUPO: nao apurei o driver de $d"
        printf '           motivo: %s\n' "$_APUR_MOTIVO" >&2
        bloqueadores="$bloqueadores $d"
        continue
    fi
    case "$drv" in
        pcieport|pci-stub|vfio-pci|"")
            info "grupo $GRUPO: $d (${drv:-sem driver}) - ponte ou livre, nao impede" ;;
        *)
            erro "grupo $GRUPO: $d usa '$drv' e nao e ponte"
            bloqueadores="$bloqueadores $d" ;;
    esac
done
if [ -n "$bloqueadores" ]; then
    echo "         Todo endpoint do grupo IOMMU vai junto para o vfio-pci." >&2
    # Antes esta linha citava `$d`, a variável do laço -- isto é, o ÚLTIMO
    # membro visitado, que quase nunca era o que bloqueou. Agora nomeia a lista
    # que de fato bloqueou.
    printf '         Verifique o que faz cada um destes antes de continuar:%s\n' "$bloqueadores" >&2
    exit 1
fi
ok "grupo IOMMU $GRUPO tem a NIC como unico endpoint"

# TRAVA 5 -- existe PMD para este par PCI?
#
# Esta é a única do conjunto que NÃO recusa: não haver PMD não estraga a
# máquina, apenas faz o bind ser inútil. Por isso ela é informativa -- e por
# isso mesmo a frase importa. Antes ela dizia "nenhum PMD do DPDK reivindica
# <par>" em três situações diferentes: quando de fato nenhum reivindicava,
# quando `python3` não estava instalado, e quando o diretório dos PMDs não
# pôde ser lido. As duas últimas são não-apuração vendida como veredito, e
# mandam o leitor procurar `--vdev` para um problema que não é esse.
if apur_cmd lspci -n -s "${BDF#0000:}"; then
    PAR=""
    while IFS= read -r linha; do
        set -- $linha
        [ $# -ge 3 ] && { PAR=$3; break; }
    done <<<"$_APUR"
    if [ -z "$PAR" ]; then
        info "NAO APURADO: o lspci rodou e nao devolveu o par vendor:device de $BDF"
    else
        ven=${PAR%%:*}; dev=${PAR##*:}
        achou=""
        examinados=0
        busca_falhou=""
        for so in /usr/lib/*/dpdk/pmds-*/librte_net_*.so; do
            apur_listar "${so%/*}" || continue      # prova que o diretório é legível
            examinados=$((examinados + 1))
            # `python3` roda por apur_cmd para que "não está no PATH" e "rodou e
            # respondeu não" parem de ser a mesma coisa. O código 1 deste
            # programa é INFORMAÇÃO -- "procurei neste .so e o par não está lá"
            # --, e é o caso previsto no contrato em que o chamador olha
            # $_APUR_RC e decide por conta própria em vez de aceitar o padrão.
            if apur_cmd python3 - "$so" "$ven" "$dev" <<'EOF'
import sys
data=open(sys.argv[1],'rb').read()
v=int(sys.argv[2],16).to_bytes(2,'little'); d=int(sys.argv[3],16).to_bytes(2,'little')
sys.exit(0 if v+d in data else 1)
EOF
            then
                achou=${so##*/}
                break
            fi
            [ "$_APUR_RC" = "1" ] && continue
            busca_falhou=$_APUR_MOTIVO
            break
        done
        if [ -n "$achou" ]; then
            ok "PMD encontrado para $PAR: $achou"
        elif [ -n "$busca_falhou" ]; then
            info "NAO APURADO se ha PMD para $PAR: $busca_falhou"
            info "isto NAO quer dizer que nao ha PMD -- a busca e que nao foi feita"
        elif [ "$examinados" -eq 0 ]; then
            info "NAO APURADO se ha PMD para $PAR: nenhum objeto librte_net_*.so"
            info "legivel em /usr/lib/*/dpdk/pmds-*/ (DPDK sem PMDs instalados, ou"
            info "instalado fora deste caminho)"
        else
            info "nenhum dos $examinados PMDs examinados reivindica $PAR — o bind"
            info "funciona, mas nenhuma aplicacao vai enxergar a porta. Veja --vdev."
        fi
    fi
else
    info "NAO APURADO o par vendor:device de $BDF: $_APUR_MOTIVO"
    info "sem o par nao da para procurar PMD; isto nao e 'nao ha PMD'"
fi

echo ""
echo "  Todas as travas passaram. Bindando..."
if ! apur_cmd modprobe vfio-pci; then
    erro "modprobe vfio-pci falhou"
    printf '           %s\n' "$_APUR_MOTIVO" >&2
    exit 1
fi
# Derrubar a interface antes do bind é parte da operação, não enfeite: falhar
# aqui significa que falta privilégio ou falta a ferramenta, e os dois são
# impedimento para o passo seguinte, que é o destrutivo. Antes o rc era
# descartado e o script seguia para o bind assim mesmo.
if [ -n "$IFACE" ] && ! apur_cmd ip link set "$IFACE" down; then
    erro "nao consegui derrubar $IFACE antes do bind"
    printf '           %s\n' "$_APUR_MOTIVO" >&2
    exit 1
fi
if ! apur_cmd dpdk-devbind.py --bind=vfio-pci "$BDF"; then
    erro "dpdk-devbind falhou"
    printf '           %s\n' "$_APUR_MOTIVO" >&2
    exit 1
fi

# Conferir no sysfs, pelo mesmo motivo da reversão: o anúncio final é a única
# coisa que o usuário lê, e ele não pode ser a repetição do que o devbind disse.
echo ""
if apur_link "/sys/bus/pci/devices/$BDF/driver"; then
    driver_final=${_APUR##*/}
    if [ "$driver_final" = "vfio-pci" ]; then
        ok "$BDF agora usa vfio-pci"
    else
        erro "o dpdk-devbind saiu 0, mas $BDF esta em '$driver_final'"
        exit 1
    fi
else
    erro "o dpdk-devbind saiu 0 e NAO apurei em qual driver $BDF ficou"
    printf '           motivo: %s\n' "$_APUR_MOTIVO" >&2
    exit 1
fi
echo ""
echo "  Confira:  dpdk-devbind.py --status-dev net"
echo "  Teste:    dpdk-testpmd -l 0-1 -- --total-num-mbufs=2048 --stats-period=1"
echo "  Desfazer: sudo $0 --desfazer $BDF"
echo ""
