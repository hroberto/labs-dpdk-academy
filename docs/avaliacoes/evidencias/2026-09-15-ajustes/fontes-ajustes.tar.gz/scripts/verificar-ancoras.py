#!/usr/bin/env python3
"""Confere se âncoras de linha ainda apontam para o alvo certo.

POR QUE ESTE SCRIPT EXISTE

Links do tipo `arquivo.c#L227` levam o leitor direto ao código que produziu um
número — leitura muito mais fluida que "procure a função no arquivo". O preço é
que números de linha mudam quando o código muda, e um link desatualizado não
quebra: ele aponta em silêncio para o trecho errado, que é pior que apontar para
lugar nenhum.

Este verificador elimina esse risco. A convenção que ele exige é simples: o
**texto do link** deve ser o nome do símbolo, e a linha apontada deve conter
esse nome. Assim:

    [`m_spinlock`](medicoes/custo-espera.c#L227)

Se `m_spinlock` deixar de estar na linha 227, o script acusa e diz onde ela foi
parar — basta corrigir o número.

POR QUE ELE PASSOU A VARRER TAMBÉM COMENTÁRIOS DE .sh E .py

Incidente: `scripts/tests/l1_xdp.sh` citava `trilha/04-projeto-final/README.md`
em duas linhas de comentário (`:43-45` e `:69-73`) e as duas envelheceram **no
mesmo conjunto de mudanças que as criou**. Nada alarmou, porque este script só
percorria arquivos `.md`. A regra do projeto diz que âncora de linha é
verificável; metade das âncoras mora em comentário de script, e essa metade não
era verificada. Um verificador com um furo desse tamanho dá uma garantia que não
tem — que é justamente o defeito que o projeto persegue: silêncio lido como
"está tudo certo".

O CONTRATO DA ÂNCORA EM COMENTÁRIO

1. Só conta o que está **dentro de comentário** (`#` em `.sh`, comentário ou
   docstring em `.py`). Código não é documentação, e `awk -F: '$1 == k'` ou
   `sed -n '43,45p'` não são âncoras.
2. A forma é `caminho/arquivo.ext:N` ou `caminho/arquivo.ext:N-M`, com extensão
   conhecida. Exigir a extensão elimina de saída os falsos positivos clássicos:
   `12:34:56`, `$1 == k`, `chave:valor`.
3. Verificar que a linha EXISTE é fraco demais: âncora aponta para CONTEÚDO.
   A checagem forte segue a mesma ideia da versão `.md` — lá o texto do link diz
   o que se espera achar na linha; aqui, o que se espera achar é o vocabulário
   do próprio trecho que cita. Se o comentário e o código que ele introduz
   compartilham tokens distintivos (`r8169`, `NETDEV_XDP_ACT_BASIC`, `0x0e`) com
   o alvo, a âncora é confirmada; se esses tokens migraram para OUTRO ponto do
   arquivo, ela é acusada, com o número novo. Nada precisa ser duplicado à mão.
4. Falso positivo em ferramenta de verificação é pior que ausência de
   ferramenta: quem é acordado à toa desliga o alarme. Por isso o script só
   ACUSA quando consegue apontar um lugar estritamente melhor. Quando não
   consegue decidir, ele não inventa veredito: lista a âncora em "não
   verificadas" **dizendo o que faltou**. "Não sei" não é "não".
5. Um alvo que não resolve tem DUAS causas, e confundi-las é o defeito de
   sempre: `linux/netlink.h:25` é cabeçalho do sistema (nada a conferir, entra
   em "não verificadas"), enquanto um `trilha/…md` do projeto que sumiu é
   FALHA. A separação é o primeiro segmento do caminho: se ele nomeia um
   diretório de topo do projeto, o alvo deveria existir.
6. Não há como distinguir uma âncora de uma MENÇÃO a uma âncora: um comentário
   que escreva `docs/x.md` seguido de dois-pontos e um número, só para falar do
   formato, será cobrado como citação — e as duas linhas acima já apanharam
   disso, na primeira execução deste texto contra a própria árvore. É o lado
   conservador certo: na dúvida, verificar. Para citar o formato sem ser
   cobrado, escreva "docs/x.md, linhas 3-5".

O QUE ELE NÃO VERIFICA (e diz que não verifica)

Âncoras dentro de heredoc, arquivos que não tokenizam, alvos de fora da árvore e
trechos sem token distintivo em comum. Todos aparecem no relatório, nomeados,
sem entrar na conta das confirmadas. O resumo FECHA — total == confirmadas +
desatualizadas + não verificadas — justamente para que a diferença não possa ser
lida como "o resto está ok".

    ./scripts/verificar-ancoras.py             # varre a árvore
    ./scripts/verificar-ancoras.py --autoteste # verifica o verificador
"""
import io
import os
import re
import sys
import tokenize

IGNORAR = {".git", "build", "subprojects", "__pycache__", ".venv", "node_modules"}

# --- âncoras em Markdown -----------------------------------------------------
# [`simbolo`](caminho#L123)  ou  [texto](caminho#L123-L130)
PADRAO_MD = re.compile(r"\[`?([^\]`]+)`?\]\(([^)#]+)#L(\d+)(?:-L\d+)?\)")

# --- âncoras em comentário ---------------------------------------------------
# Extensões aceitas depois do nome do arquivo. A lista é fechada de propósito:
# é ela que separa uma âncora de um `chave:valor` qualquer.
EXTENSOES = "md|c|h|cpp|hpp|cc|py|sh|build|txt|ya?ml|json|rst|ini|cfg"
# (?<![\w/.-]) evita casar o final de um token maior; (?![\w:-]) evita casar
# `arquivo.h:12:34` (saída de compilador) e `:43-45x`.
PADRAO_COMENTARIO = re.compile(
    r"(?<![\w/.-])((?:[\w.+-]+/)*[\w.+-]+\.(?:" + EXTENSOES + r"))"
    r":(\d+)(?:-(\d+))?(?![\w:-])"
)

# Tokens que valem como evidência de conteúdo. Só entram os "code-ish": com
# maiúscula, dígito, `_`, `-` ou `.` no meio. Prosa comum ("publicado",
# "medidos", "numeros") ficaria de fora do inglês/português técnico e geraria
# casamento por acaso entre dois textos em português — exatamente o ruído que
# faria alguém desligar o verificador.
PADRAO_TOKEN = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_.+-]*[A-Za-z0-9_]|[A-Za-z0-9_]{2,}")
# Um token só é evidência se aparecer em POUCAS linhas do alvo. `xdp` aparece em
# 40 linhas do README e não localiza nada; `mlx5_core` aparece em duas e localiza.
MAX_LINHAS_POR_TOKEN = 5
# Só acusa migração quando o lugar novo é claramente melhor: zero token no lugar
# citado e pelo menos este tanto no lugar apontado.
MIN_TOKENS_PARA_ACUSAR = 2
# Quantas linhas depois do comentário entram no contexto (o bloco de código que
# o comentário introduz costuma ser o que a âncora documenta).
MAX_LINHAS_CONTEXTO = 20


def eh_codeish(tok):
    """Token serve de evidência? Precisa de maiúscula, dígito ou separador interno."""
    return any(c.isupper() or c.isdigit() or c in "_.-+" for c in tok)


def tokens_de(texto):
    return {t for t in PADRAO_TOKEN.findall(texto) if len(t) >= 3 and eh_codeish(t)}


# --- extração de comentários -------------------------------------------------

def comentarios_py(caminho, linhas):
    """Comentários `#` e docstrings de um .py, via tokenize (exato, não heurístico).

    Erro de tokenização NÃO é engolido: vira uma pendência nomeada, porque um
    arquivo que não foi lido é um arquivo cujas âncoras não foram verificadas.
    """
    trechos, pendencias = [], []
    # Uma string tripla só é DOCSTRING se for uma instrução inteira -- o primeiro
    # token de uma linha lógica. `ISCAS_SH = """..."""` é DADO, e dado não é
    # documentação. Incidente: na primeira execução contra a árvore real, as
    # âncoras FALSAS do autoteste deste próprio script (que apontam para um
    # `docs/alvo.md` existente só dentro da fixture temporária) foram lidas como
    # âncoras de verdade e viraram 5 acusações falsas. Uma ferramenta que grita
    # ferramenta que alguém desliga. O token anterior separa os dois casos sem
    # ambiguidade: depois de `=` vem dado; depois de NEWLINE/INDENT vem docstring.
    ABRE_INSTRUCAO = {tokenize.NEWLINE, tokenize.NL, tokenize.INDENT,
                      tokenize.DEDENT, tokenize.ENCODING}
    try:
        with open(caminho, "rb") as fh:
            anterior = tokenize.ENCODING
            for tok in tokenize.tokenize(fh.readline):
                if tok.type == tokenize.COMMENT:
                    trechos.append((tok.start[0], tok.string))
                    continue
                if (tok.type == tokenize.STRING
                        and tok.string.lstrip("rRbBuUfF")[:3] in (chr(34) * 3, chr(39) * 3)
                        and anterior in ABRE_INSTRUCAO):
                    # docstring: cada linha entra com o número dela
                    for i, l in enumerate(tok.string.split("\n")):
                        trechos.append((tok.start[0] + i, l))
                anterior = tok.type
    except (tokenize.TokenError, SyntaxError, UnicodeDecodeError) as e:
        # nao se sabe QUANTAS ancoras havia -- por isso `False`: entra no
        # relatorio, mas nao inventa um numero para o total.
        pendencias.append((False, f"{caminho}: NAO tokenizou ({type(e).__name__}: {e});"
                                  " âncoras deste arquivo NAO foram verificadas"))
    return trechos, pendencias


INICIO_HEREDOC = re.compile(r"<<-?\s*(['\"]?)([A-Za-z_][A-Za-z0-9_]*)\1(?P<resto>.*)$")
# `$(( valor + (1 << desloc) ))` é deslocamento de bits, NÃO abertura de heredoc.
# Incidente concreto: em `scripts/xdp-zerocopy.sh` o scanner leu `<< desloc` como
# heredoc, nunca achou o terminador e ENGOLIU todos os comentários dali até o fim
# do arquivo -- centenas de linhas não verificadas, contadas no relatório como se
# estivessem em ordem. Foi exatamente o defeito que este verificador existe para
# não cometer. O que salvou foi a pendência "heredoc sem terminador": um erro que
# se anuncia é recuperável; um que se cala, não.
ARITMETICA = re.compile(r"\$?\(\(.*?\)\)")
# Depois da palavra de um heredoc de verdade só vem fim de linha, outro
# redirecionamento ou um separador -- nunca `)`, que é o que fecha a aritmética.
DEPOIS_DA_PALAVRA = re.compile(r"\s*([>|;&#]|$)")


def comentarios_sh(caminho, linhas):
    """Comentários `#` de um .sh, com estado de aspas e heredoc.

    Não existe tokenizer de shell na biblioteca padrão, então o scanner abaixo é
    aproximado — e por isso ele PREFERE não enxergar a enxergar errado. O corpo
    de heredoc não é código nem comentário: se houver âncora lá dentro, ela é
    reportada como não verificada, com o motivo, em vez de ser ignorada em
    silêncio.
    """
    trechos, pendencias = [], []
    em_aspas_simples = em_aspas_duplas = False
    terminador = None
    for n, linha in enumerate(linhas, 1):
        if terminador is not None:
            if linha.strip() == terminador:
                terminador = None
            elif PADRAO_COMENTARIO.search(linha):
                pendencias.append((True, f"{caminho}:{n}: âncora dentro de heredoc"
                                         f" (<<{terminador}); NAO verificada"))
            continue
        i, n_chars = 0, len(linha)
        inicio_comentario = None
        while i < n_chars:
            c = linha[i]
            if em_aspas_simples:
                if c == "'":
                    em_aspas_simples = False
            elif em_aspas_duplas:
                if c == "\\":
                    i += 1
                elif c == '"':
                    em_aspas_duplas = False
            elif c == "\\":
                i += 1
            elif c == "'":
                em_aspas_simples = True
            elif c == '"':
                em_aspas_duplas = True
            elif c == "#" and (i == 0 or linha[i - 1] in " \t;&|(`"):
                inicio_comentario = i
                break
            i += 1
        codigo = linha[:inicio_comentario] if inicio_comentario is not None else linha
        if inicio_comentario is not None:
            trechos.append((n, linha[inicio_comentario:]))
        # `<<<` é here-string; `$(( a << b ))` é deslocamento. Nenhum dos dois
        # abre heredoc, e confundi-los cega o scanner do resto do arquivo.
        codigo_sem_aritmetica = ARITMETICA.sub(" ", codigo)
        for m in INICIO_HEREDOC.finditer(codigo_sem_aritmetica):
            if codigo_sem_aritmetica[m.start() + 2:m.start() + 3] == "<":
                continue  # here-string
            if not DEPOIS_DA_PALAVRA.match(m.group("resto")):
                continue  # a palavra não encerra o comando: não é heredoc
            terminador = m.group(2)
    if terminador is not None:
        pendencias.append((False, f"{caminho}: heredoc <<{terminador} sem terminador até"
                                  " o fim do arquivo; parte das âncoras pode NAO ter sido"
                                  " verificada"))
    return trechos, pendencias


# --- resolução de alvo -------------------------------------------------------

def resolver(raiz, base, caminho):
    """Resolve o alvo relativo ao arquivo que cita, depois à raiz do projeto.

    Devolve (caminho_real, motivo_da_falha). Um alvo que não resolve pode ser
    duas coisas MUITO diferentes, e confundi-las é o defeito que este projeto
    persegue: arquivo do projeto que sumiu (falha real) ou cabeçalho de fora da
    árvore, como `linux/netlink.h:25` (nada a verificar aqui). A separação é
    feita pelo primeiro segmento: se ele nomeia um diretório de topo do
    projeto, o alvo deveria existir.
    """
    for cand in (os.path.normpath(os.path.join(base, caminho)),
                 os.path.normpath(os.path.join(raiz, caminho))):
        if os.path.isfile(cand):
            return cand, None
    topo = caminho.replace("\\", "/").split("/")[0]
    if os.path.isdir(os.path.join(raiz, topo)) and topo not in (".", ".."):
        return None, "alvo inexistente (o caminho começa dentro do projeto)"
    return None, "fora da árvore do projeto"


# --- checagem de conteúdo ----------------------------------------------------

def contexto(linhas, n_ancora):
    """Bloco de comentário que contém a âncora + o código que ele introduz.

    É daqui que sai a evidência da checagem forte, e a escolha do recorte é
    deliberada: uma âncora quase sempre apresenta o trecho logo abaixo dela
    (`# a tabela publicada em X:69-73` seguido dos cinco `check` que repetem os
    números da tabela). É esse vocabulário compartilhado que localiza a âncora
    no alvo, sem obrigar ninguém a duplicar texto à mão.

    Limitação declarada: em docstring de `.py` não existe bloco `#`, então o
    recorte cai para a linha da âncora e o que vier até a primeira linha em
    branco. Fica mais pobre em evidência — e o efeito disso é a âncora terminar
    em "não verificada", nunca em acusação falsa.
    """
    i = n_ancora - 1
    ini = i
    while ini > 0 and linhas[ini - 1].lstrip().startswith("#"):
        ini -= 1
    fim = i
    while fim + 1 < len(linhas) and linhas[fim + 1].lstrip().startswith("#"):
        fim += 1
    # segue pelo código até a primeira linha em branco
    j = fim + 1
    while j < len(linhas) and linhas[j].strip() != "" and j - ini < MAX_LINHAS_CONTEXTO:
        j += 1
    return "\n".join(linhas[ini:j])


def conferir_conteudo(texto_contexto, alvo_linhas, n1, n2, caminho_citado):
    """Devolve (veredito, detalhe).

    veredito: "ok" | "migrou" | "indeterminado"
    """
    toks = tokens_de(texto_contexto)
    # o próprio caminho citado não é evidência de nada
    toks -= tokens_de(caminho_citado)
    if not toks:
        return "indeterminado", "o trecho que cita não tem token distintivo para comparar"

    ocorrencias = {}
    for t in toks:
        onde = [i + 1 for i, l in enumerate(alvo_linhas) if t in l]
        if 1 <= len(onde) <= MAX_LINHAS_POR_TOKEN:
            ocorrencias[t] = set(onde)
    if not ocorrencias:
        return ("indeterminado",
                "nenhum token distintivo do trecho aparece no alvo"
                f" (comparados {len(toks)}); só a existência da linha foi conferida")

    def pontuar(a, b):
        faixa = set(range(a, b + 1))
        return {t for t, onde in ocorrencias.items() if onde & faixa}

    achados = pontuar(n1, n2)
    if achados:
        return "ok", ", ".join(sorted(achados)[:3])

    # Onde os tokens estao AGORA. Empates sao mantidos e mostrados: dizer "e
    # aqui" quando ha tres candidatos igualmente fortes seria a mesma
    # sobre-afirmacao que este projeto combate. O veredito e "saiu de la"; o
    # destino e PISTA, e vem rotulado como tal.
    largura = n2 - n1
    melhor = 0
    candidatos = []
    for a in range(1, len(alvo_linhas) - largura + 1):
        pts = pontuar(a, a + largura)
        if len(pts) > melhor:
            melhor, candidatos = len(pts), [(a, pts)]
        elif len(pts) == melhor and melhor > 0 and a > candidatos[-1][0] + largura:
            candidatos.append((a, pts))  # so janelas que nao se sobrepoem
    if melhor >= MIN_TOKENS_PARA_ACUSAR:
        faixas = [f"{a}" if largura == 0 else f"{a}-{a + largura}"
                  for a, _ in candidatos[:3]]
        toks = sorted(set().union(*(p for _, p in candidatos[:3])))
        resto = " (e outros)" if len(candidatos) > 3 else ""
        return "migrou", (f"{', '.join(toks[:4])} nao esta(o) ali; aparece(m) em :"
                          + ", :".join(faixas) + resto + " -- PISTA, confira")
    return ("indeterminado",
            "os tokens do trecho não aparecem na linha citada nem, com força"
            f" suficiente, em outro ponto do alvo (melhor casamento: {melhor} token)")


# --- varredura ---------------------------------------------------------------

def verificar(raiz="."):
    falhas, pendencias = [], []
    externas = {}
    total_md = total_comentario = confirmadas = 0

    for base, dirs, arquivos in os.walk(raiz):
        dirs[:] = [d for d in dirs if d not in IGNORAR]
        for nome in sorted(arquivos):
            doc = os.path.join(base, nome)
            if nome.endswith(".md"):
                texto = open(doc, encoding="utf-8").read()
                for simbolo, caminho, linha in PADRAO_MD.findall(texto):
                    total_md += 1
                    alvo = os.path.normpath(os.path.join(base, caminho))
                    if not os.path.exists(alvo):
                        falhas.append(f"{doc}: alvo inexistente -> {caminho}")
                        continue
                    linhas = open(alvo, encoding="utf-8").read().split("\n")
                    n = int(linha)
                    if n < 1 or n > len(linhas):
                        falhas.append(f"{doc}: linha {n} fora de {caminho} ({len(linhas)} linhas)")
                        continue
                    if simbolo not in linhas[n - 1]:
                        onde = [i + 1 for i, l in enumerate(linhas) if simbolo in l]
                        sugestao = (f" (está na linha {onde[0]})" if onde
                                    else " (não encontrado no arquivo)")
                        falhas.append(f"{doc}: '{simbolo}' NAO esta em {caminho}:{n}{sugestao}\n"
                                      f"      linha {n} contem: {linhas[n - 1].strip()[:60]}")
                        continue
                    confirmadas += 1

            elif nome.endswith((".sh", ".py")):
                try:
                    linhas = open(doc, encoding="utf-8").read().split("\n")
                except UnicodeDecodeError as e:
                    pendencias.append((False, f"{doc}: NAO foi lido como UTF-8 ({e});"
                                              " âncoras deste arquivo NAO foram verificadas"))
                    continue
                extrator = comentarios_py if nome.endswith(".py") else comentarios_sh
                trechos, pend = extrator(doc, linhas)
                pendencias.extend(pend)
                total_comentario += sum(1 for conta, _ in pend if conta)
                for n_linha, texto_comentario in trechos:
                    for caminho, a, b in PADRAO_COMENTARIO.findall(texto_comentario):
                        total_comentario += 1
                        origem = f"{doc}:{n_linha}"
                        faixa = f"{a}-{b}" if b else a
                        alvo, motivo = resolver(raiz, base, caminho)
                        if alvo is None:
                            if motivo.startswith("alvo inexistente"):
                                falhas.append(f"{origem}: {caminho} -> {motivo}")
                            else:
                                externas.setdefault(doc, []).append(caminho)
                            continue
                        alvo_linhas = open(alvo, encoding="utf-8").read().split("\n")
                        n1, n2 = int(a), int(b) if b else int(a)
                        if n1 < 1 or n2 < n1 or n2 > len(alvo_linhas):
                            falhas.append(f"{origem}: {caminho}:{a}{'-' + b if b else ''}"
                                          f" fora do arquivo ({len(alvo_linhas)} linhas)")
                            continue
                        veredito, detalhe = conferir_conteudo(
                            contexto(linhas, n_linha), alvo_linhas, n1, n2, caminho)
                        if veredito == "ok":
                            confirmadas += 1
                        elif veredito == "migrou":
                            falhas.append(f"{origem}: âncora {caminho}:{faixa} DESATUALIZADA"
                                          f" -- {detalhe}\n"
                                          f"      linha {n1} contem: "
                                          f"{alvo_linhas[n1 - 1].strip()[:60]}")
                        else:
                            pendencias.append((True, f"{origem}: {caminho}:{faixa} existe,"
                                                     f" mas o CONTEUDO nao foi conferido"
                                                     f" -- {detalhe}"))

    # Ancoras para cabecalhos de fora da arvore (linux/netlink.h:25 e afins) sao
    # dezenas em xdp-features.py. Lista-las uma a uma afogaria as duas linhas
    # que importam -- e um relatorio que ninguem le e um relatorio desligado.
    # Agrupa-se por arquivo, mas NAO se omite: o numero e os alvos ficam
    # visiveis, porque "nao verifiquei 23 ancoras" e informacao, e some-las ao
    # total de aprovadas seria a mentira que este verificador existe para nao
    # contar.
    n_externas = sum(len(v) for v in externas.values())
    for doc, alvos in sorted(externas.items()):
        distintos = sorted(set(alvos))
        pendencias.append((False, f"{doc}: {len(alvos)} âncoras para alvos fora da árvore"
                                  f" ({', '.join(distintos)}) -- NAO verificadas"
                                  " (arquivo do sistema, não do projeto)"))

    if falhas:
        print("\n  âncoras desatualizadas:")
        for f in falhas:
            print(f"  {f}")
    if pendencias:
        # Estas NAO sao aprovacoes. Sao o que o verificador admite nao ter
        # apurado -- e o motivo. Omiti-las transformaria "nao sei" em "nao ha
        # problema", que e o defeito que este projeto persegue.
        print("\n  âncoras NAO verificadas (o verificador não conseguiu apurar):")
        for _, texto in pendencias:
            print(f"  {texto}")
    # O resumo tem que FECHAR: confirmadas + desatualizadas + nao verificadas ==
    # total. Um resumo que nao fecha e um convite a assumir que a diferenca
    # esta ok -- de novo, silencio lido como aprovacao. As agrupadas contam uma
    # a uma; as pendencias que nao correspondem a uma ancora identificada
    # (arquivo que nem foi lido) ficam de fora da conta e do total, e aparecem
    # so no relatorio, porque ali o numero real e desconhecido.
    nao_verificadas = n_externas + sum(1 for conta, _ in pendencias if conta)
    print(f"\n  {total_md} âncoras em .md + {total_comentario} em comentários de .sh/.py"
          f" = {total_md + total_comentario}; {confirmadas} confirmadas,"
          f" {len(falhas)} desatualizadas, {nao_verificadas} não verificadas")
    return len(falhas)


# --- autoteste ---------------------------------------------------------------
#
# POR QUE UM VERIFICADOR PRECISA SE VERIFICAR
#
# Este script ganhou a varredura de `.sh`/`.py` porque duas âncoras morreram sem
# alarme: a ferramenta de verificação tinha um furo e ninguém sabia. A lição não
# é "corrigir o furo", é "o furo não era detectável". As asserções abaixo tornam
# o contrato EXECUTÁVEL: se alguém mexer no regex e as iscas de falso positivo
# passarem a casar, ou se a checagem de conteúdo parar de acusar a âncora morta,
# isto falha aqui e não seis meses depois, em silêncio.
#
#   ./scripts/verificar-ancoras.py --autoteste

ISCAS_SH = """#!/usr/bin/env bash
# Iscas de falso positivo -- NENHUMA destas linhas contem uma ancora:
# um timestamp 12:34:56, uma porta http://host:8080, um erro alvo.md:12:34
campo() { awk -F: -v k="$1" '$1 == k { print $2 }'; }   # $1 == k nao e ancora
trecho() { sed -n '43,45p' docs/alvo.md; }              # sed -n nao e ancora
chave="docs/alvo.md:80"                                 # string, nao comentario
cat <<'EOF'
# docs/alvo.md:99 dentro de heredoc
EOF
# ANCORA VIVA: a tabela publicada em docs/alvo.md:3-5
check "r8169"     0
check "mlx5_core" 59
# ANCORA MORTA: docs/alvo.md:1-2 deveria conter a tabela
check "r8169"     0
check "mlx5_core" 59
# ANCORA FORA DA ARVORE: linux/netlink.h:25 -- nada a conferir aqui
# ANCORA FORA DO ARQUIVO: docs/alvo.md:900
"""

ALVO_MD = """linha 1
linha 2
| driver | simbolos |
| `r8169` | 0 |
| `mlx5_core` | 59 |
linha 6
"""


def autoteste():
    import contextlib
    import tempfile

    falhou = 0

    def exigir(condicao, descricao):
        nonlocal falhou
        print(f"  [{'ok' if condicao else 'FALHA'}] {descricao}")
        if not condicao:
            falhou += 1

    with tempfile.TemporaryDirectory() as tmp:
        os.makedirs(os.path.join(tmp, "docs"))
        with open(os.path.join(tmp, "docs", "alvo.md"), "w", encoding="utf-8") as fh:
            fh.write(ALVO_MD)
        with open(os.path.join(tmp, "iscas.sh"), "w", encoding="utf-8") as fh:
            fh.write(ISCAS_SH)
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            n_falhas = verificar(tmp)
        saida = buf.getvalue()

    print(saida.rstrip())
    print()
    # 1. As iscas nao podem virar ancora. Falso positivo aqui e o defeito que
    #    faz alguem desligar o verificador.
    for isca in ("12:34:56", "host:8080", "alvo.md:12:34", "43,45p", "alvo.md:80"):
        exigir(isca not in saida, f"isca ignorada: {isca}")
    # 2. A ancora correta e CONFIRMADA -- um verificador que so sabe acusar nao
    #    prova nada sobre as que passaram.
    exigir("1 confirmadas" in saida, "âncora viva (docs/alvo.md:3-5) confirmada")
    # 3. A ancora morta e acusada, com a pista de para onde o conteudo foi.
    exigir("docs/alvo.md:1-2 DESATUALIZADA" in saida, "âncora morta acusada")
    exigir(":4-5" in saida, "acusação diz onde o conteúdo está agora")
    # 4. Heredoc e alvo externo nao sao aprovados nem acusados: sao NOMEADOS.
    exigir("dentro de heredoc" in saida, "âncora em heredoc declarada não verificada")
    exigir("fora da árvore" in saida, "linux/netlink.h declarado fora da árvore")
    exigir("linux/netlink.h" in saida and "inexistente" not in saida,
           "alvo do sistema NAO vira falha (não sei != não)")
    # 5. Linha fora do arquivo e falha dura: nao ha ambiguidade a preservar.
    exigir("docs/alvo.md:900 fora do arquivo" in saida, "linha inexistente acusada")
    # 6. So as duas de verdade falham (a morta e a fora do arquivo).
    exigir(n_falhas == 2, f"exatamente 2 falhas duras (obtido: {n_falhas})")
    # 7. O resumo tem que FECHAR: confirmadas + desatualizadas + não verificadas.
    m = re.search(r"= (\d+); (\d+) confirmadas, (\d+) desatualizadas, (\d+) não", saida)
    exigir(m is not None and int(m.group(1)) == sum(int(m.group(i)) for i in (2, 3, 4)),
           "o resumo fecha (total == confirmadas + desatualizadas + não verificadas)")

    print(f"\n  autoteste: {falhou} asserção(ões) falharam")
    return falhou


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--autoteste":
        sys.exit(1 if autoteste() else 0)
    sys.exit(1 if verificar(sys.argv[1] if len(sys.argv) > 1 else ".") else 0)
