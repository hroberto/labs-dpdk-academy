# SPDX-License-Identifier: MIT
#
# Classificação do MODELO DE DRIVER de uma NIC, para o DPDK.
#
# POR QUE ISTO EXISTE
#
# `scripts/preparar-nic.sh` e `scripts/diagnostico-nic.sh` foram escritos
# supondo que preparar uma NIC para o DPDK significa TIRÁ-LA DO KERNEL e
# bindá-la ao `vfio-pci`. Isso vale para a maioria das placas, e é falso para
# uma família inteira -- a que este projeto vai usar a seguir.
#
# OS DOIS MODELOS, e a diferença não é detalhe de configuração:
#
#   CAPTURA TOTAL (vfio-pci) -- Intel, Realtek, Broadcom e a maioria. O
#   dispositivo é desligado do driver do kernel e entregue ao user-space. A
#   interface DESAPARECE do `ip link`. O DPDK passa a falar com o hardware
#   diretamente, e o kernel não vê mais nada. É o modelo que os dois scripts
#   já tratavam.
#
#   BIFURCADO (mlx4, mlx5) -- Mellanox/NVIDIA. A documentação do DPDK diz que
#   "the same device is managed by both kernel and DPDK drivers": kernel e DPDK
#   convivem no MESMO dispositivo. A interface CONTINUA no `ip link`, o
#   `dpdk-devbind.py` não é usado, e bindar ao `vfio-pci` seria erro -- tiraria
#   do PMD justamente o driver de kernel de que ele depende. O que o PMD exige
#   no lugar é a pilha de userspace do RDMA (`rdma-core`), e o isolamento entre
#   os dois lados é configurado em tempo de execução, com `rte_flow_isolate()`.
#
# COMO A CLASSIFICAÇÃO É FEITA
#
# Pelo *vendor ID* do PCI, que é o critério estável: `0x15b3` é
# Mellanox/NVIDIA, e toda a linha ConnectX usa o modelo bifurcado. Não se usa o
# nome do driver do kernel, que muda por distribuição e por versão, nem o nome
# da interface, que o usuário renomeia.
#
# Esta função é o único lugar do projeto que sabe dessa distinção. Se aparecer
# outra família bifurcada, ela entra aqui e os dois scripts herdam.

# ===========================================================================
# DE ONDE VEM O FATO, A PARTIR DESTA RODADA
# ===========================================================================
#
# Toda leitura de /sys, /proc, /boot e /lib/modules deste arquivo passa pelos
# acessores de scripts/lib-apuracao.sh, que devolvem TRI-ESTADO: apurado,
# ausente (fato de inexistencia) e nao-apurado (nao e fato nenhum). O motivo
# desta troca esta documentado naquele arquivo; aqui interessa a consequencia
# local, que era o defeito fundador DOCUMENTADO COMO CONTRATO logo abaixo, em
# `vendor_de`.
#
# A biblioteca e dependencia DURA: sem ela nao ha como ler o sysfs sem
# reintroduzir a leitura crua que esta rodada existe para eliminar. Faltando o
# arquivo, este aqui recusa-se a carregar em vez de degradar em silencio --
# degradar em silencio e a forma que "nao consegui" tem de virar "nao ha".
if ! command -v apur_ler >/dev/null 2>&1; then
    _LIB_NIC_DIR=$(dirname "${BASH_SOURCE[0]}")
    if [ -r "$_LIB_NIC_DIR/lib-apuracao.sh" ]; then
        # shellcheck source=lib-apuracao.sh
        . "$_LIB_NIC_DIR/lib-apuracao.sh"
    else
        echo "ERRO FATAL: lib-nic.sh exige lib-apuracao.sh no mesmo diretorio" >&2
        echo "            ($_LIB_NIC_DIR/lib-apuracao.sh nao esta la, ou nao pode ser lido)." >&2
        echo "            Sem os acessores nao ha leitura de sysfs que distinga" >&2
        echo "            \"nao existe\" de \"nao consegui ler\": este arquivo NAO carrega." >&2
        return 1 2>/dev/null || exit 1
    fi
fi

# Vendors cujos PMDs são bifurcados. Um por linha, com o nome para a mensagem.
_VENDOR_BIFURCADO_15b3="Mellanox/NVIDIA (ConnectX)"

# modelo_de_driver <vendor_id_hex>  ->  "bifurcado" | "captura"
#
# Recebe o vendor em vez de ler o sysfs para ser TESTÁVEL sem o hardware: os
# testes passam IDs conhecidos e conferem a classificação. Sem isso, o caminho
# da Mellanox só seria exercitado no dia em que a placa chegasse -- e é
# exatamente o caminho que não pode estar errado nesse dia.
#
# ATENCAO AO QUE ELE *NAO* DECIDE, e esta e a fronteira que a rodada da
# apuracao tornou explicita: um vendor VAZIO cai em "captura", e vazio pode
# significar tanto "li o sysfs e o dispositivo nao e Mellanox" quanto "nao
# consegui ler". A segunda NAO pode chegar aqui: quem chama decide o modelo
# DEPOIS de confirmar que o vendor foi apurado -- ver `vendor_apurar`.
modelo_de_driver() {
    case "${1,,}" in
        0x15b3|15b3) printf 'bifurcado' ;;
        *)           printf 'captura' ;;
    esac
}

# nome_do_vendor <vendor_id_hex> -> descrição legível, ou vazio
nome_do_vendor() {
    case "${1,,}" in
        0x15b3|15b3) printf '%s' "$_VENDOR_BIFURCADO_15b3" ;;
        *)           printf '' ;;
    esac
}

# --- vendor_apurar <bdf> -----------------------------------------------------
#
# O CAMINHO CORRETO para obter o vendor PCI de um dispositivo. Devolve o
# tri-estado de lib-apuracao.sh, sem subshell:
#
#   rc=0  apurado     -> $_APUR tem o vendor ("0x15b3"), $_APUR_ESTADO="apurado"
#   rc=1  NAO APURADO -> $_APUR_MOTIVO diz o que faltou (privilegio, leitura)
#   rc=2  AUSENTE     -> o dispositivo nao esta em /sys/bus/pci/devices
#
# INCIDENTE, e ele e o defeito fundador deste projeto DOCUMENTADO COMO SE FOSSE
# CONTRATO. A funcao `vendor_de` abaixo declarava, na propria docstring,
# "ou vazio se o dispositivo não existir" -- e a implementacao era um
# `cat ... 2>/dev/null || printf ''`. Vazio saia identico nos tres casos:
#
#   (a) o dispositivo nao existe                      -> FATO
#   (b) existe e este uid nao pode ler o atributo     -> NAO APURADO
#   (c) /sys nao esta montado (container sem /sys)    -> NAO APURADO
#
# A consequencia nao e cosmetica. O vazio desce para `modelo_de_driver`, que
# responde "captura" para tudo que nao e 15b3 -- entao um sysfs ilegivel
# classifica uma ConnectX como captura total, e o passo seguinte do fluxo de
# preparacao binda ao vfio-pci uma placa BIFURCADA, tirando do PMD o driver de
# kernel de que ele depende. "Nao consegui ler" virando uma decisao destrutiva.
#
# Por que o valor NAO volta por `$( )`: a substituicao de comando roda em
# subshell, e o subshell morre levando junto $_APUR_MOTIVO -- o chamador fica
# com o vazio de novo. Chame no shell atual e leia as variaveis.
vendor_apurar() {
    apur_ler "/sys/bus/pci/devices/$1/vendor"
}

# vendor_de <bdf> -> vendor, ou VAZIO
#
# COMPATIBILIDADE, e o vazio daqui NAO E CONTRATO: e a forma antiga, mantida
# byte a byte para nao mudar por baixo o comportamento de quem ja chama
# `$(vendor_de ...)`. O vazio continua ambiguo de proposito -- so que agora a
# ambiguidade esta NOMEADA aqui, em vez de anunciada como se fosse informacao.
#
# Quem decide bind (captura x bifurcado) NAO deve usar esta funcao: um vazio
# tratado como "nao e Mellanox" e exatamente o caminho descrito em
# `vendor_apurar`. Use `vendor_apurar` e ramifique nos tres estados.
#
# A leitura crua saiu daqui: por dentro isto e `vendor_apurar`, e o vazio agora
# e produzido DEPOIS de a distincao ter sido feita, nao no lugar dela.
vendor_de() {
    if vendor_apurar "$1"; then
        printf '%s' "$_APUR"
    else
        printf ''
    fi
}

# vendor_motivo -> por que a ultima chamada de vendor_de nao devolveu valor
#
# Existe para que o chamador preguicoso -- que e a maioria, sempre -- tenha
# como transformar o vazio em frase sem reescrever o fluxo dele. Vazia quando
# a ultima apuracao deu certo.
vendor_motivo() { printf '%s' "${_APUR_MOTIVO:-}"; }

# --- rdma_core_ok -> 0 se a pilha de userspace do RDMA está completa ---------
#
# O PMD mlx5 depende de `rdma-core`. Faltando, o dispositivo simplesmente não é
# probado, e a mensagem do DPDK não aponta para a causa -- por isso a
# verificação é explícita e vem ANTES de tentar.
#
# INCIDENTE, mesma familia do de `vendor_de` por outra porta -- FERRAMENTA
# AUSENTE. A forma anterior era `ldconfig -p 2>/dev/null | grep -q "$l"`, e o
# rc do pipe e o do `grep`: com `ldconfig` fora do PATH (comum para uid nao
# root, em que /sbin nem sempre esta no PATH) a saida e vazia, nenhum grep casa,
# e as TRES bibliotecas sao reportadas como FALTANDO. Isso e uma afirmacao
# sobre a maquina do leitor -- "sua pilha RDMA esta incompleta" -- derivada de
# nao se ter conseguido perguntar. O relatorio entao manda instalar pacotes que
# ja podem estar la.
#
# Agora ha TRES estados, e `$_RDMA_ESTADO` os distingue:
#   apurado + vazio      a pilha esta completa (rc=0)
#   apurado + lista      estas bibliotecas faltam mesmo (rc=1)   <- FATO
#   nao-apurado          nao deu para perguntar (rc=1)           <- NAO E FATO
#
# O rc continua sendo 0 so no primeiro caso, de proposito: quem so olha o rc
# continua sendo conservador (nao promete RDMA que nao conferiu), e quem
# precisa da diferenca le $_RDMA_ESTADO -- que e o que os relatorios fazem.
_RDMA_FALTANDO=""
_RDMA_ESTADO=""
_RDMA_MOTIVO=""
rdma_core_ok() {
    local faltando="" l
    _RDMA_FALTANDO=""; _RDMA_ESTADO=""; _RDMA_MOTIVO=""

    # `ldconfig -p` le o cache do linker; e comando, nao arquivo de /sys, e por
    # isso vai por apur_cmd -- que separa "nao esta no PATH" de "rodou e
    # falhou" de "rodou e nao imprimiu nada", as tres coisas que o pipe antigo
    # colapsava num unico vazio.
    if ! apur_cmd ldconfig -p; then
        _RDMA_ESTADO="nao-apurado"
        _RDMA_MOTIVO=$_APUR_MOTIVO
        return 1
    fi

    # Casamento por substring com construcao do proprio shell: sem `grep`, que
    # tambem pode faltar -- e faltando o grep o pipe antigo dava o mesmo vazio,
    # com o mesmo veredito falso.
    for l in libibverbs.so.1 libmlx5.so.1 librdmacm.so.1; do
        case "$_APUR" in
            *"$l"*) ;;
            *) faltando="$faltando $l" ;;
        esac
    done
    _RDMA_FALTANDO="${faltando# }"
    _RDMA_ESTADO="apurado"
    [ -z "$_RDMA_FALTANDO" ]
}

# rdma_core_faltando -> lista do que faltou na última chamada de rdma_core_ok
rdma_core_faltando() { printf '%s' "${_RDMA_FALTANDO:-}"; }

# rdma_core_estado  -> "apurado" | "nao-apurado" da ultima chamada
# rdma_core_motivo  -> a frase do que faltou para apurar (vazia se apurado)
rdma_core_estado() { printf '%s' "${_RDMA_ESTADO:-}"; }
rdma_core_motivo() { printf '%s' "${_RDMA_MOTIVO:-}"; }

# explicar_bifurcado <bdf> <vendor> -- por que não se binda, e o que fazer.
explicar_bifurcado() {
    local bdf=$1 vendor=$2
    echo "  Este dispositivo usa driver BIFURCADO -- $(nome_do_vendor "$vendor")."
    echo ""
    echo "  Kernel e DPDK gerenciam o MESMO dispositivo. A documentacao do DPDK:"
    echo "    \"The same device is managed by both kernel and DPDK drivers.\""
    echo ""
    echo "  Consequencias, e a primeira surpreende:"
    echo "    - NAO se binda ao vfio-pci. Fazer isso tira do PMD o driver de"
    echo "      kernel de que ele depende."
    echo "    - a interface CONTINUA no 'ip link'. Isso e esperado, nao falha."
    echo "    - dpdk-devbind.py nao participa."
    echo "    - o PMD exige rdma-core no user-space."
    echo ""
    # Tres ramos, e o terceiro e novo: "nao deu para perguntar" nao pode sair
    # com a cara de "esta faltando". A linha antiga imprimia
    # "rdma-core: FALTANDO ->" seguido de NADA quando a consulta nao rodou --
    # uma acusacao sem objeto, que manda instalar o que nao se sabe se falta.
    if rdma_core_ok; then
        echo "  rdma-core: completo."
    elif [ "$(rdma_core_estado)" = "apurado" ]; then
        echo "  rdma-core: FALTANDO ->$(rdma_core_faltando)"
        echo "    Debian/Ubuntu: sudo apt install rdma-core libibverbs1 ibverbs-providers"
    else
        printf '  rdma-core: NAO APURADO -- %s\n' "$(rdma_core_motivo)"
        echo "    Isto NAO e o mesmo que a pilha estar incompleta: a consulta nao foi"
        echo "    feita. Confira a mao com:  ldconfig -p | grep libibverbs"
    fi
    echo ""
    echo "  Para usar, basta rodar a aplicacao apontando o dispositivo:"
    echo "    dpdk-testpmd -l 0-1 -a $bdf -- -i"
    echo ""
    echo "  Confira antes que o RDMA enxerga a placa:  ibv_devinfo"
}
