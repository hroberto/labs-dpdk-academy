#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
#
# Diagnostico do caminho NIC fisica -> DPDK, etapa por etapa.
#
# POR QUE EXISTE
#
# O modulo de RX/TX depende de uma afirmacao que ninguem tinha verificado nesta
# maquina: "a NIC de referencia serve". Bindar a placa e rodar o testpmd a mao
# funciona, mas nao deixa registro, esquece uma etapa no meio, e -- pior --
# pode deixar a placa fora do kernel se algo falhar.
#
# Este script executa TODAS as etapas, verifica cada uma, e devolve a placa ao
# kernel no final: inclusive se falhar no meio, inclusive com Ctrl+C, porque o
# restauro esta num trap de EXIT/INT/TERM.
#
# E o perfil "hardware smoke" que faltava na suite: prova probe, capacidades,
# filas e link -- e nao prova benchmark nem taxa de linha.
#
# ===========================================================================
# UMA REVERSAO QUE NAO REVERTE E DA MESMA FAMILIA QUE UMA TRAVA QUE NAO TRAVA
# ===========================================================================
#
# Este script e um DIAGNOSTICO -- e, diante de um fato que nao conseguiu
# apurar, um diagnostico declara e segue. Mas ele tambem PROMETE REVERSAO, e a
# promessa de reversao obedece a regra oposta: onde a reversao depende de um
# fato, esse fato tem de estar APURADO ANTES de a alteracao acontecer, ou a
# alteracao nao acontece.
#
# O DEFEITO QUE ESTA VERSAO FECHA, e ele deixava a placa fora do kernel:
#
#   O driver de origem era descoberto com um `basename $(readlink -f ...)` cujos
#   dois erros eram engolidos. O resultado vazio significava, indistintamente,
#   "o dispositivo nao tem driver ligado" (fato) e "nao consegui ler" (nada).
#   A etapa 1 registrava isso como a FALHA "sem driver" -- e SEGUIA. Mais
#   adiante a placa era bindada ao vfio-pci. No fim, a funcao de restauro
#   comecava por "se nao registrei driver de origem, nada foi alterado: sair em
#   silencio" -- premissa que tinha deixado de ser verdadeira tres etapas antes.
#   Resultado: placa no vfio-pci, nenhuma tentativa de religar, nenhuma
#   mensagem, codigo de saida coerente. A reversao prometida nao acontecia, e
#   nao avisava que nao tinha acontecido.
#
#   Por isso, agora, a apuracao do driver de origem e do modelo de driver vem
#   ANTES do trap e ANTES de qualquer alteracao, e nao apurar ABORTA. Quando o
#   dispositivo esta legitimamente sem driver -- fato, nao falha de leitura --
#   o script tambem para, porque nao existe "de volta" para onde voltar; a saida
#   e informar o driver a mao com --driver-original=<nome>.
#
# O SEGUNDO DEFEITO, de outra natureza: o veredito final dizia "TODAS AS ETAPAS
# PASSARAM" contando apenas FALHAS. Uma etapa que nao pode ser apurada nao
# falhava nem passava -- ela sumia da conta, e o verde saia por cima do que
# ninguem verificou. Verde falso e pior que defesa nenhuma, entao a nao-apuracao
# agora tem contador proprio e veredito proprio.
#
# Uso: sudo ./scripts/diagnostico-nic.sh BDF [--driver-original=<nome>]
# A captura exige dispositivo explicito; nao ha BDF padrao.

set -u

BDF=""
DRIVER_ORIGINAL_FORCADO=""
for arg in "$@"; do
    case "$arg" in
        --driver-original=*) DRIVER_ORIGINAL_FORCADO="${arg#--driver-original=}" ;;
        -*) echo "opcao desconhecida: $arg" >&2; exit 2 ;;
        *)  [ -z "$BDF" ] || { echo 'informe apenas um BDF' >&2; exit 2; }; BDF="$arg" ;;
    esac
done
if [[ "$BDF" =~ ^[[:xdigit:]]{2}:[[:xdigit:]]{2}\.[0-7]$ ]]; then BDF="0000:$BDF"; fi
if [[ ! "$BDF" =~ ^[[:xdigit:]]{4}:[[:xdigit:]]{2}:[[:xdigit:]]{2}\.[0-7]$ ]]; then
    echo 'informe BDF explicito no formato 0000:01:00.0' >&2; exit 2
fi
if [ -n "$DRIVER_ORIGINAL_FORCADO" ] && [[ ! "$DRIVER_ORIGINAL_FORCADO" =~ ^[a-zA-Z0-9_][a-zA-Z0-9_.-]*$ ]]; then
    echo 'nome de driver invalido' >&2; exit 2
fi

FALHAS=0
NAO_APURADOS=0
DRIVER_ORIGINAL=""
BINDOU=0
MODELO=""

# O diretorio do script sai de expansao do proprio shell: com `dirname` fora do
# PATH, o `source` falhava e o script seguia com as funcoes indefinidas.
AQUI=${0%/*}
[ "$AQUI" = "$0" ] && AQUI="."
# shellcheck source=lib-apuracao.sh
. "$AQUI/lib-apuracao.sh" || { echo "nao consegui carregar $AQUI/lib-apuracao.sh" >&2; exit 1; }
# shellcheck source=lib-nic.sh
. "$AQUI/lib-nic.sh" || { echo "nao consegui carregar $AQUI/lib-nic.sh" >&2; exit 1; }
. "$AQUI/lib-bind-guard.sh" || { echo "nao consegui carregar lib-bind-guard.sh" >&2; exit 1; }

titulo() { printf '\n\033[1m=== ETAPA %s: %s ===\033[0m\n' "$1" "$2"; }
ok()     { printf '  [ok]    %s\n' "$1"; }
falha()  { printf '  [FALHA] %s\n' "$1"; FALHAS=$((FALHAS+1)); }
info()   { printf '  [info]  %s\n' "$1"; }
# nao_apurado -- o terceiro estado, e ele NAO e uma falha. Uma falha e um fato
# ruim sobre a maquina; isto e a ausencia de fato. Contam separado porque o
# veredito final trata os dois de forma diferente.
nao_apurado() { printf '  [?]     NAO APURADO: %s\n' "$1"; NAO_APURADOS=$((NAO_APURADOS+1)); }

# --- driver_de <bdf> --------------------------------------------------------
#
# Nome do driver ligado ao dispositivo, em $_DRIVER, com tri-estado no rc:
#   0 = apurado ($_DRIVER tem o nome)
#   1 = NAO APURADO ($_APUR_MOTIVO explica)
#   2 = AUSENTE: nao ha symlink `driver` -- o dispositivo esta sem driver. FATO.
_DRIVER=""
driver_de() {
    _DRIVER=""
    apur_link "/sys/bus/pci/devices/$1/driver" || return $?
    _DRIVER=${_APUR##*/}
    return 0
}

# --- iface_de <bdf> ---------------------------------------------------------
#   0 com $_IFACE preenchido -> ha interface
#   0 com $_IFACE vazio      -> FATO: o dispositivo nao expoe interface ao kernel
#   1                        -> NAO APURADO
_IFACE=""
iface_de() {
    _IFACE=""
    if apur_listar "/sys/bus/pci/devices/$1/net"; then
        [ "$_APUR_N" -eq 0 ] && return 0
        _IFACE=${_APUR%%$'\n'*}
        return 0
    fi
    [ "$_APUR_ESTADO" = "ausente" ] && return 0
    return 1
}

# --- rota_default_txt -------------------------------------------------------
# A primeira linha da rota default, ou o veneno da biblioteca. Nunca vazio
# calado: "  rota default: " seguido de nada era uma afirmacao sobre a maquina.
rota_default_txt() {
    if apur_cmd ip route show default; then
        printf '%s' "${_APUR%%$'\n'*}"
    else
        printf '%s' "$_APUR"
    fi
}

restaurar() {
    # Se nada foi bindado, nada ha para restaurar. A guarda agora e uma bandeira
    # LIGADA NO MOMENTO DA ALTERACAO, e nao a presenca do nome do driver de
    # origem: era exatamente essa confusao -- "nao sei o driver" lido como "nao
    # alterei nada" -- que deixava a placa no vfio-pci em silencio.
    [ "$BINDOU" -eq 1 ] || return 0
    printf '\n\033[1m=== RESTAURANDO ===\033[0m\n'
    if driver_de "$BDF" && [ "$_DRIVER" = "vfio-pci" ]; then
        apur_cmd dpdk-devbind.py --bind="$DRIVER_ORIGINAL" "$BDF"
        sleep 1
    fi
    # O desfecho e SEMPRE conferido no sysfs. E o unico ponto do script em que
    # nao apurar nao pode virar silencio: quem le esta saida precisa saber se a
    # placa voltou, e "nao sei" aqui exige acao humana imediata.
    if driver_de "$BDF"; then
        if [ "$_DRIVER" = "$DRIVER_ORIGINAL" ]; then
            if iface_de "$BDF"; then
                ok "placa de volta em '$_DRIVER', interface '${_IFACE:-(nenhuma)}'"
            else
                ok "placa de volta em '$_DRIVER' (interface NAO APURADA: $_APUR_MOTIVO)"
            fi
        else
            falha "placa em '$_DRIVER', esperado '$DRIVER_ORIGINAL' -- religue a mao:"
            printf '          dpdk-devbind.py --bind=%s %s\n' "$DRIVER_ORIGINAL" "$BDF"
        fi
    else
        falha "NAO APUREI em qual driver $BDF ficou: $_APUR_MOTIVO"
        printf '          A placa PODE estar fora do kernel. Confira e, se preciso, religue:\n'
        printf '          dpdk-devbind.py --status-dev net\n'
        printf '          dpdk-devbind.py --bind=%s %s\n' "$DRIVER_ORIGINAL" "$BDF"
    fi
    printf '  rota default: %s\n' "$(rota_default_txt)"
}

# Guardas que nao dependem de ter alterado nada vem ANTES do trap.
#
# `$EUID` e variavel do proprio bash, no lugar de `$(id -u)`: com `id` fora do
# PATH a comparacao numerica errava e a mensagem culpava a falta de root.
[ "${EUID:-1}" -eq 0 ] || { echo "precisa ser root: sudo $0 ${BDF}"; exit 1; }
if ! apur_listar "/sys/bus/pci/devices/$BDF"; then
    if [ "$_APUR_ESTADO" = "ausente" ]; then
        echo "dispositivo $BDF nao existe"
    else
        echo "NAO APUREI se o dispositivo $BDF existe: $_APUR_MOTIVO"
        echo "sem isso nao da para comecar: o script alteraria estado sem saber sobre o que"
    fi
    exit 1
fi
command -v dpdk-devbind.py >/dev/null || { echo "dpdk-devbind.py nao encontrado"; exit 1; }
command -v dpdk-testpmd   >/dev/null || { echo "dpdk-testpmd nao encontrado"; exit 1; }

# ---------------------------------------------------------------------------
titulo 1 "Estado inicial"

# O MODELO DE DRIVER decide se havera bind. Sem apurar o vendor nao ha como
# saber, e "nao ha como saber" nao pode virar "captura total" -- que e o ramo
# que binda. Aqui o script ainda nao alterou nada, entao abortar e barato.
if vendor_apurar "$BDF"; then
    VENDOR=$_APUR
    MODELO=$(modelo_de_driver "$VENDOR")
else
    echo "  NAO APUREI o vendor PCI de $BDF: $_APUR_MOTIVO" >&2
    echo "  Sem o vendor nao da para saber se a placa e de captura total ou" >&2
    echo "  bifurcada, e a diferenca decide se o script binda ou nao binda." >&2
    echo "  O script para aqui, com a maquina como estava." >&2
    exit 1
fi

# O DRIVER DE ORIGEM e a promessa de reversao. Apurado ANTES do trap e antes de
# qualquer alteracao; nao apurar aborta, e a ausencia (placa sem driver) tambem
# aborta -- nao por ser falha de leitura, mas porque nao existe destino de volta.
if [ -n "$DRIVER_ORIGINAL_FORCADO" ]; then
    DRIVER_ORIGINAL=$DRIVER_ORIGINAL_FORCADO
    info "driver de origem informado na linha de comando: $DRIVER_ORIGINAL"
elif driver_de "$BDF"; then
    DRIVER_ORIGINAL=$_DRIVER
    ok "driver atual: $DRIVER_ORIGINAL"
elif [ "$_APUR_ESTADO" = "ausente" ] && [ "$MODELO" != "bifurcado" ]; then
    echo "  $BDF esta SEM DRIVER ligado (apurado: nao ha o link 'driver' no sysfs)." >&2
    echo "  Este script binda ao vfio-pci e promete devolver a placa ao kernel no" >&2
    echo "  fim -- e nao ha para onde devolver. Informe o driver de origem:" >&2
    echo "    sudo $0 $BDF --driver-original=<nome>" >&2
    exit 1
elif [ "$_APUR_ESTADO" != "ausente" ]; then
    echo "  NAO APUREI o driver atual de $BDF: $_APUR_MOTIVO" >&2
    echo "  A reversao no fim do teste depende deste nome. Sem ele o script nao" >&2
    echo "  binda: uma reversao que nao pode ser cumprida nao pode ser prometida." >&2
    echo "    sudo $0 $BDF --driver-original=<nome>" >&2
    exit 1
else
    # Bifurcada e sem driver: nao havera bind, entao nao ha reversao a prometer.
    info "sem driver ligado, e o modelo e bifurcado: nao havera bind"
fi

trap restaurar EXIT INT TERM

if iface_de "$BDF"; then
    IFACE_ORIGINAL=$_IFACE
    [ -n "$IFACE_ORIGINAL" ] && ok "interface: $IFACE_ORIGINAL" || info "sem interface no kernel"
else
    IFACE_ORIGINAL=""
    nao_apurado "qual interface de kernel pertence a $BDF: $_APUR_MOTIVO"
fi
info "rota default: $(rota_default_txt)"
if apur_cmd lspci -n -s "${BDF#0000:}"; then
    par=""
    while IFS= read -r linha; do
        set -- $linha
        [ $# -ge 3 ] && { par=$3; break; }
    done <<<"$_APUR"
    [ -n "$par" ] && info "par PCI: $par" || nao_apurado "o par PCI: o lspci rodou e nao imprimiu a coluna esperada"
else
    nao_apurado "o par PCI de $BDF: $_APUR_MOTIVO"
fi
if [ "$MODELO" = "bifurcado" ]; then
    ok "modelo de driver: BIFURCADO -- $(nome_do_vendor "$VENDOR")"
    info "kernel e DPDK compartilham o dispositivo; NAO havera bind"
else
    ok "modelo de driver: captura total (vfio-pci)"
fi

# Hugepages: `awk '/HugePages_Free/'` casava tambem com qualquer chave que
# CONTIVESSE esse texto, e sumia por inteiro com /proc mascarado ou sem `awk`.
# `apur_campo` compara a chave LITERALMENTE e separa "li o arquivo e a chave nao
# esta la" (fato: kernel sem hugetlb) de "nao li o arquivo" (nao e fato nenhum).
if apur_campo /proc/meminfo HugePages_Free; then
    info "hugepages livres: $_APUR"
elif [ "$_APUR_ESTADO" = "ausente" ]; then
    info "/proc/meminfo foi lido e nao traz HugePages_Free (kernel sem hugetlb)"
else
    nao_apurado "hugepages livres: $_APUR_MOTIVO"
fi
info "ulimit -l (MEMLOCK): $(ulimit -l)"

# ---------------------------------------------------------------------------
if [ "$MODELO" = "bifurcado" ]; then
    # ------------------------------------------------------------------
    titulo 2 "rdma-core (o que o mlx5 exige no lugar do vfio-pci)"
    if rdma_core_ok; then
        ok "pilha rdma-core completa"
    else
        falha "faltando:$(rdma_core_faltando)"
        info "Debian/Ubuntu: sudo apt install rdma-core libibverbs1 ibverbs-providers"
    fi
    # `ibv_devinfo` fora do PATH e "ibv_devinfo rodou e nao enxergou nada" sao
    # coisas diferentes: a primeira e pacote faltando, a segunda e diagnostico
    # sobre a placa. apur_cmd separa as duas, e o rc != 0 carrega o stderr.
    if apur_cmd ibv_devinfo; then
        ok "ibv_devinfo enxerga dispositivo RDMA"
    elif [ -n "$_APUR_RC" ]; then
        falha "ibv_devinfo rodou e saiu $_APUR_RC: nao enxerga dispositivo RDMA"
    else
        info "ibv_devinfo ausente (pacote ibverbs-utils) -- nao e bloqueio"
    fi

    titulo 3 "Bind: nao se aplica"
    info "driver bifurcado: a interface segue no kernel, e isso e o esperado"
    info "a placa continua visivel em 'ip link' durante todo o teste"
else
titulo 2 "Carregar vfio-pci"
if ! nic_bind_guard "$BDF"; then
    falha "captura recusada: $NIC_BIND_REASON"
    exit 1
fi
if ! apur_cmd modprobe vfio-pci; then
    falha "modprobe vfio-pci: $_APUR_MOTIVO"
    exit 1
fi
[ -n "$_APUR_ERRO" ] && printf '          %s\n' "$_APUR_ERRO"

# `lsmod | grep -q` trocado por contagem em bash puro sobre /proc/modules: nem
# `lsmod` nem `grep` precisam existir, e -- o que importa mais -- zero
# casamentos deixa de ser indistinguivel de "nao consegui procurar". Antes, sem
# `lsmod` no PATH, o script anunciava "vfio_pci nao carregou" e abortava
# culpando o modulo por uma ferramenta ausente.
if apur_contar /proc/modules '^vfio_pci '; then
    if [ "$_APUR_N" -gt 0 ]; then
        ok "modulo vfio_pci carregado"
    else
        falha "vfio_pci nao carregou (apurado: /proc/modules nao lista o modulo)"
        exit 1
    fi
else
    falha "NAO APUREI se o vfio_pci carregou: $_APUR_MOTIVO"
    echo "          Sem essa confirmacao o bind nao e tentado." >&2
    exit 1
fi

# ---------------------------------------------------------------------------
titulo 3 "Bindar ao vfio-pci"
if [ -n "$IFACE_ORIGINAL" ] && ! apur_cmd ip link set "$IFACE_ORIGINAL" down; then
    falha "nao consegui derrubar $IFACE_ORIGINAL: $_APUR_MOTIVO"
    exit 1
fi
# A bandeira sobe ANTES da chamada: se o devbind alterar o estado e falhar no
# meio, o restauro tem de rodar mesmo assim. Subir depois seria apostar que a
# operacao e atomica.
BINDOU=1
if ! apur_cmd dpdk-devbind.py --bind=vfio-pci "$BDF"; then
    falha "dpdk-devbind: $_APUR_MOTIVO"
    exit 1
fi
[ -n "$_APUR_ERRO" ] && printf '          %s\n' "$_APUR_ERRO"
sleep 1
if driver_de "$BDF"; then
    if [ "$_DRIVER" = "vfio-pci" ]; then
        ok "driver agora: vfio-pci"
    else
        falha "bind nao pegou: $_DRIVER"
        exit 1
    fi
else
    falha "NAO APUREI qual driver assumiu $BDF apos o bind: $_APUR_MOTIVO"
    exit 1
fi

# O no de dispositivo do grupo e procurado na LISTAGEM de /dev/vfio, e nao com
# um teste de existencia sobre o caminho montado. Antes o nome do grupo vinha de
# um `basename $(readlink -f ...)` sem tratamento: quando falhava, o caminho
# testado virava "/dev/vfio/" -- que EXISTE -- e o script imprimia um [ok] para
# um grupo que ninguem identificou.
if apur_link "/sys/bus/pci/devices/$BDF/iommu_group"; then
    GRUPO=${_APUR##*/}
    if apur_listar /dev/vfio; then
        achou_no=0
        for n in $_APUR; do [ "$n" = "$GRUPO" ] && achou_no=1; done
        if [ "$achou_no" -eq 1 ]; then
            if apur_cmd stat -c '%A %U:%G' "/dev/vfio/$GRUPO"; then
                ok "/dev/vfio/$GRUPO existe ($_APUR)"
            else
                ok "/dev/vfio/$GRUPO existe (permissoes NAO APURADAS: $_APUR_MOTIVO)"
            fi
        else
            falha "/dev/vfio/$GRUPO NAO existe -- o VFIO nao expos o grupo"
        fi
    elif [ "$_APUR_ESTADO" = "ausente" ]; then
        falha "/dev/vfio nao existe -- o VFIO nao expos grupo nenhum"
    else
        nao_apurado "se o VFIO expos o grupo $GRUPO: $_APUR_MOTIVO"
    fi
else
    nao_apurado "a qual grupo IOMMU $BDF pertence: $_APUR_MOTIVO"
fi

# ---------------------------------------------------------------------------
fi

titulo 4 "testpmd: o PMD reivindica o dispositivo?"
if ! apur_cmd mktemp; then
    nao_apurado "se o PMD reivindica $BDF: $_APUR_MOTIVO (sem arquivo temporario nao ha onde guardar a saida do testpmd)"
else
SAIDA=$_APUR
printf 'show port summary all\nshow port info 0\nquit\n' | \
  timeout 60 dpdk-testpmd -l 0-1 -a "$BDF" -- -i --total-num-mbufs=2048 >"$SAIDA" 2>&1
RC=$?
info "codigo de saida do testpmd: $RC"

# A saida do testpmd e lida UMA vez pelo acessor; dai em diante tudo e feito com
# construcoes do shell. O que isso fecha: o `grep -q 'No probed ethernet
# devices'` decidia o veredito da etapa, e um grep que ERRA sai com codigo != 0
# igual a um grep que NAO ENCONTRA -- isto e, "nao consegui procurar" caia no
# ramo "o dispositivo foi probado". O ramo otimista era o ramo do erro.
if ! apur_ler "$SAIDA"; then
    nao_apurado "o resultado do testpmd: $_APUR_MOTIVO"
else
SAIDA_TXT=$_APUR

# linhas_que_casam <ere> <limite> -- imprime ate <limite> linhas que casam.
linhas_que_casam() {
    local ere=$1 limite=$2 linha n=0
    while IFS= read -r linha; do
        if [[ $linha =~ $ere ]]; then
            printf '          %s\n' "$linha"
            n=$((n + 1))
            [ "$n" -ge "$limite" ] && return 0
        fi
    done <<<"$SAIDA_TXT"
}
# faixa_entre <ere_inicio> <ere_fim> -- da primeira linha que casa o inicio ate
# a primeira que casa o fim, inclusive.
faixa_entre() {
    local ini=$1 fim=$2 linha dentro=0
    while IFS= read -r linha; do
        if [ "$dentro" -eq 0 ]; then
            [[ $linha =~ $ini ]] || continue
            dentro=1
        fi
        printf '          %s\n' "$linha"
        [ "$dentro" -eq 1 ] && [[ $linha =~ $fim ]] && return 0
    done <<<"$SAIDA_TXT"
}

echo "  --- linhas decisivas ---"
linhas_que_casam 'Probe PCI driver|EAL: Requested device|No probed|rte_eth_dev|Cannot|failed|Error|error' 12

if apur_contar "$SAIDA" 'No probed ethernet devices'; then
    if [ "$_APUR_N" -gt 0 ]; then
        falha "PMD NAO reivindicou o dispositivo"
        echo "  --- saida completa do EAL, para diagnostico ---"
        linhas_que_casam '.*' 40
    else
        ok "o dispositivo foi probado"
        # O testpmd ECOA o comando no prompt antes de responder, entao delimitar
        # por "show port info 0" pega so o eco. Os marcadores confiaveis sao os
        # cabecalhos que o proprio testpmd imprime.
        echo "  --- resumo da porta ---"
        faixa_entre 'Number of available ports' '^[[:space:]]*$'
        echo "  --- capacidades da porta 0 ---"
        faixa_entre 'Infos for port' 'Device private info'
    fi
else
    nao_apurado "se o PMD reivindicou o dispositivo: $_APUR_MOTIVO"
fi
fi

echo "  (saida completa em $SAIDA)"
fi

# ---------------------------------------------------------------------------
titulo 5 "Veredito"
if [ "$FALHAS" -eq 0 ] && [ "$NAO_APURADOS" -eq 0 ]; then
    printf '  \033[1mTODAS AS ETAPAS PASSARAM\033[0m -- a NIC fisica serve para o modulo de RX/TX.\n'
elif [ "$FALHAS" -eq 0 ]; then
    # O verde NAO sai aqui, e essa e a mudanca. Antes, etapas que nao puderam
    # ser apuradas nao entravam na conta -- nem como falha nem como pendencia --
    # e o script anunciava que a placa servia com base em verificacoes que nao
    # rodaram. Um relatorio que esconde o que nao verificou empresta autoridade
    # ao silencio.
    printf '  \033[1mNENHUMA FALHA, MAS %s ITEM(NS) NAO APURADO(S)\033[0m -- veja as linhas [?].\n' "$NAO_APURADOS"
    printf '  Isto NAO e o mesmo que "a NIC serve": e "o que foi verificado passou".\n'
else
    printf '  \033[1m%s FALHA(S)\033[0m' "$FALHAS"
    [ "$NAO_APURADOS" -gt 0 ] && printf ' e %s item(ns) NAO APURADO(S)' "$NAO_APURADOS"
    printf ' -- veja acima; a placa sera restaurada mesmo assim.\n'
fi
