#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
#
# Registro do ambiente de medição.
#
# POR QUE ESTE SCRIPT EXISTE
#
# Todo número publicado neste projeto foi medido numa máquina específica, e a
# regra editorial é que **resultado experimental sem contexto de hardware não é
# resultado universal**. Só que descrever a máquina em prosa, documento por
# documento, produz três problemas que já apareceram aqui:
#
#   1. a descrição diverge entre arquivos, e ninguém percebe;
#   2. ela envelhece em silêncio quando o kernel ou o DPDK são atualizados;
#   3. quem reproduz numa máquina diferente não sabe o que comparar.
#
# A solução é não escrever a descrição: gerá-la. Este script emite o registro no
# formato que os documentos citam, e serve tanto para a máquina de referência
# quanto para a de quem estiver reproduzindo.
#
# ===========================================================================
# O "-" QUE NAO MENTIA E MESMO ASSIM ENGANAVA
# ===========================================================================
#
# A versao anterior resolvia toda leitura que falhasse com um "-":
#
#     CPU_L3_TAM=$(cat /sys/.../index3/size 2>/dev/null || echo "-")
#     GOVERNOR=$(cat /sys/.../scaling_governor 2>/dev/null || echo "-")
#     TURBO_INTEL=$(cat /sys/.../intel_pstate/no_turbo 2>/dev/null || echo "-")
#
# O "-" nao afirma nada falso, e por isso a forma passou tres revisoes. O
# problema e o que ele NAO diz, num documento cuja razao de existir e
# reprodutibilidade:
#
#   - "-" em `intel_no_turbo` nesta maquina significa "este AMD nao tem o
#     driver intel_pstate", que e um FATO sobre o hardware -- publicavel,
#     util, e que dispensa investigacao;
#   - "-" em `governor` significaria "nao consegui ler", que e o oposto: um
#     buraco na medicao, e quem comparar duas execucoes precisa saber que ali
#     falta dado, nao que o dado e "nenhum".
#
# As duas coisas saiam com o MESMO caractere. Agora a celula distingue
# "(ausente)" de "(nao apurado)", e o relatorio ganha uma secao no fim dizendo,
# campo a campo, O QUE faltou -- nunca um marcador mudo. As leituras passam
# todas por scripts/lib-apuracao.sh, que e quem sabe separar os tres estados.
#
# Uso:
#   ./scripts/ambiente.sh              # texto legível
#   ./scripts/ambiente.sh --markdown   # tabela pronta para colar em documento
set -u

RAIZ=$(dirname "$0")
if [ -r "$RAIZ/lib-apuracao.sh" ]; then
    # shellcheck source=lib-apuracao.sh
    . "$RAIZ/lib-apuracao.sh"
else
    echo "ERRO FATAL: $RAIZ/lib-apuracao.sh nao esta la, ou nao pode ser lido." >&2
    echo "            Sem os acessores este registro nao teria como distinguir" >&2
    echo "            um campo AUSENTE de um campo NAO APURADO, e a distincao e" >&2
    echo "            a razao de o registro existir. NAO roda." >&2
    exit 3
fi

MODO=${1:-texto}

# --- o vocabulario de celula --------------------------------------------------
#
# Duas palavras, e elas nunca se confundem com um valor medido:
#   (ausente)      o fato e a inexistencia -- o kernel nao publica esse arquivo
#   (nao apurado)  nao foi possivel olhar; NAO e afirmacao sobre a maquina
AUSENTE="(ausente)"
NAO_APURADO="(nao apurado)"

# Cada lacuna vira uma linha "campo|ESTADO|motivo", impressa no fim. O motivo
# nunca e descartado: e ele que diz se root, um pacote ou outro kernel mudaria
# a resposta.
_LACUNAS=""
registrar_lacuna() { _LACUNAS="${_LACUNAS}${1}|${2}|${3}"$'\n'; }

# le_arquivo <rotulo> <caminho>  ->  VALOR
le_arquivo() {
    if apur_ler "$2"; then
        VALOR=$_APUR
    elif [ "$_APUR_ESTADO" = "ausente" ]; then
        VALOR=$AUSENTE
        registrar_lacuna "$1" AUSENTE "$_APUR_MOTIVO"
    else
        VALOR=$NAO_APURADO
        registrar_lacuna "$1" "NAO APURADO" "$_APUR_MOTIVO"
    fi
}

# le_campo <rotulo> <arquivo> <chave>  ->  VALOR
le_campo() {
    if apur_campo "$2" "$3"; then
        VALOR=$_APUR
    elif [ "$_APUR_ESTADO" = "ausente" ]; then
        VALOR=$AUSENTE
        registrar_lacuna "$1" AUSENTE "$_APUR_MOTIVO"
    else
        VALOR=$NAO_APURADO
        registrar_lacuna "$1" "NAO APURADO" "$_APUR_MOTIVO"
    fi
}

# roda <rotulo> <programa> [args...]  ->  VALOR (PRIMEIRA linha da saida)
#
# Substitui o `v()` antigo, que era `$("$@" 2>/dev/null | head -1)` com
# `${saida:--}`: ali "programa ausente", "programa que falhou" e "programa que
# imprimiu nada" saiam os tres como "-". Agora o motivo e preservado.
roda() {
    local rotulo=$1
    shift
    if apur_cmd "$@"; then
        VALOR=${_APUR%%$'\n'*}
    else
        VALOR=$NAO_APURADO
        registrar_lacuna "$rotulo" "NAO APURADO" "$_APUR_MOTIVO"
    fi
}

# numerico <valor> -- so para decidir se da para fazer conta com a celula.
numerico() { case "${1:-}" in ''|*[!0-9]*) return 1 ;; *) return 0 ;; esac; }

# --- coleta ---------------------------------------------------------------
# ATENÇÃO: nada aqui depende do TEXTO do lscpu. A saída dele é traduzida — nesta
# máquina sai em português —, e um parsing por rótulo em inglês devolve campos
# vazios em silêncio. Foi o que aconteceu na primeira versão deste script, o que
# é irônico num script cuja razão de existir é reprodutibilidade. As formas
# usadas abaixo, `lscpu -p=` e o sysfs, são independentes de idioma.
le_campo "CPU (modelo)" /proc/cpuinfo "model name"; CPU_MODELO=$VALOR
roda "CPU (logicas)" nproc; CPU_LOGICAS=$VALOR

# conta_unicas <rotulo> <spec de lscpu -p>  -> numero de combinacoes distintas
#
# O pipe antigo era `lscpu -p=X | grep -v '^#' | sort -u | wc -l`, e ele tem
# tres processos que podem faltar e um rc que se perde no caminho: com `lscpu`
# fora do PATH o resultado era o numero 0, e zero soquete e uma afirmacao
# absurda que ninguem notaria numa tabela. Aqui o rc do lscpu e apurado e a
# contagem e feita pelo proprio shell.
conta_unicas() {
    local rotulo=$1 spec=$2 linha n=0
    local -A vistos=()
    if ! apur_cmd lscpu -p="$spec"; then
        VALOR=$NAO_APURADO
        registrar_lacuna "$rotulo" "NAO APURADO" "$_APUR_MOTIVO"
        return
    fi
    while IFS= read -r linha; do
        [ -n "$linha" ] || continue
        case "$linha" in '#'*) continue ;; esac
        if [ -z "${vistos[$linha]:-}" ]; then vistos[$linha]=1; n=$((n + 1)); fi
    done <<<"$_APUR"
    VALOR=$n
}
conta_unicas "CPU (nucleos fisicos)" CORE,SOCKET; CPU_FISICOS=$VALOR
conta_unicas "CPU (soquetes)" SOCKET;            CPU_SOQUETES=$VALOR
conta_unicas "nos NUMA" NODE;                    NUMA_NOS=$VALOR

# SMT so e calculavel quando os dois lados sao numeros: com um deles nao
# apurado, a divisao publicaria uma razao inventada.
if numerico "$CPU_FISICOS" && numerico "$CPU_LOGICAS" && [ "$CPU_FISICOS" -gt 0 ]; then
    CPU_SMT=$((CPU_LOGICAS / CPU_FISICOS))
else
    CPU_SMT=$NAO_APURADO
    registrar_lacuna "CPU (threads por nucleo)" "NAO APURADO" \
        "depende de nucleos fisicos e logicos, e um dos dois nao foi apurado"
fi

# L3 pode ter várias instâncias (uma por CCD, em Ryzen): reportar as duas coisas.
le_arquivo "L3 (tamanho)" /sys/devices/system/cpu/cpu0/cache/index3/size
CPU_L3_TAM=$VALOR

# O glob `cat /sys/devices/system/cpu/cpu*/cache/index3/id 2>/dev/null` devolvia
# VAZIO tanto para "este kernel nao expoe o id do cache" quanto para "nao pude
# percorrer /sys", e `wc -l` transformava os dois no numero 0 -- "zero
# instancias de L3", que nenhuma maquina tem. Agora a lista de CPUs vem de
# `apur_listar` (que separa diretorio vazio de diretorio ilegivel) e cada
# leitura e apurada em separado.
#
# A ordem e a do proprio diretorio, e a unicidade guarda a PRIMEIRA aparicao:
# sem `sort` externo no caminho, uma ferramenta a menos pode faltar.
CPU_L3_N=$NAO_APURADO
CPU_DOMINIOS=$NAO_APURADO
if apur_listar /sys/devices/system/cpu; then
    entradas=$_APUR
    ids=""; n_ids=0; dominios=""; nao_apurados=0; motivo_l3=""
    while IFS= read -r e; do
        case "$e" in
            cpu[0-9]*) ;;
            *) continue ;;
        esac
        if apur_ler "/sys/devices/system/cpu/$e/cache/index3/id"; then
            case " $ids " in
                *" $_APUR "*) ;;
                *) ids="$ids $_APUR"; n_ids=$((n_ids + 1)) ;;
            esac
        elif [ "$_APUR_ESTADO" != "ausente" ]; then
            nao_apurados=$((nao_apurados + 1)); motivo_l3=$_APUR_MOTIVO
        fi
        if apur_ler "/sys/devices/system/cpu/$e/cache/index3/shared_cpu_list"; then
            case " $dominios " in
                *" $_APUR "*) ;;
                *) dominios="$dominios $_APUR" ;;
            esac
        elif [ "$_APUR_ESTADO" != "ausente" ]; then
            nao_apurados=$((nao_apurados + 1)); motivo_l3=$_APUR_MOTIVO
        fi
    done <<<"$entradas"
    if [ "$nao_apurados" -gt 0 ]; then
        registrar_lacuna "L3 (instancias e dominios)" "NAO APURADO" \
            "$nao_apurados leitura(s) de cache L3 falharam; a primeira: $motivo_l3"
    fi
    # Zero instancias so e publicavel quando NENHUMA leitura falhou: dai e
    # fato (kernel que nao expoe o id do cache), e nao buraco.
    if [ "$nao_apurados" -eq 0 ] || [ "$n_ids" -gt 0 ]; then
        CPU_L3_N=$n_ids
        CPU_DOMINIOS="${dominios# } "
    fi
else
    registrar_lacuna "L3 (instancias e dominios)" "NAO APURADO" "$_APUR_MOTIVO"
fi
CPU_L3="$CPU_L3_TAM x $CPU_L3_N instancia(s)"

# Sinalizadores de TSC: a lista `flags` do /proc/cpuinfo e conferida por
# pertencimento, em ordem fixa. O `grep -o ... | sort -u` anterior devolvia
# vazio tanto para "esta CPU nao tem nenhum deles" quanto para "nao li o
# arquivo" -- e a ausencia de sinalizador de TSC muda a validade de TODA
# medicao de tempo deste projeto, entao ela nao pode sair por omissao.
if apur_campo /proc/cpuinfo flags; then
    todas=" $_APUR "
    CPU_FLAGS=""
    for f in constant_tsc invariant_tsc nonstop_tsc tsc_known_freq; do
        case "$todas" in *" $f "*) CPU_FLAGS="$CPU_FLAGS$f " ;; esac
    done
    [ -n "$CPU_FLAGS" ] || CPU_FLAGS="(nenhum dos quatro sinalizadores de TSC)"
else
    CPU_FLAGS=$NAO_APURADO
    registrar_lacuna "sinalizadores de TSC" \
        "$([ "$_APUR_ESTADO" = ausente ] && echo AUSENTE || echo 'NAO APURADO')" "$_APUR_MOTIVO"
fi

# Governor e frequência decidem se a medição é comparável entre execuções.
le_arquivo "governor" /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
GOVERNOR=$VALOR
# Os dois abaixo sao mutuamente exclusivos por construcao (um driver Intel, um
# AMD): o AUSENTE de um deles e o caso NORMAL, e por isso ele precisa aparecer
# como fato, e nao como buraco.
le_arquivo "turbo (intel_pstate/no_turbo)" /sys/devices/system/cpu/intel_pstate/no_turbo
TURBO_INTEL=$VALOR
le_arquivo "turbo (cpufreq/boost)" /sys/devices/system/cpu/cpufreq/boost
TURBO_AMD=$VALOR

le_campo "hugepages (total)"  /proc/meminfo HugePages_Total; HUGE_TOTAL=$VALOR
le_campo "hugepages (livres)" /proc/meminfo HugePages_Free;  HUGE_LIVRES=$VALOR
le_campo "hugepages (tamanho)" /proc/meminfo Hugepagesize;   HUGE_TAM=$VALOR

# MemTotal vem em kB; a conversao para GiB usa `awk` porque o formato "%.1f"
# respeita o separador decimal do locale, e a tabela ja publicada tras virgula.
# Com `awk` fora do PATH isto vira NAO APURADO, e nao um numero arredondado no
# escuro.
MEM_TOTAL=$NAO_APURADO
if apur_campo /proc/meminfo MemTotal; then
    mem_kb=${_APUR%% *}
    if numerico "$mem_kb"; then
        if apur_cmd awk -v kb="$mem_kb" 'BEGIN{printf "%.1f GiB", kb/1048576}'; then
            MEM_TOTAL=$_APUR
        else
            registrar_lacuna "memoria total" "NAO APURADO" "$_APUR_MOTIVO"
        fi
    else
        registrar_lacuna "memoria total" "NAO APURADO" \
            "/proc/meminfo traz MemTotal com valor nao numerico (\"$_APUR\")"
    fi
else
    registrar_lacuna "memoria total" \
        "$([ "$_APUR_ESTADO" = ausente ] && echo AUSENTE || echo 'NAO APURADO')" "$_APUR_MOTIVO"
fi

roda "kernel" uname -r; KERNEL=$VALOR

# `. /etc/os-release` EXECUTA o arquivo para ler um campo; apur_campo apenas o
# le. Alem de nao executar nada, ele separa "nao ha PRETTY_NAME" de "nao li o
# arquivo", que era o mesmo vazio.
DISTRO=$NAO_APURADO
if apur_campo /etc/os-release PRETTY_NAME; then
    DISTRO=$_APUR
    DISTRO=${DISTRO%\"}; DISTRO=${DISTRO#\"}   # o valor vem entre aspas
else
    registrar_lacuna "distribuicao" \
        "$([ "$_APUR_ESTADO" = ausente ] && echo AUSENTE || echo 'NAO APURADO')" "$_APUR_MOTIVO"
fi

# Linha de comando do kernel: os parametros que mudam medicao. O filtro roda no
# proprio shell -- `tr` e `grep` fora do PATH davam lista vazia, que a linha
# seguinte transformava em "(nenhum parâmetro relevante)": uma afirmacao sobre
# o boot do leitor tirada de duas ferramentas que nao rodaram.
if apur_ler /proc/cmdline; then
    CMDLINE=""
    for tok in $_APUR; do
        case "$tok" in
            *iommu*|*hugepages*|*isolcpus*|*nohz*|*mitigations*|*processor.max_cstate*|*intel_idle*)
                CMDLINE="$CMDLINE$tok " ;;
        esac
    done
    [ -n "$CMDLINE" ] || CMDLINE="(nenhum parâmetro relevante)"
else
    CMDLINE=$NAO_APURADO
    registrar_lacuna "linha de comando do kernel" \
        "$([ "$_APUR_ESTADO" = ausente ] && echo AUSENTE || echo 'NAO APURADO')" "$_APUR_MOTIVO"
fi

roda "DPDK"  pkg-config --modversion libdpdk; DPDK=$VALOR
roda "compilador" cc --version;               CC=$VALOR
roda "meson" meson --version;                 MESON=$VALOR
roda "ninja" ninja --version;                 NINJA=$VALOR

# Mitigações de CPU mudam o custo de syscall em ordem de grandeza: sem isto,
# comparar com a literatura leva a conclusão errada.
#
# CUIDADO COM O FORMATO — duas armadilhas já cortaram exatamente o dado caro:
#
#   1. o valor de uma mitigação ATIVA contém ':' no meio. O kernel publica
#      "spectre_v2:Mitigation: Enhanced / Automatic IBRS; IBPB: conditional;
#      STIBP: always-on; RSB filling; ...". Separar por ':' e guardar só o
#      segundo campo reduz tudo a "spectre_v2=Mitigation", que não informa nada
#      — e informa MENOS justamente nas ativas, que são as que custam ciclo;
#   2. truncar a string inteira num limite fixo (`cut -c1-200`) descarta o fim
#      da lista. Como a ordem é alfabética, o que some é spectre_*, srso e
#      vmscape: de novo, as caras. E some em silêncio, sem reticência.
#
# A forma abaixo nao corta nada: cada arquivo e um par (nome = conteudo
# integro). Para caber na leitura sem perder informação, as ativas saem por
# extenso e as inativas viram uma lista de nomes: "Not affected" não custa
# ciclo nenhum, e é o custo que este campo existe para registrar.
#
# TERCEIRA armadilha, e ela e a desta rodada: o `grep -H . .../*` anterior
# devolvia vazio tanto para "este kernel nao expoe vulnerabilities/" quanto
# para "nao pude percorrer o diretorio", e as duas caiam em "(não expostas)" --
# uma afirmacao sobre o kernel do leitor.
MITIG_ATIVAS=""
MITIG_INATIVAS=""
if apur_listar /sys/devices/system/cpu/vulnerabilities; then
    vulns=$_APUR
    sep_a=""; sep_i=""; falhas_mitig=0; motivo_mitig=""
    while IFS= read -r nome; do
        [ -n "$nome" ] || continue
        if ! apur_ler "/sys/devices/system/cpu/vulnerabilities/$nome"; then
            falhas_mitig=$((falhas_mitig + 1)); motivo_mitig=$_APUR_MOTIVO
            continue
        fi
        if [ "$_APUR" = "Not affected" ]; then
            MITIG_INATIVAS="${MITIG_INATIVAS}${sep_i}${nome}"; sep_i=", "
        else
            MITIG_ATIVAS="${MITIG_ATIVAS}${sep_a}${nome}=${_APUR}"; sep_a="; "
        fi
    done <<<"$vulns"
    if [ "$falhas_mitig" -gt 0 ]; then
        registrar_lacuna "mitigacoes" "NAO APURADO" \
            "$falhas_mitig arquivo(s) de vulnerabilities/ nao puderam ser lidos; o primeiro: $motivo_mitig"
    fi
    [ -n "$MITIG_ATIVAS" ] || MITIG_ATIVAS="(nenhuma ativa)"
    [ -n "$MITIG_INATIVAS" ] || MITIG_INATIVAS="(nenhuma)"
elif [ "$_APUR_ESTADO" = "ausente" ]; then
    MITIG_ATIVAS="(não expostas por este kernel)"
    MITIG_INATIVAS="(não expostas por este kernel)"
    registrar_lacuna "mitigacoes" AUSENTE "$_APUR_MOTIVO"
else
    MITIG_ATIVAS=$NAO_APURADO
    MITIG_INATIVAS=$NAO_APURADO
    registrar_lacuna "mitigacoes" "NAO APURADO" "$_APUR_MOTIVO"
fi

# Sem `cut`: o nome da NIC é curto o bastante para caber inteiro, e cortá-lo
# produzia "RTL8125 2.5GbE Control" — que parece um modelo, e não é.
#
# O filtro por "ethernet" tambem saiu do `grep`: com ele fora do PATH a linha
# sumia e a NIC virava "-", indistinguivel de uma maquina sem placa.
NIC=$NAO_APURADO
NIC_DRV=$NAO_APURADO
if apur_cmd lspci -nn; then
    while IFS= read -r linha; do
        case "${linha,,}" in
            *ethernet*) NIC=$linha; break ;;
        esac
    done <<<"$_APUR"
    if [ "$NIC" = "$NAO_APURADO" ]; then
        NIC="(nenhuma linha de Ethernet no lspci)"
        NIC_DRV="$AUSENTE"
    fi
else
    registrar_lacuna "NIC" "NAO APURADO" "$_APUR_MOTIVO"
fi

# O driver e o da PRIMEIRA interface nao-lo do `ip link`, que pode nao ser a
# mesma placa da linha acima -- a limitacao e antiga e continua declarada aqui.
if [ "$NIC_DRV" = "$NAO_APURADO" ] && [ "$NIC" != "$NAO_APURADO" ]; then
    if apur_cmd ip -o link show; then
        iface=""
        while IFS= read -r linha; do
            nome=${linha#*: }; nome=${nome%%:*}
            [ -n "$nome" ] && [ "$nome" != lo ] && { iface=$nome; break; }
        done <<<"$_APUR"
        if [ -z "$iface" ]; then
            NIC_DRV="(nenhuma interface alem de lo)"
        elif apur_link "/sys/class/net/$iface/device/driver"; then
            NIC_DRV=${_APUR##*/}
        elif [ "$_APUR_ESTADO" = "ausente" ]; then
            # Interface sem device/driver e interface VIRTUAL -- fato, nao falha.
            NIC_DRV="(interface $iface nao tem driver de dispositivo: virtual?)"
            registrar_lacuna "driver da NIC" AUSENTE "$_APUR_MOTIVO"
        else
            registrar_lacuna "driver da NIC" "NAO APURADO" "$_APUR_MOTIVO"
        fi
    else
        registrar_lacuna "driver da NIC" "NAO APURADO" "$_APUR_MOTIVO"
    fi
fi

# --- saída ----------------------------------------------------------------

# lacunas_texto <prefixo> -- imprime a secao "o que nao foi apurado"
lacunas_texto() {
    local prefixo=$1 campo estado motivo
    [ -n "$_LACUNAS" ] || return 0
    while IFS='|' read -r campo estado motivo; do
        [ -n "$campo" ] || continue
        printf '%s%s [%s]: %s\n' "$prefixo" "$campo" "$estado" "$motivo"
    done <<<"$_LACUNAS"
}

if [ "$MODO" = "--markdown" ]; then
    cat <<EOF
| Item | Valor |
|---|---|
| CPU | $CPU_MODELO |
| Núcleos / threads | $CPU_FISICOS físicos, $CPU_LOGICAS lógicos ($CPU_SMT thread(s) por núcleo) |
| Soquetes / nós NUMA | $CPU_SOQUETES / $NUMA_NOS |
| L3 | $CPU_L3 |
| Domínios de cache L3 | \`$CPU_DOMINIOS\` |
| Sinalizadores de TSC | $CPU_FLAGS |
| Governor / turbo | $GOVERNOR / intel=$TURBO_INTEL amd_boost=$TURBO_AMD |
| Memória | $MEM_TOTAL |
| Hugepages | $HUGE_TOTAL de $HUGE_TAM ($HUGE_LIVRES livres) |
| Kernel | $KERNEL |
| Distribuição | $DISTRO |
| Linha de comando do kernel | \`$CMDLINE\` |
| NIC | $NIC |
| Driver da NIC | $NIC_DRV |
| DPDK | $DPDK |
| Compilador | $CC |
| Meson / Ninja | $MESON / $NINJA |
| Mitigações ativas | $MITIG_ATIVAS |
| Mitigações não aplicáveis | $MITIG_INATIVAS |
EOF
    # A tabela colada num documento leva junto a explicacao das celulas que nao
    # sao medicao. Sem isto, um "(nao apurado)" atravessaria a copia sem dizer
    # por que -- e quem lesse o documento teria de volta o marcador mudo.
    if [ -n "$_LACUNAS" ]; then
        echo ""
        echo "Campos não medidos nesta execução:"
        echo ""
        lacunas_texto "- "
    fi
    exit 0
fi

cat <<EOF

== Ambiente de medição ==

  Processador
    modelo ................. $CPU_MODELO
    nucleos/threads ........ $CPU_FISICOS fisicos, $CPU_LOGICAS logicos ($CPU_SMT por nucleo)
    soquetes / nos NUMA .... $CPU_SOQUETES / $NUMA_NOS
    L3 ..................... $CPU_L3
    dominios de cache L3 ... $CPU_DOMINIOS
    sinalizadores de TSC ... $CPU_FLAGS

  Estado de frequencia (decide se a medicao e comparavel entre execucoes)
    governor ............... $GOVERNOR
    turbo .................. intel_no_turbo=$TURBO_INTEL  amd_boost=$TURBO_AMD

  Memoria
    total .................. $MEM_TOTAL
    hugepages .............. $HUGE_TOTAL de $HUGE_TAM ($HUGE_LIVRES livres)

  Sistema
    kernel ................. $KERNEL
    distribuicao ........... $DISTRO
    linha de comando ....... $CMDLINE
    mitigacoes ativas ...... $MITIG_ATIVAS
    nao aplicaveis ......... $MITIG_INATIVAS

  Rede
    NIC .................... $NIC
    driver ................. $NIC_DRV

  Ferramental
    DPDK ................... $DPDK
    compilador ............. $CC
    meson / ninja .......... $MESON / $NINJA
EOF

if [ -n "$_LACUNAS" ]; then
    cat <<EOF

  O que NAO foi medido nesta execucao, e por que
    (AUSENTE = o fato e a inexistencia; NAO APURADO = nao foi possivel olhar,
     e nada se pode afirmar sobre o valor)

EOF
    lacunas_texto "    "
fi

cat <<EOF

  Para colar num documento: ./scripts/ambiente.sh --markdown

EOF
