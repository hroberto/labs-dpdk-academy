#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
#
# Verificação local antes de commitar.
#
# POR QUE ESTE SCRIPT EXISTE
#
# A primeira execução da CI na história deste projeto falhou com 7 erros e 2
# timeouts. **Todas as causas eram detectáveis nesta máquina**, e nenhuma foi
# detectada, porque a verificação manual antes do commit era "rodei os testes" —
# o que não cobre o que a CI cobre.
#
# Cada bloco abaixo existe por causa de um incidente concreto, e o comentário
# diz qual. Um verificador cujas regras ninguém sabe justificar vira ritual, e
# ritual se ignora no dia em que atrapalha.
#
# O QUE ELE NÃO É
#
# Não substitui a CI: aqui o DPDK é 25.11 e lá é 23.11, e essa diferença já
# produziu dois defeitos. O que ele faz é eliminar as falhas que NÃO dependem
# de ambiente — que foram a maioria.
#
# Uso:
#   ./scripts/pre-commit.sh            # completo (~2 min)
#   ./scripts/pre-commit.sh --rapido   # sem a suíte longa (~20 s)
#   ./scripts/pre-commit.sh --instalar # liga como hook do git
set -u
cd "$(dirname "$0")/.."

MODO="completo"
case "${1:-}" in
    --rapido)   MODO="rapido" ;;
    --instalar) MODO="instalar" ;;
    "")         ;;
    *) echo "uso: $0 [--rapido|--instalar]" >&2; exit 2 ;;
esac

BUILD=${DPDK_ACADEMY_BUILD:-build-precommit}
falhas=0
avisos=0

titulo() { printf '\n\033[1m== %s ==\033[0m\n' "$1"; }
ok()     { printf '  [ok]    %s\n' "$1"; }
falha()  { printf '  [FALHA] %s\n' "$1"; falhas=$((falhas + 1)); }
aviso()  { printf '  [aviso] %s\n' "$1"; avisos=$((avisos + 1)); }

# --- instalação como hook -------------------------------------------------
if [ "$MODO" = "instalar" ]; then
    mkdir -p .git/hooks
    cat > .git/hooks/pre-commit <<'HOOK'
#!/usr/bin/env bash
# Instalado por scripts/pre-commit.sh --instalar
exec ./scripts/pre-commit.sh --rapido
HOOK
    chmod +x .git/hooks/pre-commit
    echo "  hook instalado em .git/hooks/pre-commit (modo --rapido)"
    echo "  para pular pontualmente: git commit --no-verify"
    exit 0
fi

# --- 1. Sintaxe: o mais barato, e falha antes de tudo ---------------------
titulo "1. Sintaxe"

erro_sh=0
for f in $(find scripts docs trilha -name '*.sh' 2>/dev/null); do
    bash -n "$f" 2>/dev/null || { falha "bash -n: $f"; erro_sh=1; }
done
[ $erro_sh -eq 0 ] && ok "todos os scripts shell"

if command -v python3 >/dev/null 2>&1; then
    erro_py=0
    for f in scripts/*.py; do
        [ -e "$f" ] || continue
        python3 -m py_compile "$f" 2>/dev/null || { falha "py_compile: $f"; erro_py=1; }
    done
    [ $erro_py -eq 0 ] && ok "todos os scripts python"

    # O workflow da CI é YAML: um erro aqui só apareceria no GitHub.
    if [ -f .github/workflows/ci.yml ]; then
        python3 -c "import yaml,sys; yaml.safe_load(open('.github/workflows/ci.yml'))" 2>/dev/null \
            && ok "ci.yml é YAML válido" || falha "ci.yml não é YAML válido"
    fi
    if [ -f .github/dependabot.yml ]; then
        python3 -c "import yaml,sys; yaml.safe_load(open('.github/dependabot.yml'))" 2>/dev/null \
            && ok "dependabot.yml é YAML válido" || falha "dependabot.yml não é YAML válido"
    fi
fi

# --- 2. Consistência específica deste projeto -----------------------------
titulo "2. Consistência do projeto"

# INCIDENTE: `--in-memory --no-huge` juntos são rejeitados até o DPDK 23.11
# (`--no-huge` liga `--legacy-mem`, incompatível com `--in-memory`). Passava
# aqui, quebrava na CI. Só vale para INVOCAÇÕES; a prosa pode citar a
# combinação, e cita, para ensinar por que ela falha.
# `-e` e nao `--`: com `--` o grep trata `--include` como NOME DE ARQUIVO, e
# varre tudo -- inclusive a prosa que cita a combinacao para ensinar por que ela
# falha, e este proprio script. Foi assim na primeira versao daqui.
# AS DUAS ORDENS. A versao anterior casava so '--in-memory --no-huge'; uma
# invocacao escrita '--no-huge --in-memory' passava batido, e a ordem inversa
# existe no repositorio (docs/02-runtime-dpdk/README.md:143, em prosa). Regra
# derivada da CLASSE do defeito e nao da forma em que ele apareceu da primeira
# vez.
combos=$(grep -rnE -e '--in-memory[[:space:]]+(--[a-z-]+[[:space:]]+)*--no-huge' \
                   -e '--no-huge[[:space:]]+(--[a-z-]+[[:space:]]+)*--in-memory' \
         --include='*.sh' --include='meson.build' . 2>/dev/null \
         | grep -vE '^\./build|pre-commit\.sh' | grep -vE ':[0-9]+:\s*#' || true)
if [ -n "$combos" ]; then
    falha "invocação com '--in-memory' e '--no-huge' juntos (rejeitado até o DPDK 23.11)"
    sed 's/^/          /' <<<"$combos"
else
    # O ESCOPO VAI NA MENSAGEM. Afirmar "nenhuma invocacao" sem dizer onde se
    # procurou e afirmar mais do que se apurou -- e um verificador que anuncia
    # ausencia e a forma mais silenciosa de um controle mentir.
    ok "nenhuma invocação combina --in-memory com --no-huge (varridos: *.sh e meson.build, as duas ordens; *.md fica de fora de propósito, a prosa cita a combinação para ensinar por que falha)"
fi

# INCIDENTE: `actions/checkout@v4` era tag móvel. Fixado por SHA; esta regra
# impede que alguém reintroduza a tag sem perceber.
if [ -f .github/workflows/ci.yml ]; then
    if grep -qE 'uses: [a-zA-Z0-9_-]+/[a-zA-Z0-9_.-]+@v[0-9]' .github/workflows/ci.yml; then
        falha "ação de CI referenciada por TAG; fixe por SHA de 40 caracteres"
        grep -nE 'uses: .*@v[0-9]' .github/workflows/ci.yml | sed 's/^/          /'
    else
        ok "ações da CI fixadas por SHA"
    fi
    # INCIDENTE: sem bloco `permissions:`, o GITHUB_TOKEN herda escrita.
    grep -q '^permissions:' .github/workflows/ci.yml \
        && ok "GITHUB_TOKEN com permissões declaradas" \
        || falha "ci.yml sem bloco 'permissions:' (o token herda escrita)"

    # INCIDENTE: fixar por SHA impede que a TAG seja reapontada, mas nao diz
    # QUAL versao o SHA e. Horas depois de ligar o Dependabot, ele abriu um PR
    # levando actions/checkout de v4 para v7 -- tres versoes maiores de salto --
    # e a verificacao acima aprovaria, porque continua sendo um SHA valido.
    #
    # Esta checagem resolve o SHA de volta para a tag e compara com o major que
    # o workflow declara no comentario ao lado do pin. E AVISO, nao falha:
    # depende de rede e de `gh`, e um pre-commit que exige os dois nao roda em
    # aviao nem em maquina de terceiros.
    if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
        while read -r acao sha; do
            [ -n "$sha" ] || continue
            major=$(grep -oE "# *Corresponde a v[0-9]+" .github/workflows/ci.yml | grep -oE 'v[0-9]+' | head -1)
            [ -n "$major" ] || { aviso "pin de $acao sem 'Corresponde a vN' no comentario"; continue; }
            # APURACAO-OK: o vazio aqui NAO e publicado como fato -- as duas linhas
            # abaixo o traduzem em "nao consegui resolver (offline?)", que e um
            # AVISO nomeando a nao-apuracao, e nunca em "o pin esta certo".
            esperado=$(timeout 20 gh api "repos/$acao/git/ref/tags/$major" --jq '.object.sha' 2>/dev/null || echo "")
            if [ -z "$esperado" ]; then
                aviso "nao consegui resolver $acao@$major (offline?)"
            elif [ "$esperado" = "$sha" ]; then
                ok "$acao fixada em $major (SHA confere com a tag)"
            else
                aviso "$acao: o SHA fixado NAO e mais o topo de $major"
                printf '          fixado:  %s\n          %s hoje: %s\n' "$sha" "$major" "$esperado"
                printf '          Se veio de um PR do Dependabot, confira se e salto de major.\n'
            fi
        done < <(grep -oE 'uses: [a-zA-Z0-9_-]+/[a-zA-Z0-9_.-]+@[0-9a-f]{40}' .github/workflows/ci.yml \
                 | sed 's/uses: //' | tr '@' ' ')
    else
        aviso "gh ausente ou nao autenticado: versao do SHA fixado nao verificada"
    fi
fi

# --- 3. Apuração: "não sei" não pode sair como "não" -----------------------
titulo "3. Apuracao (nao sei != nao)"

# O INCIDENTE QUE ESTA SEÇÃO REGISTRA, e ele é o motivo de ela existir.
#
# `scripts/xdp-zerocopy.sh` passou por DUAS rodadas de correção instância a
# instância. A rodada 1 achou 10 defeitos; a rodada 2, com quatro agentes em
# paralelo, fechou quatro deles -- e a reverificação encontrou o MESMO defeito
# em outras sete células, duas delas ABERTAS pelas próprias correções. O caso
# que decidiu esta seção:
#
#     tamanho=$(stat -c '%s' "$f" 2>/dev/null || printf 0)
#
# essa linha foi escrita DENTRO da função `_elf_defeito`, que existia para
# impedir que um módulo truncado publicasse "0 símbolos" como se fosse
# medição. Com `stat` ausente, `tamanho` virava 0, e a função passava a acusar
# "ELF TRUNCADO ... o arquivo tem so 0 (descompressão incompleta -- TMPDIR sem
# espaço?)" para um módulo intacto: três afirmações falsas numa frase, e uma
# CAUSA inventada que manda o leitor caçar o problema errado.
#
# A conclusão é a razão desta seção existir: o defeito não é uma LISTA DE
# LUGARES, é um PADRÃO MECÂNICO. Corrigir lugar a lugar não converge -- a
# rodada 2 provou isso reabrindo, dentro da própria correção, o defeito que a
# correção fechava. O que converge é uma regra que varre a árvore.
#
# O DEFEITO, ENUNCIADO: informação que não pôde ser apurada -- por falta de
# privilégio, por erro engolido, por ferramenta ausente -- sai renderizada como
# um FATO NEGATIVO ("não tem suporte", "não existe", "0"). "Não sei" virando
# "não".
#
# O CONTRATO DA REGRA (o que ela pega, e por que nesse nível)
#
#   FALHA -- só onde não há leitura alternativa possível:
#     [1] `cmd || echo <número>` / `|| printf <número>`: a falha vira um
#         NÚMERO. Número é fato publicável, e "0 símbolos" é indistinguível de
#         "driver sem suporte". Não existe caso em que "não apurei" deva sair
#         como algarismo -- por isso aqui é falha, e não aviso. Um padrão
#         legítimo continua possível e é uma linha a mais: teste o rc, DIGA que
#         está assumindo um valor, e assuma-o.
#     [2] `grep -c ... || true`: `grep -c` sai 1 quando não há casamento
#         (informação legítima: o número é zero) e >1 quando ERRA. O `|| true`
#         apaga a diferença, e o erro vira o número zero.
#
#   AVISO, com a linha citada, para JULGAMENTO HUMANO -- onde a regra não sabe
#   decidir sozinha, e um falso positivo que bloqueia é pior que ausência:
#     [3] `|| true` / `|| :` num comando cuja SAÍDA É CAPTURADA (`$( )`).
#         Aqui está a distinção que o contrato pede: `|| true` é LEGÍTIMO
#         quando o comando roda por EFEITO COLATERAL e o valor não vai para
#         lugar nenhum (`rm -f x || true`) -- e essas a regra nem olha, porque
#         não há captura. Quando há captura, o valor vai virar texto publicado
#         ou comparação, e aí o rc importa. Se é publicado ou não, a regra NÃO
#         sabe: por isso avisa em vez de falhar.
#     [4] `|| echo <literal não numérico>` (`'-'`, `'?'`, `''`): a falha vira
#         um marcador. Marcador é melhor que número falso, mas continua sem
#         dizer POR QUE não apurou. Julgamento humano: o relatório em volta
#         nomeia o que faltou?
#     [5] `[ ! -r X ]` sem um teste de EXISTÊNCIA do MESMO alvo antes: ENOENT
#         e EACCES saem iguais, e a mensagem escolhe um dos dois. Foi assim que
#         "o módulo existe e o uid não pode lê-lo" saiu para um arquivo que não
#         existia.
#
#   O QUE A REGRA DELIBERADAMENTE NÃO PEGA, e é preciso dizer para que a
#   ausência de alarme não seja lida como ausência de defeito:
#     - `2>/dev/null` SOZINHO não é defeito: suprimir stderr e ainda testar o
#       rc é legítimo. O defeito é suprimir stderr E descartar o rc, e é isso
#       que [1]-[4] procuram.
#     - `$(cmd 2>/dev/null)` cujo VAZIO é interpretado adiante como resposta.
#       Essa é a forma mais comum e a regra não a alcança: exigiria saber o que
#       o código faz com a variável depois. Continua sendo revisão humana.
#     - `.py`: só arquivos `.sh` são varridos. As mesmas formas existem em
#       Python (`except: return 0`) e não são cobertas aqui.
#     - comentário de linha inteira é PROSA e é pulado de propósito: vários
#       arquivos deste projeto NARRAM o incidente citando `|| true` e
#       `|| echo 0` no texto, e cobrar a narrativa faria a regra gritar
#       exatamente onde alguém já fez o trabalho.
#
#   EXCEÇÕES: são explícitas, por LINHA, e carregam a justificativa no próprio
#   lugar do código -- um comentário `APURACAO-OK` seguido de dois-pontos e do
#   motivo, na própria linha ou na de cima. (Aqui o marcador está escrito sem
#   os dois-pontos de propósito: com eles, este parágrafo contaria como uma
#   exceção, e o total impresso abaixo deixaria de fechar.) Não há lista implícita
#   dentro do regex, e não há exceção por arquivo: um arquivo inteiro isento é
#   como a verificação morre em silêncio. O total de exceções honradas é
#   impresso a cada execução, para que ele não cresça calado.
#
# POR QUE EM AWK, E NÃO EM PYTHON COMO OS VERIFICADORES DE DOCUMENTAÇÃO: os
# blocos de `.py` desta ferramenta estão sob `command -v python3`, e sem o
# interpretador eles simplesmente não rodam -- a verificação some sem dizer
# nada, que é a mesma classe de defeito que esta seção persegue. `awk` já é
# dependência dos scripts varridos.
awk_apuracao='
BEGIN { falhas = 0; avisos = 0; excecoes = 0 }
FNR == 1 { delete existe; marcado = 0 }
# A escotilha vem ANTES do salto de comentario, para que a justificativa possa
# ser escrita na linha DE CIMA quando a linha ofensora ja e longa demais.
# A classe [-] impede a regra de contar a si mesma como excecao.
/APURACAO[-]OK:/ { excecoes++; marcado = 1; next }
/^[ \t]*#/ { next }
{
    if (marcado) { marcado = 0; next }
    linha = $0
    if (match(linha, /\[\[? +!? *-[edfsL] +[^]]+\]/)) {
        alvo = substr(linha, RSTART, RLENGTH)
        gsub(/\[\[? +!? *-[edfsL] +/, "", alvo); gsub(/ *\]+$/, "", alvo); gsub(/"/, "", alvo)
        existe[alvo] = FNR
    }
    # [1] e [4]: a falha vira um valor literal.
    # Duas formas NAO sao resgate de falha e ficam de fora: o ternario
    # "A && B || C" e o condicional "[ teste ] || comando".
    if (linha ~ /\|\|[ \t]*(echo|printf)[ \t]/ && linha !~ /&&.*\|\|/ && linha !~ /\][ \t]*\|\|/) {
        resto = linha
        sub(/^.*\|\|[ \t]*(echo|printf)[ \t]+/, "", resto)
        sub(/[ \t].*$/, "", resto); sub(/\).*$/, "", resto)
        lit = resto; gsub(/['\''"]/, "", lit)
        if (lit ~ /^-?[0-9]+$/)
            emite("FALHA", "a falha vira o NUMERO " lit "; numero e fato publicavel", linha)
        else if (lit == "")
            emite("aviso", "a falha vira STRING VAZIA, que o codigo adiante pode ler como resposta", linha)
        else
            emite("aviso", "a falha vira o literal \"" lit "\"; o relatorio em volta diz o que faltou?", linha)
    }
    # [3] rc descartado num comando cuja saida e capturada.
    if (linha ~ /\|\|[ \t]*(true|:)[ \t]*(\)|;|$)/ && linha ~ /\$\(/)
        emite("aviso", "rc descartado num comando cuja SAIDA e capturada", linha)
    # [2] grep -c com o rc descartado.
    if (linha ~ /grep[ \t]+-[a-zA-Z]*c/ && linha ~ /\|\|[ \t]*(true|:)/)
        emite("FALHA", "grep -c com rc descartado: erro (rc>1) fica igual a zero casamentos (rc=1)", linha)
    # [5] leitura sem existencia.
    if (match(linha, /\[\[? +! +-[rwx] +[^]]+\]/)) {
        alvo = substr(linha, RSTART, RLENGTH)
        gsub(/\[\[? +! +-[rwx] +/, "", alvo); gsub(/ *\]+$/, "", alvo); gsub(/"/, "", alvo)
        if (!(alvo in existe))
            emite("aviso", "leitura de " alvo " sem teste de EXISTENCIA antes: ENOENT e EACCES saem iguais", linha)
    }
}
function emite(nivel, motivo, texto,   corte) {
    corte = texto; sub(/^[ \t]+/, "", corte)
    if (length(corte) > 88) corte = substr(corte, 1, 85) "..."
    printf "%s|%s:%d|%s|%s\n", nivel, FILENAME, FNR, motivo, corte
    if (nivel == "FALHA") falhas++; else avisos++
}
END { printf "RESUMO|%d|%d|%d\n", falhas, avisos, excecoes }'

apur=$(find scripts docs trilha -name '*.sh' 2>/dev/null | sort | xargs awk "$awk_apuracao")
apur_resumo=$(grep '^RESUMO|' <<<"$apur")
apur_falhas=$(cut -d'|' -f2 <<<"$apur_resumo")
apur_avisos=$(cut -d'|' -f3 <<<"$apur_resumo")
apur_exc=$(cut -d'|' -f4 <<<"$apur_resumo")

mostrar_apuracao() {
    grep "^$1|" <<<"$apur" | while IFS='|' read -r _ onde motivo trecho; do
        printf '          %s: %s\n            %s\n' "$onde" "$motivo" "$trecho"
    done
}
if [ "${apur_falhas:-0}" -gt 0 ]; then
    falha "$apur_falhas linha(s) em que a falha da coleta vira um NUMERO publicavel"
    mostrar_apuracao FALHA
else
    ok "nenhuma falha de coleta virando numero publicavel"
fi
if [ "${apur_avisos:-0}" -gt 0 ]; then
    aviso "$apur_avisos linha(s) para julgamento humano (rc descartado, marcador mudo, leitura sem existencia)"
    mostrar_apuracao aviso
fi
printf '  [nota]  %s excecao(oes) marcadas com APURACAO-OK, cada uma justificada na propria linha\n' \
    "${apur_exc:-0}"

# --- 4. Nada sensível ------------------------------------------------------
titulo "4. Informações sensíveis"

# INCIDENTE, e a seção 3 acima é que o apontou -- nesta ferramenta, não no
# script auditado. As três varreduras abaixo eram
#     seg=$(git grep ... 2>/dev/null || true)
#     [ -z "$seg" ] && ok "nenhum padrão de credencial"
# e o `|| true` apagava a diferença entre os DOIS motivos de `git grep` não
# imprimir nada: rc=1 ("procurei e não há") e rc>1 ("não consegui procurar" --
# fora de um repositório git, índice corrompido, pathspec inválido). O segundo
# saía como `[ok] nenhum padrão de credencial`: a verificação que não rodou,
# reportada como verificação que passou. Um verificador que comete o defeito
# que ele denuncia é pior que nenhum, porque empresta autoridade ao silêncio.
#
# `git grep` documenta rc=0 com casamento, rc=1 sem casamento; qualquer outro é
# erro. É essa a separação abaixo, e o erro é FALHA, não aviso: uma varredura
# de credencial que não rodou não pode liberar um commit.
varre_git_grep() {   # varre_git_grep <rotulo> <nivel: falha|aviso> <args do git grep...>
    local rotulo=$1 nivel=$2 saida rc
    shift 2
    saida=$(git grep -nI "$@" 2>&1)
    rc=$?
    case "$rc" in
        0)  if [ "$nivel" = falha ]; then falha "$rotulo encontrado"; else aviso "$rotulo encontrado"; fi
            sed 's/^/          /' <<<"$saida" | head -10 ;;
        1)  ok "nenhum $rotulo" ;;
        *)  falha "NAO APURADO: git grep saiu com codigo $rc procurando $rotulo -- a varredura nao rodou, e isto nao e o mesmo que nao haver nada"
            sed 's/^/          /' <<<"$saida" | head -10 ;;
    esac
}

varre_git_grep "padrão de credencial" falha \
    -E '(BEGIN [A-Z ]*PRIVATE KEY|ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}|AKIA[0-9A-Z]{16}|xox[baprs]-[0-9A-Za-z-]{10,})' -- .

# Caminho absoluto da máquina de quem escreveu vaza usuário e quebra para
# terceiros que clonarem.
varre_git_grep "caminho absoluto de máquina" aviso '/home/[a-z]' -- . ':!*.md'

# Endereço MAC identifica hardware de quem publicou. Saída de testpmd colada
# num documento é o caminho mais provável.
varre_git_grep "endereço MAC" aviso -E '\b([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}\b' -- .

# --- 5. Documentação --------------------------------------------------------
titulo "5. Documentação"

if [ -x scripts/verificar-links.py ]; then
    if out=$(./scripts/verificar-links.py 2>&1); then
        ok "$(tail -1 <<<"$out" | sed 's/^ *//')"
    else
        falha "links ou referências quebrados"; sed 's/^/          /' <<<"$out" | head -8
    fi
fi
if [ -x scripts/verificar-ancoras.py ]; then
    if out=$(./scripts/verificar-ancoras.py 2>&1); then
        ok "$(tail -1 <<<"$out" | sed 's/^ *//')"
        # INCIDENTE desta integração: o gate imprimia SÓ a última linha (o
        # resumo) quando o verificador saía 0, e o verificador sai 0 mesmo
        # tendo encontrado pendências que ele não conseguiu apurar -- entre
        # elas "heredoc sem terminador até o fim do arquivo", que significa
        # que centenas de linhas NÃO foram varridas. O comentário de
        # verificar-ancoras.py diz "um erro que se anuncia é recuperável; um
        # que se cala, não" -- e era esta integração que o calava, imprimindo
        # [ok] por cima. As pendências viram AVISO: não bloqueiam (o
        # verificador não as considera falha) e param de sumir.
        pend=$(grep -iE 'heredoc|nao tokenizou|nao leu como' <<<"$out")
        if [ -n "$pend" ]; then
            aviso "o verificador de âncoras deixou pendência(s) NÃO APURADA(S)"
            sed 's/^ */          /' <<<"$pend" | head -6
        fi
    else
        falha "âncoras de linha desatualizadas"
        # head -20 e nao -8: com -8 a execucao real cortava a secao
        # "âncoras NAO verificadas" logo depois do cabecalho, e o leitor via o
        # titulo sem um item sequer embaixo.
        sed 's/^/          /' <<<"$out" | head -20
    fi
fi

# --- 6. Build e testes ------------------------------------------------------
titulo "6. Build e testes"

if ! pkg-config --exists libdpdk 2>/dev/null; then
    aviso "DPDK ausente: build e testes pulados (a CI os fará)"
else
    if [ ! -f "$BUILD/build.ninja" ]; then
        meson setup "$BUILD" >/dev/null 2>&1 || { falha "meson setup falhou"; }
    fi
    saida_build=$(ninja -C "$BUILD" 2>&1)
    rc=$?
    # A barra do projeto é ZERO avisos, e aviso não falha o build por padrão.
    avs=$(grep -c 'warning:' <<<"$saida_build" | head -1)
    if [ $rc -ne 0 ]; then
        falha "build falhou"; grep -E 'error:' <<<"$saida_build" | head -5 | sed 's/^/          /'
    elif [ "${avs:-0}" -gt 0 ]; then
        falha "$avs aviso(s) de compilação — a barra do projeto é zero"
        grep 'warning:' <<<"$saida_build" | head -4 | sed 's/^/          /'
    else
        ok "build limpo, zero avisos"
    fi

    if [ "$MODO" = "completo" ]; then
        # Suíte com os MESMOS tetos da CI. Rodar só o padrão local esconde
        # timeout: custo-espera leva 40 s aqui e estourou 300 s no runner.
        if DPDK_ACADEMY_AMOSTRAS=3 DPDK_ACADEMY_RODADAS=20000 \
           meson test -C "$BUILD" >/dev/null 2>&1; then
            ok "suíte completa nos tetos da CI"
        else
            falha "suíte falhou (tetos da CI)"
            DPDK_ACADEMY_AMOSTRAS=3 DPDK_ACADEMY_RODADAS=20000 \
              meson test -C "$BUILD" --print-errorlogs 2>&1 | grep -E 'FAIL|TIMEOUT' | head -6 | sed 's/^/          /'
        fi
    else
        if meson test -C "$BUILD" --suite l1 >/dev/null 2>&1; then
            ok "suíte L1 (modo rápido; rode sem --rapido antes de publicar)"
        else
            falha "suíte L1 falhou"
        fi
    fi
fi

# --- 7. Assinatura ----------------------------------------------------------
titulo "7. Assinatura de commit"

# A branch main exige assinatura verificada. Descobrir isso no `git push`,
# depois de escrever a mensagem, é atrito evitável.
# `git config --get` sai 1 quando a chave NAO ESTA DEFINIDA (informação) e
# 127/erro quando o próprio git não roda (não é informação). A forma anterior,
# `$(git config --get commit.gpgsign || echo false)`, dava "false" para os dois
# -- e "git ausente" saía como "o usuário desligou a assinatura", que é uma
# afirmação sobre a configuração dele que ninguém apurou.
if ! command -v git >/dev/null 2>&1; then
    falha "NAO APURADO: git nao esta no PATH, entao a exigencia de assinatura da main nao foi conferida"
else
    gpgsign=$(git config --get commit.gpgsign); rc_cfg=$?
    if [ "$rc_cfg" -gt 1 ]; then
        falha "NAO APURADO: 'git config --get commit.gpgsign' saiu com codigo $rc_cfg"
    elif [ "${gpgsign:-false}" = "true" ]; then
        chave=$(git config --get user.signingkey); rc_key=$?
        if [ "$rc_key" -gt 1 ]; then
            falha "NAO APURADO: 'git config --get user.signingkey' saiu com codigo $rc_key"
        elif [ -n "$chave" ]; then ok "commit.gpgsign ativo (chave ${chave:0:16}…)"
        else falha "commit.gpgsign ativo mas user.signingkey não definido"; fi
    else
        falha "commit.gpgsign desligado — a main exige assinatura verificada"
    fi
fi

# --- veredito ---------------------------------------------------------------
printf '\n\033[1m== Veredito ==\033[0m\n'
[ $avisos -gt 0 ] && printf '  %d aviso(s) — não bloqueiam\n' "$avisos"
if [ $falhas -eq 0 ]; then
    printf '  \033[1mtudo passou.\033[0m Pode commitar.\n\n'
    exit 0
fi
printf '  \033[1m%d falha(s).\033[0m Corrija antes de commitar.\n' "$falhas"
printf '  Para pular deliberadamente: git commit --no-verify\n\n'
exit 1
