#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Verifica o ambiente necessário para a trilha DPDK Academy e informa o que falta.
# Uso: scripts/check-env.sh
#
# DE ONDE VEM CADA FATO
#
# Toda leitura de /sys e /proc deste arquivo passa pelos acessores de
# scripts/lib-apuracao.sh, que devolvem TRI-ESTADO. A razao e o incidente
# registrado na secao de hugepages abaixo: um diagnostico que nao distingue
# "li e nao ha" de "nao consegui ler" acaba fazendo AFIRMACOES sobre a maquina
# do leitor a partir de uma leitura que nao aconteceu.
set -u

RAIZ=$(dirname "$0")

# A biblioteca de apuracao e dependencia DURA: sem ela so restaria leitura
# crua, que e exatamente o que este arquivo deixou de fazer. Faltando,
# recusa-se a rodar em vez de degradar em silencio.
if [ -r "$RAIZ/lib-apuracao.sh" ]; then
    # shellcheck source=lib-apuracao.sh
    . "$RAIZ/lib-apuracao.sh"
else
    echo "ERRO FATAL: $RAIZ/lib-apuracao.sh nao esta la, ou nao pode ser lido." >&2
    echo "            Sem os acessores nao da para distinguir \"nao ha\" de" >&2
    echo "            \"nao consegui ler\": este verificador NAO roda." >&2
    exit 3
fi

ok()   { printf '  ok    - %s\n' "$1"; }
falta(){ printf '  FALTA - %s\n' "$1"; faltas=$((faltas + 1)); }
info() { printf '  info  - %s\n' "$1"; }
faltas=0

echo "Compiladores e ferramentas:"
for t in gcc g++ make pkg-config; do
    if command -v "$t" >/dev/null 2>&1; then ok "$t ($("$t" --version 2>/dev/null | head -1))"; else falta "$t"; fi
done
command -v clang++ >/dev/null 2>&1 && info "clang++ disponivel ($(clang++ --version | head -1))"

echo "Suporte a C++23:"
if printf '#include <print>\n#include <expected>\nint main(){std::println("ok");}\n' | g++ -std=c++23 -x c++ - -o /dev/null 2>/dev/null; then
    ok "g++ compila <print> e <expected> com -std=c++23"
else
    falta "g++ com suporte a C++23 (<print>, <expected>): use GCC 14+ ou Clang 18+"
fi

echo "DPDK:"
if pkg-config --exists libdpdk; then
    ok "libdpdk $(pkg-config --modversion libdpdk) encontrada pelo pkg-config"
else
    falta "libdpdk no pkg-config (instale dpdk-dev / dpdk-devel ou ajuste PKG_CONFIG_PATH)"
fi
for t in dpdk-testpmd dpdk-devbind.py dpdk-hugepages.py; do
    if command -v "$t" >/dev/null 2>&1; then ok "$t"; else info "$t nao encontrado (opcional para os topicos iniciais)"; fi
done

echo "Hugepages (opcionais: os topicos iniciais rodam com --no-huge):"
# NAO APURADO x APURADO ZERO. Este bloco ja foi
#     total=$(awk '/HugePages_Total/ ...' /proc/meminfo 2>/dev/null || echo 0)
# e /proc/meminfo ilegivel -- container com /proc mascarado, `awk` fora do
# PATH -- saia como "nenhuma hugepage reservada", que e uma AFIRMACAO sobre a
# maquina do leitor.
#
# A correcao anterior escreveu A MAO os quatro ramos (nao existe, sem
# privilegio, sem awk, lido sem a chave). Funcionava e nao escalava: cada nova
# leitura da arvore precisava repetir os mesmos quatro ramos, e a rodada
# seguinte mostrou que eles sao repetidos errado. Agora quem os separa e
# `apur_campo`, que distingue "li o arquivo inteiro e a chave nao esta la"
# (AUSENTE, que e fato) de "nao li o arquivo" (NAO APURADO, que nao e fato).
#
# DOIS GANHOS QUE NAO ERAM OBVIOS:
#   1. `awk` deixou de ser dependencia. A extracao e feita com construcao do
#      proprio shell, entao "awk fora do PATH" deixou de ser uma das origens
#      possiveis de resposta errada aqui;
#   2. a chave passou a ser comparada LITERALMENTE. O padrao antigo
#      /HugePages_Total/ casa TAMBEM com HugePages_Total_Surplus se um kernel
#      publicar essa linha antes -- e o numero errado sairia com toda a cara
#      de certo.
if apur_campo /proc/meminfo HugePages_Total; then
    total=$_APUR
    case "$total" in
        ''|*[!0-9]*)
            info "NAO APURADO: /proc/meminfo traz HugePages_Total com valor nao numerico (\"$total\")" ;;
        *)
            livres="(nao apurado)"; motivo_livres=""
            if apur_campo /proc/meminfo HugePages_Free; then livres=$_APUR; else motivo_livres=$_APUR_MOTIVO; fi
            # `Hugepagesize: 2048 kB` -- a primeira palavra e o numero; a
            # unidade e impressa em seguida, como antes.
            tam="(nao apurado)"; motivo_tam=""
            if apur_campo /proc/meminfo Hugepagesize; then tam=${_APUR%% *}; else motivo_tam=$_APUR_MOTIVO; fi
            if [ "$total" -gt 0 ]; then
                ok "$total hugepages de ${tam} kB reservadas ($livres livres)"
            else
                # APURADO, e a resposta e zero -- que e diferente de nao saber.
                info "nenhuma hugepage reservada (rode scripts/preparar-hugepages.sh)"
            fi
            [ -n "$motivo_livres" ] && info "  HugePages_Free NAO APURADO: $motivo_livres"
            [ -n "$motivo_tam" ] && info "  Hugepagesize NAO APURADO: $motivo_tam"
            ;;
    esac
else
    # O veneno de $_APUR ja vem prefixado com "NAO APURADO:" ou "AUSENTE:", e
    # a frase nomeia o que faltou -- nunca "nenhuma hugepage".
    info "hugepages: $_APUR"
fi

# /dev/hugepages: a existencia vem de `apur_listar` (que separa "nao existe" de
# "nao pude olhar"), e dono/modo de `apur_cmd stat` -- `stat` fora do PATH
# deixou de virar linha ausente.
if apur_listar /dev/hugepages; then
    if apur_cmd stat -c '%U:%G %A' /dev/hugepages; then
        info "/dev/hugepages montado ($_APUR)"
    else
        info "/dev/hugepages existe; dono e modo NAO APURADOS: $_APUR_MOTIVO"
    fi
elif [ "$_APUR_ESTADO" = "ausente" ]; then
    info "/dev/hugepages nao existe (hugetlbfs nao montado)"
else
    info "/dev/hugepages: $_APUR"
fi

echo "Drivers para NIC fisica (opcionais ate os topicos de RX/TX):"
# A forma anterior era `lsmod 2>/dev/null | grep -q '^vfio_pci'`, e o rc do
# pipe e o do grep: com `lsmod` fora do PATH (ou `grep`, ou /proc/modules
# mascarado) a saida vazia dava "vfio-pci nao carregado" -- de novo uma
# afirmacao sobre a maquina do leitor tirada de uma consulta que nao rodou.
# `apur_contar` le /proc/modules, que e a MESMA fonte que o lsmod imprime,
# conta com o proprio shell e distingue "contei zero" de "nao pude contar".
if apur_contar /proc/modules '^vfio_pci'; then
    if [ "$_APUR_N" -gt 0 ]; then
        ok "vfio-pci carregado"
    else
        info "vfio-pci nao carregado (modprobe vfio-pci quando for usar uma NIC real)"
    fi
else
    info "NAO APURADO se vfio-pci esta carregado: $_APUR_MOTIVO"
fi

# Duas familias de driver, duas pilhas de dependencia. A de captura total
# (vfio-pci) ja e verificada acima; esta e a bifurcada, que o mlx5 exige e que
# nao tem nada a ver com vfio. Ver scripts/lib-nic.sh.
echo "Pilha RDMA (necessaria so para NIC bifurcada: Mellanox/NVIDIA):"
# shellcheck source=lib-nic.sh
. "$RAIZ/lib-nic.sh"
if rdma_core_ok; then
    ok "rdma-core completo"
elif [ "$(rdma_core_estado)" = "apurado" ]; then
    info "faltando:$(rdma_core_faltando) (instale antes de usar uma ConnectX)"
else
    # Terceiro ramo novo: sem `ldconfig` no PATH a versao anterior listava as
    # TRES bibliotecas como faltando, que e um veredito sobre a maquina do
    # leitor derivado de nao se ter conseguido perguntar.
    info "NAO APURADO se a pilha RDMA esta completa: $(rdma_core_motivo)"
fi
# A forma anterior era
#     ls /sys/bus/pci/devices/*/vendor >/dev/null 2>&1 && grep -lq '0x15b3' ...
# e os dois lados colapsavam nao-apuracao em "nenhuma": glob vazio por falta de
# travessia em /sys, `grep` fora do PATH, arquivo `vendor` sem permissao --
# tudo saia como "nenhuma NIC Mellanox/NVIDIA presente". Numa maquina com
# ConnectX, essa linha manda o leitor seguir pelo caminho de bind errado.
# Agora a lista vem de `apur_listar` e cada vendor de `vendor_apurar`, e os
# dispositivos que NAO puderam ser lidos sao contados e declarados.
if apur_listar /sys/bus/pci/devices; then
    dispositivos=$_APUR
    total_pci=$_APUR_N
    mellanox=""
    vendor_nao_apurado=0
    while IFS= read -r bdf; do
        [ -n "$bdf" ] || continue
        if vendor_apurar "$bdf"; then
            case "${_APUR,,}" in
                0x15b3) mellanox="$mellanox $bdf" ;;
            esac
        else
            vendor_nao_apurado=$((vendor_nao_apurado + 1))
        fi
    done <<<"$dispositivos"
    if [ -n "$mellanox" ]; then
        ok "ha NIC Mellanox/NVIDIA nesta maquina ($mellanox)"
    elif [ "$vendor_nao_apurado" -eq 0 ]; then
        info "nenhuma NIC Mellanox/NVIDIA presente ($total_pci dispositivos PCI lidos)"
    else
        info "nenhum dos $((total_pci - vendor_nao_apurado)) dispositivos PCI lidos e Mellanox/NVIDIA; outros $vendor_nao_apurado tiveram o vendor NAO APURADO: $(vendor_motivo)"
    fi
else
    info "NAO APURADO se ha NIC Mellanox/NVIDIA: $_APUR_MOTIVO"
fi

# O README lista estas quatro como "ferramentas de qualidade". Elas nao sao
# necessarias para compilar nem para rodar a trilha -- por isso entram como
# 'info', e nao como 'FALTA' -- mas antes desta secao o script dizia "Ambiente
# pronto" numa maquina onde NENHUMA delas estava instalada. Um diagnostico que
# so verifica o que ja funciona nao e diagnostico.
echo "Ferramentas de qualidade (opcionais ate a etapa de benchmarking e CI):"
for t in clang-format clang-tidy perf; do
    # Distribuicoes empacotam clang-format-19, clang-tidy-21 etc. sem o nome
    # generico: procurar so o nome curto reportaria ausencia onde ha ferramenta.
    achado=$(command -v "$t" 2>/dev/null || compgen -c "$t-" 2>/dev/null | sort -V | tail -1)
    if [ -n "$achado" ]; then ok "$t ($achado)"; else info "$t nao encontrado"; fi
done
if printf 'int main(){return 0;}\n' | gcc -fsanitize=address,undefined -x c - -o /dev/null 2>/dev/null; then
    ok "sanitizers (ASan/UBSan) disponiveis no gcc"
else
    info "sanitizers indisponiveis no gcc (instale libasan/libubsan)"
fi

echo
if [ $faltas -eq 0 ]; then
    echo "Ambiente pronto para a trilha."
else
    echo "$faltas item(ns) faltando. Veja os requisitos em README.md."
    exit 1
fi
