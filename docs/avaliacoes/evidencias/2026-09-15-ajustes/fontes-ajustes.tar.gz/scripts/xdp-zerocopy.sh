#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
#
# Diagnóstico não destrutivo de suporte a AF_XDP zero-copy, SEM root.
#
# POR QUE ESTE SCRIPT EXISTE, E POR QUE ELE FOI REESCRITO
#
# A versão anterior perguntava a capacidade do netdev com `xdp-loader features`
# e desistia quando não havia privilégio. Medido, como uid 1000:
#
#     $ xdp-loader features enp8s0  ->  "This program must be run as root."
#     $ ./scripts/xdp-zerocopy.sh   ->  "-- Veredito --
#                                        Resultado inconclusivo: ..."
#
# Três defeitos de uma vez. (1) O documento do projeto afirmava "BASIC: no"
# para esta placa e a ferramenta dizia "inconclusivo": texto e ferramenta
# discordando. (2) "Inconclusivo" ali significava "faltou privilégio", que é
# coisa diferente de "não deu para saber" -- e o leitor não tinha como
# descobrir qual das duas era. (3) O ramo que preenche o veredito só rodava com
# root, então nunca foi exercitado por ninguém.
#
# A causa não era o dado ser privilegiado: era a FERRAMENTA ser privilegiada.
# `xdp-loader` exige root porque carrega eBPF e abre mapa BPF; a LEITURA de
# xdp-features é netlink puro, e o kernel declara essa leitura livre --
# NETDEV_CMD_DEV_GET vem com flags 0x0e, sem o bit GENL_ADMIN_PERM que
# NETDEV_CMD_BIND_RX e NETDEV_CMD_NAPI_SET carregam. Confira você mesmo:
#
#     ./scripts/xdp-features.py --politica
#
# Ordem em que ESTE SCRIPT consulta as fontes -- e ela NÃO é a ordem de força
# da evidência:
#   1. netlink genérico, família "netdev" -- sem privilégio nenhum;
#   2. `xdp-loader features` -- MESMO dado, só que exigindo root: fallback;
#   3. inspeção heurística do módulo do driver -- indireta;
#   4. bind real com XDP_ZEROCOPY -- não é executada aqui.
#
# O rótulo "da mais forte para a mais fraca" esteve nesta lista e estava errado:
# o item 4 é a ÚNICA prova, ou seja, a evidência mais forte, e aparece por
# último porque é a última (e a única) que exige privilégio. A hierarquia de
# força está publicada em trilha/04-projeto-final/README.md, da mais fraca para
# a mais forte, e lá o bind real é o topo. Dois textos do mesmo repositório
# dizendo o contrário sobre qual evidência vale mais é o tipo de divergência
# que este projeto trata como defeito, não como estilo.
#
# A inspeção de símbolos NÃO é pré-condição formal: otimização, inlining,
# símbolos internos e renomeações produzem falso negativo. Ela responde "vale a
# pena tentar?", não "isso funciona".
#
# CONVENÇÃO DE SAÍDA. Este arquivo era o contraexemplo do projeto: 47 linhas de
# saída, 15 com acento, enquanto os outros doze scripts imprimem ASCII puro. A
# reescrita normaliza para ASCII.
#
# OS TÍTULOS DE SEÇÃO SÃO INTERFACE PÚBLICA -- e isto é uma correção. Este
# comentário afirmava "nenhum documento cita os títulos de seção (verificado
# com grep em docs/ e trilha/), então isso não quebra referência". A frase era
# verdadeira quando foi escrita e deixou de ser NA MESMA RODADA de mudanças:
# trilha/04-projeto-final/README.md publica hoje o comando
#     ./scripts/xdp-zerocopy.sh enp8s0 | sed -n '/^-- Capacidade/,/^-- Heur/p'
# e, logo abaixo, a saída desse recorte byte a byte. Renomear "-- Capacidade
# anunciada pelo netdev --" ou "-- Heuristica do modulo ..." faz aquele bloco
# passar a reproduzir ZERO linha, em silêncio: o formato `sed` não é âncora, e
# scripts/verificar-ancoras.py não o enxerga. Localize os citadores antes de
# renomear qualquer título daqui:
#     grep -rn -- '-- Capacidade\|-- Heur' docs/ trilha/
#
# Uso:
#   ./scripts/xdp-zerocopy.sh                       # escolhe uma interface fisica
#   ./scripts/xdp-zerocopy.sh enp8s0                # por interface
#   ./scripts/xdp-zerocopy.sh i40e                  # por driver, sem a placa
#   ./scripts/xdp-zerocopy.sh r8169 i40e ice ixgbe  # comparacao entre drivers

set -u

RAIZ=$(dirname "$0")
HELPER="$RAIZ/xdp-features.py"

# --- de onde vem cada fato ----------------------------------------------------
#
# Toda leitura de /sys, /proc, /boot e /lib/modules deste arquivo passa pelos
# acessores de scripts/lib-apuracao.sh. A razao esta escrita nos INCIDENTES
# espalhados por este arquivo, e ela e sempre a mesma: as formas cruas
# (`cat X 2>/dev/null`, `[ -e X ]`, `ls X/* | wc -l`, `readlink -f X 2>/dev/null`)
# devolvem o MESMO vazio -- ou o mesmo zero -- para "nao existe" (fato) e para
# "nao consegui olhar" (nao e fato nenhum). Cada correcao pontual fechava uma
# celula e reabria outra; por isso agora ha UM caminho, e ele devolve TRI-ESTADO.
#
# A biblioteca e dependencia DURA. Sem ela nao ha leitura de sysfs que preserve
# a distincao, e degradar em silencio seria cometer o defeito que este arquivo
# inteiro existe para matar: o script recusa-se a rodar, dizendo o que falta.
if [ -r "$RAIZ/lib-apuracao.sh" ]; then
    # shellcheck source=lib-apuracao.sh
    . "$RAIZ/lib-apuracao.sh"
else
    echo "ERRO FATAL: $RAIZ/lib-apuracao.sh nao esta ao lado deste script," >&2
    echo "            ou nao pode ser lido por este processo." >&2
    echo "            Todo diagnostico daqui depende dos acessores que separam" >&2
    echo "            \"nao existe\" de \"nao consegui ler\". Sem eles este script" >&2
    echo "            NAO roda -- um diagnostico degradado em silencio e pior" >&2
    echo "            do que diagnostico nenhum." >&2
    exit 3
fi

# --- texto_para_arquivo <texto> -----------------------------------------------
#
# ACESSOR QUE FALTA, DECLARADO COMO FALTA. scripts/lib-apuracao.sh trabalha
# sobre CAMINHOS: `apur_campo` e `apur_contar` recebem arquivo, nao string. Duas
# consultas deste script produzem TEXTO em memoria e precisam da mesma
# separacao "li e nao ha" x "nao consegui ler": a saida do `nm` e a do
# descompressor de /proc/config.gz.
#
# A alternativa seria reescrever aqui a contagem e a extracao de campo -- isto
# e, duplicar a biblioteca, que e como o defeito se espalhou da primeira vez.
# Enquanto nao existirem `apur_contar_texto` / `apur_campo_texto`, o texto vira
# arquivo temporario e segue pelo acessor de verdade.
#
# Devolve o caminho em $_TEXTO_ARQ; rc!=0 com o motivo em $_TEXTO_MOTIVO.
_TEXTO_ARQ=""
_TEXTO_MOTIVO=""
texto_para_arquivo() {
    local arq
    _TEXTO_ARQ=""; _TEXTO_MOTIVO=""
    arq=$(mktemp) || {
        _TEXTO_MOTIVO="mktemp falhou (TMPDIR=${TMPDIR:-/tmp} cheio ou sem permissao?)"
        return 1
    }
    if ! printf '%s\n' "$1" > "$arq"; then
        rm -f "$arq"
        _TEXTO_MOTIVO="nao foi possivel escrever o arquivo temporario $arq"
        return 1
    fi
    _TEXTO_ARQ=$arq
}

# --- uid_atual ----------------------------------------------------------------
#
# O uid sai por `id -u`, e nao por $EUID, porque ele NAO e so texto de
# mensagem: e ele que decide se o fallback privilegiado chega a ser executado.
# Por apur_cmd, "id fora do PATH" vira frase, e nao um campo vazio em
# "uid=" -- que e a versao pequena do mesmo defeito.
uid_atual() {
    if apur_cmd id -u; then
        printf '%s' "$_APUR"
    else
        printf 'NAO APURADO: %s' "$_APUR_MOTIVO"
    fi
}

# --- versao_kernel ------------------------------------------------------------
#
# `uname -r` entra na linha de cabecalho, no nome de /boot/config-<versao> e no
# caminho da arvore de modulos. Sem apuracao, `$(uname -r)` ausente montaria o
# caminho "/boot/config-" e o relatorio afirmaria que ELE nao existe -- uma
# frase verdadeira sobre um arquivo que ninguem procurou.
versao_kernel() {
    if apur_cmd uname -r; then
        printf '%s' "$_APUR"
    else
        printf 'NAO APURADA: %s' "$_APUR_MOTIVO"
    fi
}

# RAIZ DO SYSFS DE REDE, PARAMETRIZADA -- e a razao e testabilidade, nao gosto.
#
# Todo defeito grave que sobrou depois de duas rodadas de correcao neste
# arquivo mora numa leitura de /sys que falha: `type` ilegivel elegendo a
# interface errada, sysfs ausente virando "essa interface nao existe",
# device/ sem travessia virando "driver desconhecido/virtual". Nenhum deles
# podia ser exercitado por teste, porque o caminho era literal e absoluto:
# exigia `unshare -Urm` e uma remontagem de /sys, que nao roda em CI comum.
#
# Com a variavel, `scripts/tests/l1_xdp_zerocopy.sh` monta um /sys falso em
# TMPDIR e cobre os tres casos sem privilegio nenhum. Fora do teste ela nao
# existe: sem DPDK_ACADEMY_SYSFS_NET no ambiente, o valor e exatamente o de
# antes, e a saida publicada nao muda.
SYSFS_NET=${DPDK_ACADEMY_SYSFS_NET:-/sys/class/net}

# --- ferramentas de apuracao -------------------------------------------------

# modo_de <caminho>  ->  "modo NNN" ou "modo NAO APURADO: <porque>"
#
# INCIDENTE. Quatro pontos deste arquivo escreviam
#     "$(stat -c '%a' "$X" 2>/dev/null || printf '?')"
# e o relatorio saia com "modo ?". O `?` nao mente, mas tambem nao diz nada:
# nao da para distinguir "o stat nao esta instalado" de "nao consegui olhar
# esse arquivo". Numa frase que ja afirma "existe e o uid nao pode le-lo", o
# `?` era o UNICO sinal de que parte da afirmacao nao tinha sido verificada --
# e sinal que ninguem sabe ler nao e sinal.
#
# A migracao para apur_cmd fecha as duas portas de uma vez e com UMA frase: ele
# distingue "stat fora do PATH" de "stat rodou e falhou" de "stat rodou e nao
# imprimiu nada", que e exatamente o conjunto de casos que o `?` resumia.
modo_de() {
    if apur_cmd stat -c '%a' "$1"; then
        printf 'modo %s' "$_APUR"
    else
        printf 'modo NAO APURADO: %s' "$_APUR_MOTIVO"
    fi
}

# shellcheck source=lib-xdp.sh
. "$RAIZ/lib-xdp.sh"

# O --help nomeia a interface do modo sem argumento. A forma anterior era
#     $(escolher_interface 2>/dev/null || echo '(nenhuma encontrada)')
# e ela tem os dois vicios que este arquivo persegue de uma vez: descarta o rc
# (falha vira um texto) e joga fora o stderr, que e justamente onde
# escolher_interface avisa que descartou uma candidata sem conseguir le-la.
# Aqui o rc e testado e o aviso continua indo para o stderr do processo.
escolhida_para_o_help() {
    local escolhida
    if escolhida=$(escolher_interface); then
        printf '%s' "$escolhida"
    else
        printf '(NAO APURADA nesta maquina -- veja os avisos acima, se houver)'
    fi
}

usage() {
    cat <<EOF
Uso: $0 [interface | driver [driver...]]

Consulta a capacidade AF_XDP zero-copy de uma interface e mostra uma inspecao
heuristica do modulo do driver. O script nao carrega programas XDP e nao altera
a configuracao da rede. Nada aqui exige root.

SEM ARGUMENTO o script escolhe sozinho uma interface fisica e roda o modo
interface -- e este e o primeiro comando publicado no material. O criterio da
escolha e explicito, nao a ordem do glob: entra quem for ethernet (type=1),
tiver device/driver em sysfs e nao tiver wireless/ nem phy80211; entre as
candidatas, PCI ganha de qualquer outro barramento (USB, por exemplo), e so o
empate entre iguais e decidido por ordem alfabetica. Nesta maquina isso
seleciona: $(escolhida_para_o_help).

Um argumento pode ser uma INTERFACE (enp8s0) ou um DRIVER (i40e). O modo por
driver existe para comparar placas que nao estao nesta maquina -- e o que
produz a tabela do modulo de projeto final. Com DOIS OU MAIS drivers o script
entra em modo comparacao e imprime uma linha por driver:

    $0 r8169 i40e ice ixgbe mlx5_core

Misturar interface com driver e recusado: o modo interface tem secoes (estado
do link, netdev, prova funcional) que o modo driver nao tem, e a saida ficaria
irregular. Para varias interfaces de uma vez, use ./scripts/xdp-features.py
sem argumento.
EOF
}

# --- selecao de argumentos ---------------------------------------------------

# Prefere uma interface ETHERNET em barramento PCI.
#
# A versao anterior dependia da ORDEM DO GLOB, e nao de um criterio: nesta
# maquina passam nos filtros tanto enp8s0 (PCI, a placa de que o material fala)
# quanto enx207bd51a08e1 (USB, r8152), e enp8s0 so vencia porque 'p' < 'x'.
# Renomear a interface, ou plugar outro adaptador USB, trocaria em silencio o
# sujeito do diagnostico. Agora PCI ganha de forma explicita, e o desempate
# alfabetico so decide entre iguais.
escolher_interface() {
    local candidata caminho tipo reserva=""

    for caminho in "$SYSFS_NET"/*; do
        [ -e "$caminho" ] || continue
        candidata=${caminho##*/}
        [ "$candidata" = lo ] && continue
        [ -e "$caminho/device/driver" ] || continue
        # 1 = ARPHRD_ETHER. Wi-Fi tambem reporta 1, entao exclui-se quem tem
        # diretorio wireless/ ou phy80211.
        #
        # INCIDENTE, e e a pior forma do defeito fundador neste arquivo. A
        # linha era
        #     tipo=$(cat "$caminho/type" 2>/dev/null || echo 0)
        # e "nao consegui ler o type" virava "type=0", isto e, "nao e
        # ethernet": a candidata era DESCARTADA EM SILENCIO. Medido com um
        # /sys falso de duas candidatas -- enp8s0 (PCI, `type` modo 000) e
        # enx99 (USB, legivel) -- e sem CAP_DAC_OVERRIDE: a PCI sumia da
        # eleicao, a USB ganhava, e TODO o relatorio (cabecalho, netdev,
        # heuristica do modulo, veredito, a linha do xdpsock) passava a falar
        # de outra placa, com numeros perfeitamente corretos sobre a placa que
        # ninguem perguntou. Nao e uma frase errada: e um SUJEITO errado.
        # O --help repetia a afirmacao, entao os dois canais mentiam juntos.
        if ! tipo=$(cat "$caminho/type" 2>/dev/null); then
            printf 'AVISO: candidata "%s" NAO APURADA: nao consegui ler %s (%s).\n' \
                "$candidata" "$caminho/type" "$(modo_de "$caminho/type")" >&2
            printf '       Ela esta fora desta eleicao por falta de leitura, e nao por criterio.\n' >&2
            continue
        fi
        [ "$tipo" = "1" ] || continue
        # Escrito com `if` em vez de `A || B && continue` de proposito: aquela
        # forma e a SC2015 do shellcheck e le-se como "(A || B) && continue",
        # que POR ACASO e o que se queria -- verificado com um /sys falso, em
        # que wlan0 (PCI, com wireless/) foi descartada e a ethernet USB
        # venceu. Ficou explicito porque shellcheck nao esta instalado nesta
        # maquina nem na CI: ninguem receberia o aviso, e o proximo revisor
        # gastaria o mesmo tempo redescobrindo a precedencia.
        if [ -e "$caminho/wireless" ] || [ -e "$caminho/phy80211" ]; then
            continue
        fi

        case "$(readlink -f "$caminho/device/subsystem" 2>/dev/null)" in
            */pci) printf '%s\n' "$candidata"; return 0 ;;
        esac
        [ -n "$reserva" ] || reserva=$candidata
    done

    if [ -n "$reserva" ]; then
        printf '%s\n' "$reserva"
        return 0
    fi

    candidata=$(ip -o route show default 2>/dev/null | awk '{print $5; exit}')
    if [ -n "$candidata" ] && [ -e "$SYSFS_NET/$candidata" ]; then
        printf '%s\n' "$candidata"
        return 0
    fi

    for caminho in "$SYSFS_NET"/*; do
        [ -e "$caminho" ] || continue
        candidata=${caminho##*/}
        [ "$candidata" = lo ] && continue
        if [ -e "$caminho/device/driver" ]; then
            printf '%s\n' "$candidata"
            return 0
        fi
    done

    return 1
}

# e_interface / e_driver: COLETA pura, sem decisao -- a decisao esta em
# classificar_alvo(), em lib-xdp.sh, onde o teste L1 a alcanca.
#
# LIMITE MEDIDO de /sys/class/net, e ele nao e teorico. Dentro de um network
# namespace criado sem remontar sysfs, /sys/class/net continua mostrando as
# interfaces do HOST:
#     $ unshare -Urn -- bash -c 'ip link add veth0 type veth peer name veth1;
#                                ip -br link; ls /sys/class/net'
#       ip -br link      -> lo, veth1@veth0, veth0@veth1
#       ls /sys/class/net -> enp8s0, enx207bd51a08e1, wlp7s0   <- do host
# O script entao recusa "veth0" como inexistente. A correcao para exercitar o
# caso e remontar sysfs (`unshare -Urnm` + `mount -t sysfs none /sys`), e ai
# tudo funciona -- foi assim que o controle positivo do veth (0x23) rodou de
# ponta a ponta. Nao se troca /sys por `ip link` aqui porque o resto do modo
# interface (operstate, carrier, device/driver) le sysfs de qualquer forma: um
# sysfs do namespace errado daria diagnostico da placa errada, que e pior do
# que recusar.
e_interface() { [ -e "$SYSFS_NET/$1" ] && printf 'sim' || printf 'nao'; }

# motivo_sysfs  ->  frase, ou VAZIO se /sys/class/net e consultavel
#
# INCIDENTE, e ele e o defeito fundador inteiro num caminho que nenhuma
# correcao anterior tinha olhado. `motivo_lib_modules()` abaixo foi escrita
# para impedir que /lib/modules inacessivel virasse "o driver nao existe" --
# mas a MESMA frase de recusa depende de OUTRA fonte, /sys/class/net, e essa
# nao tinha verificacao nenhuma. `e_interface` e um `[ -e ]` seco: sysfs nao
# montado (container), mascarado, ou sem travessia da 'nao', igual a um nome
# inventado. Medido, com /sys/class/net substituido por um tmpfs vazio:
#     $ ./scripts/xdp-zerocopy.sh enp8s0
#     Erro: "enp8s0" nao e uma interface nem um driver conhecido.
#       interfaces:
# -- a placa desta maquina, declarada inexistente. E a linha "interfaces:"
# saia VAZIA porque o `ls ... 2>/dev/null` engolia o EACCES, isto e, a unica
# pista disponivel era apagada pelo mesmo padrao.
motivo_sysfs() {
    if [ ! -d "$SYSFS_NET" ]; then
        printf '%s nao existe (sysfs nao montado, ou container sem /sys?)' "$SYSFS_NET"
    elif [ ! -r "$SYSFS_NET" ] || [ ! -x "$SYSFS_NET" ]; then
        printf '%s existe e este processo (uid=%s) nao pode percorre-lo (%s)' \
            "$SYSFS_NET" "$(id -u)" "$(modo_de "$SYSFS_NET")"
    fi
}
e_driver() {
    if command -v modinfo >/dev/null 2>&1 && modinfo -n "$1" >/dev/null 2>&1; then
        printf 'sim'
    else
        printf 'nao'
    fi
}

# motivo_lib_modules  ->  frase, ou VAZIO se a arvore de modulos e consultavel
#
# INCIDENTE. `e_driver` acima devolve 'nao' tanto para "este driver nao existe"
# quanto para "nao deu para olhar", porque `modinfo` colapsa os dois: medido,
# com /lib/modules substituido por um diretorio 0700 de outro dono,
# `modinfo -n i40e` responde "ERROR: Module i40e not found." com rc=1 -- a
# MESMA resposta de um nome inventado. O script entao afirmava categoricamente
# "\"i40e\" nao e uma interface nem um driver conhecido", que e outra vez falta
# de acesso renderizada como inexistencia. Nao da para consertar dentro do
# `modinfo`; da para conferir a arvore ANTES de acreditar nele.
#
# Os dois casos que esta funcao separa sao reais: container sem /lib/modules
# (a docstring de scripts/xdp-features.py cita container como publico-alvo) e
# /lib/modules sem permissao de travessia.
# Os quatro casos sao conferidos em ordem, do mais externo para o mais
# interno: sem isso, um /lib/modules ILEGIVEL faria o teste `[ -d
# /lib/modules/<versao> ]` falhar e o script diria "a arvore nao existe" --
# trocando "sem permissao" por "nao existe", que e o mesmo defeito de novo,
# uma pasta acima.
motivo_lib_modules() {
    local base=/lib/modules arvore="/lib/modules/$(uname -r)"
    if [ ! -d "$base" ]; then
        printf '%s nao existe nesta maquina (container sem os modulos do host?)' "$base"
    elif [ ! -r "$base" ] || [ ! -x "$base" ]; then
        printf '%s existe e este processo (uid=%s) nao pode percorre-lo (%s)' \
            "$base" "$(id -u)" "$(modo_de "$base")"
    elif [ ! -d "$arvore" ]; then
        printf 'a arvore %s nao existe (kernel sem os modulos correspondentes instalados?)' \
            "$arvore"
    elif [ ! -r "$arvore" ] || [ ! -x "$arvore" ]; then
        printf 'a arvore %s existe e este processo (uid=%s) nao pode percorre-la (%s)' \
            "$arvore" "$(id -u)" "$(modo_de "$arvore")"
    fi
}

recusar() {
    local lista rc motivo nomes n
    printf 'Erro: %s\n' "$1" >&2
    # A lista de interfaces e a unica pista que a recusa oferece. Ela era
    # `ls ... 2>/dev/null`, e um EACCES saia como lista VAZIA -- "nenhuma
    # interface aqui", que e uma afirmacao. Agora o erro do `ls` aparece.
    lista=$(ls "$SYSFS_NET" 2>&1)
    rc=$?
    if [ "$rc" -ne 0 ]; then
        motivo=$(motivo_sysfs)
        printf '  interfaces: NAO APURADAS -- %s\n' "${motivo:-ls saiu com codigo $rc: $lista}" >&2
    else
        # Sem `grep` no meio: a lista e a unica pista da recusa, e um `grep`
        # ausente do PATH fazia o pipe devolver VAZIO -- "nenhuma interface",
        # de novo uma afirmacao no lugar de uma falha. O filtro de "lo" cabe
        # em construcao do proprio shell, que nao pode faltar.
        nomes=""
        for n in $lista; do
            [ "$n" = lo ] && continue
            nomes="${nomes}${n} "
        done
        printf '  interfaces: %s\n' "$nomes" >&2
    fi
    printf '  veja "%s --help".\n' "$0" >&2
    exit 2
}

# A varredura de -h/--help vem AQUI, e nao junto do usage(): o texto do help
# chama escolher_interface() para nomear a interface do modo sem argumento, e
# a funcao so existe a partir deste ponto do arquivo.
for a in "$@"; do
    case "$a" in
        -h|--help) usage; exit 0 ;;
    esac
done

modo="interface"
iface=""
drivers=()

if [ "$#" -eq 0 ]; then
    iface=$(escolher_interface) || {
        # "nao achei nenhuma" e "nao consegui olhar" saiam com a mesma frase.
        motivo_net=$(motivo_sysfs)
        if [ -n "$motivo_net" ]; then
            echo "Erro: NAO APURADO quais interfaces existem nesta maquina: $motivo_net." >&2
            echo "      Isto NAO e o mesmo que nao haver interface fisica." >&2
        else
            echo "Erro: $SYSFS_NET foi lido e nenhuma interface fisica passou nos criterios" >&2
            echo "      (ethernet, com device/driver, sem wireless). Veja --help." >&2
        fi
        exit 2
    }
else
    for a in "$@"; do
        case "$(classificar_alvo "$a" "$(e_interface "$a")" "$(e_driver "$a")")" in
            interface)
                [ -n "$iface" ] && recusar "informe uma interface por vez."
                iface=$a
                ;;
            driver)
                drivers+=("$a")
                ;;
            *)
                # "nao apurado" nao pode virar "nao existe". A recusa depende
                # de DUAS fontes, e a versao anterior so conferia uma: se
                # /lib/modules nao podia ser consultada, dizia-se isso -- mas
                # se /sys/class/net e que estava inacessivel, o script afirmava
                # categoricamente que a interface nao existe. As duas sao
                # conferidas agora, e a frase nomeia a que falhou.
                motivo_arvore=$(motivo_lib_modules)
                motivo_net=$(motivo_sysfs)
                if [ -n "$motivo_net" ] || [ -n "$motivo_arvore" ]; then
                    faltou=""
                    [ -n "$motivo_net" ] && faltou="$motivo_net"
                    [ -n "$motivo_arvore" ] && faltou="${faltou:+$faltou, e }$motivo_arvore"
                    recusar "nao foi possivel APURAR se \"$a\" e uma interface ou um driver: $faltou. Isto NAO e o mesmo que \"$a\" nao existir"
                fi
                recusar "\"$a\" nao e uma interface nem um driver conhecido."
                ;;
        esac
    done

    if [ -n "$iface" ] && [ "${#drivers[@]}" -gt 0 ]; then
        recusar "nao misture interface com driver na mesma chamada."
    fi
    if [ -z "$iface" ]; then
        [ "${#drivers[@]}" -gt 1 ] && modo="comparacao" || modo="driver"
    fi
fi

# --- coleta: identificacao ---------------------------------------------------

# Nome reservado para "a coleta nao apurou qual e o driver". E variavel, e nao
# literal repetido, para que o consumidor (inspecionar_modulo) e o produtor
# nao possam divergir na grafia.
_DRIVER_NAO_APURADO="(nao apurado)"
_DRIVER_MOTIVO=""

if [ "$modo" = "interface" ]; then
    # INCIDENTE. Era
    #     driver_path=$(readlink -f ".../device/driver" 2>/dev/null || true)
    #     [ -n "$driver_path" ] || driver="desconhecido/virtual"
    # e um EACCES na travessia de device/ virava string vazia, que virava o
    # rotulo "desconhecido/virtual" -- um VEREDITO ("esta interface e
    # virtual"), nao uma constatacao de falha. Duas linhas do relatorio
    # passavam a afirmar o que ninguem apurou, e a segunda se contradizia na
    # propria frase: "NAO APURADO: nao ha driver associado a este dispositivo
    # em sysfs". Ha driver; faltou travessia de diretorio.
    dev="$SYSFS_NET/$iface/device"
    driver=""
    if [ -e "$dev/driver" ]; then
        if driver_path=$(readlink -f "$dev/driver" 2>&1); then
            driver=${driver_path##*/}
        else
            driver=$_DRIVER_NAO_APURADO
            _DRIVER_MOTIVO="o link $dev/driver existe e readlink falhou ($driver_path)"
        fi
    elif [ -e "$dev" ]; then
        if [ ! -r "$dev" ] || [ ! -x "$dev" ]; then
            driver=$_DRIVER_NAO_APURADO
            _DRIVER_MOTIVO="$dev existe e este processo (uid=$(id -u)) nao pode percorre-lo ($(modo_de "$dev")), entao nao da para dizer qual driver governa \"$iface\""
        else
            driver="desconhecido/virtual"
        fi
    else
        # Sem device/ ha duas leituras: interface virtual de verdade (veth,
        # lo, bridge) ou sysfs que nao pode ser lido. A segunda tem motivo.
        _DRIVER_MOTIVO=$(motivo_sysfs)
        if [ -n "$_DRIVER_MOTIVO" ]; then
            driver=$_DRIVER_NAO_APURADO
        else
            driver="desconhecido/virtual"
        fi
    fi
    pci="-"
    if [ -e "$dev" ]; then
        pci=$(basename "$(readlink -f "$dev")")
    fi
elif [ "$modo" = "driver" ]; then
    driver=${drivers[0]}
    pci="-"
fi

# --- coleta: infraestrutura do kernel ----------------------------------------

# INCIDENTE, e ele e a versao antiga do bug fundador dentro da secao errada.
# Esta funcao imprimia UMA frase -- "configuracao do kernel indisponivel para
# leitura" -- para pelo menos quatro situacoes diferentes:
#
#   (a) o kernel nao publica /proc/config.gz e nao ha /boot/config-<versao>;
#   (b) o arquivo EXISTE e falta PRIVILEGIO (distros que entregam
#       /boot/config-* em 0600, ou /boot inteiro fechado);
#   (c) o arquivo esta la e legivel, e o que faltou foi o grep/zgrep;
#   (d) o arquivo foi lido com sucesso e nenhuma das chaves aparece -- ou seja,
#       o kernel foi compilado SEM elas, que e uma resposta, nao uma falha.
#
# (b) e literalmente "faltou privilegio" renderizado como "a informacao nao
# existe" -- o defeito que este script inteiro veio matar. E (d) era pior
# ainda: um dado APURADO virava "indisponivel". Medido, com um bind de um
# arquivo 0600 sobre /boot/config-$(uname -r) em user+mount namespace, a saida
# era a mesma frase muda.
#
# Agora cada caso tem nome, e o `|| true` que engolia o erro do grep sumiu.
#
# NAO EXERCITADO: /proc/config.gz nao existe nesta maquina, entao o ramo do
# zgrep nao foi rodado -- so o de /boot/config-*. Fica declarado em vez de
# afirmado.
infraestrutura_do_kernel() {
    local padrao='^(CONFIG_XDP_SOCKETS|CONFIG_BPF|CONFIG_BPF_SYSCALL)='
    local fonte="" leitor="" saida rc

    local cfg="/boot/config-$(uname -r)"

    if [ -e /proc/config.gz ]; then
        fonte=/proc/config.gz; leitor=zgrep
    elif [ -e "$cfg" ]; then
        fonte=$cfg; leitor=grep
    fi

    if [ -z "$fonte" ]; then
        # INCIDENTE, E ELE FOI COMETIDO PELA CORRECAO ANTERIOR DESTA FUNCAO.
        # A reescrita separou (a) fonte ausente, (b) arquivo sem privilegio,
        # (c) leitor faltando e (d) lido sem casamento -- e escolheu a fonte
        # com `[ -e "$cfg" ]`, que devolve falso tanto para "nao existe"
        # quanto para "/boot nao e percorrivel por este uid". Resultado
        # medido, com /boot em modo 000 e o arquivo intacto (308.473 bytes) la
        # dentro: o relatorio AFIRMAVA "nao ha /boot/config-<versao>", e o
        # ramo (b) -- o UNICO ponto deste relatorio que ensina que root muda a
        # resposta -- ficava inalcancavel justamente no caso em que root
        # resolveria. E o mesmo erro "uma pasta acima" que motivo_lib_modules()
        # foi escrita para evitar, deixado aberto no diretorio vizinho.
        if [ -d /boot ] && { [ ! -r /boot ] || [ ! -x /boot ]; }; then
            printf '  NAO APURADO por falta de PRIVILEGIO: /boot existe e este processo\n'
            printf '  (uid=%s) nao pode percorre-lo (%s), entao NAO DA PARA DIZER se\n' \
                "$(id -u)" "$(modo_de /boot)"
            printf '  %s esta la. A informacao pode existir; o acesso e que falta --\n' "$cfg"
            echo "  ao contrario do resto deste relatorio, aqui root muda a resposta."
            echo "  Confira com:"
            printf '    sudo grep -E %s %s\n' "'$padrao'" "$cfg"
            return 0
        fi
        echo "  NAO APURADO: este kernel nao publica /proc/config.gz e nao ha"
        printf '  %s. Sem uma dessas duas fontes nao da para dizer\n' "$cfg"
        echo "  se CONFIG_XDP_SOCKETS esta habilitado -- o que e diferente de"
        echo "  dizer que nao esta."
        return 0
    fi
    # APURACAO-OK: a existencia de "$fonte" foi conferida logo acima, com
    # `[ -e /proc/config.gz ]` ou `[ -e "$cfg" ]`; ela so tem valor aqui
    # porque um daqueles dois testes passou. ENOENT esta descartado.
    if [ ! -r "$fonte" ]; then
        printf '  NAO APURADO por falta de PRIVILEGIO: %s existe (%s) e\n' \
            "$fonte" "$(modo_de "$fonte")"
        printf '  este processo (uid=%s) nao pode le-lo. A informacao existe; o\n' "$(id -u)"
        echo "  acesso e que falta -- ao contrario do resto deste relatorio,"
        echo "  aqui root muda a resposta. Confira com:"
        printf '    sudo %s -E %s %s\n' "$leitor" "'$padrao'" "$fonte"
        return 0
    fi
    if ! command -v "$leitor" >/dev/null 2>&1; then
        printf '  NAO APURADO: %s e legivel, e o leitor "%s" nao esta instalado\n' "$fonte" "$leitor"
        echo "  (Debian/Ubuntu: apt install grep gzip). Nao e falta de"
        echo "  privilegio nem ausencia da informacao: e ferramenta faltando."
        return 0
    fi

    # stderr vai junto do stdout DE PROPOSITO, e a separacao e feita pelo rc:
    # 0 = houve casamento (o que sai e a configuracao), 1 = nenhum casamento,
    # >1 = erro do leitor. Assim nenhuma mensagem de erro cai em /dev/null --
    # foi um `2>/dev/null || true` aqui que produziu a frase muda do incidente.
    saida=$("$leitor" -E "$padrao" "$fonte" 2>&1)
    rc=$?
    case "$rc" in
        0)
            printf '%s\n' "$saida" | sed 's/^/  /'
            ;;
        1)
            printf '  APURADO, e a resposta e negativa: %s foi lido e NENHUMA das\n' "$fonte"
            echo "  chaves CONFIG_XDP_SOCKETS / CONFIG_BPF / CONFIG_BPF_SYSCALL"
            echo "  aparece habilitada. Sem CONFIG_XDP_SOCKETS o AF_XDP nao existe"
            echo "  neste kernel, em modo nenhum."
            ;;
        *)
            printf '  NAO APURADO: %s existe e e legivel, e "%s" saiu com codigo %s.\n' \
                "$fonte" "$leitor" "$rc"
            printf '%s\n' "$saida" | sed 's/^/    /'
            ;;
    esac
}

# --- coleta: heuristica do modulo --------------------------------------------
#
# Preenche _MOD_*. Devolve 0 quando ha numeros, 1 quando so ha um motivo.
_MOD_ERRO=""
_MOD_CAMINHO=""
_MOD_XDP=0
_MOD_CHAMADAS=0
_MOD_PROPRIOS=0

# O temporario e removido em toda saida normal da funcao. O trap cobre o resto:
# no modo comparacao a funcao roda N vezes, e um Ctrl-C no meio deixaria um
# modulo descomprimido de dezenas de MB em /tmp. Um trap POR CHAMADA nao
# resolveria -- o ultimo sobrescreve os anteriores -- por isso ha um so, sobre
# uma variavel de modulo.
_MOD_TMP=""
trap 'rm -f "${_MOD_TMP:-}"' EXIT

# _u_le <arquivo> <offset> <n bytes>  ->  inteiro decimal, ou rc!=0
#
# Le um campo little-endian do cabecalho ELF, byte a byte. NAO se usa
# `od -tu8`: `od` interpreta na ordem NATIVA da maquina, e num host big-endian
# isso leria o campo invertido e o script acusaria "truncado" num modulo
# intacto -- trocar um numero falso por outro numero falso. Montar o valor byte
# a byte deixa a ordem explicita no codigo, e o numero de bytes lidos e
# conferido: se o arquivo acabar antes, isto FALHA em vez de devolver um valor
# menor (que era exatamente como o truncamento passava despercebido).
_u_le() {
    local bytes b valor=0 desloc=0 lidos=0
    bytes=$(od -An -tx1 -v -j "$2" -N "$3" "$1" 2>/dev/null) || return 1
    for b in $bytes; do
        valor=$(( valor + $((16#$b)) * (1 << desloc) ))
        desloc=$(( desloc + 8 ))
        lidos=$(( lidos + 1 ))
    done
    [ "$lidos" -eq "$3" ] || return 1
    printf '%s' "$valor"
}

# _elf_defeito <arquivo>  ->  frase do defeito em stdout, ou VAZIO se integro
#
# Confere a INTEGRIDADE ESTRUTURAL, nao so a magica. A conferencia que existia
# aqui lia 4 bytes, e um ELF cortado ao meio comeca com \x7fELF igual a um
# inteiro: passava. O criterio que de fato pega o truncamento e a tabela de
# cabecalhos de secao, que num .ko fica no FIM do arquivo -- se
# e_shoff + e_shentsize * e_shnum passa do tamanho do arquivo, falta ELF.
# Medido no mlx5_core cortado em 4 MiB: e_shoff=6621264, e_shentsize=64,
# e_shnum=80, fim=6626384 > 4194304 -- e o proprio readelf diz "Ler 5120 bytes
# estende-se para la do fim do ficheiro". Foi esse ELF que o nm aceitou com
# rc=0 e zero simbolos.
_elf_defeito() {
    local f=$1 tamanho magica classe dados shoff shentsize shnum fim

    if ! command -v od >/dev/null 2>&1; then
        printf 'nao ha "od" para conferir a integridade do ELF, e sem essa conferencia um modulo truncado publicaria 0/0/0 como se fosse medicao'
        return
    fi
    # INCIDENTE, E ELE E O DEFEITO FUNDADOR DENTRO DA PROPRIA CORRECAO DELE.
    # Esta linha nasceu, nesta funcao, como
    #     tamanho=$(stat -c '%s' "$f" 2>/dev/null || printf 0)
    # -- e esta funcao existe para impedir que um modulo truncado publique
    # "0 simbolos" como se fosse medicao. Com `stat` ausente (container
    # minimo sem coreutils), `tamanho` virava 0, a comparacao `fim > tamanho`
    # disparava sempre, e um modulo INTEIRO era publicado como
    #     NAO APURADO: ELF TRUNCADO: a tabela de secoes termina no byte
    #     1401064 e o arquivo tem so 0 (descompressao incompleta -- TMPDIR
    #     sem espaco?)
    # Tres afirmacoes falsas numa frase, e uma CAUSA inventada mandando o
    # leitor investigar espaco em disco quando o que faltava era um binario.
    # A assimetria denunciava o descuido: a linha acima ja guardava o `od` com
    # `command -v` e uma frase de NAO APURADO, e nada equivalente existia para
    # a outra ferramenta externa da mesma funcao.
    if ! command -v stat >/dev/null 2>&1; then
        printf 'nao ha "stat" para medir o tamanho do arquivo, e sem esse numero a conferencia de truncamento nao pode ser feita (a integridade do ELF NAO foi apurada)'
        return
    fi
    if ! tamanho=$(stat -c '%s' "$f" 2>&1); then
        printf 'nao foi possivel medir o tamanho de %s (%s), entao a integridade do ELF NAO foi apurada' "$f" "$tamanho"
        return
    fi
    magica=$(od -An -tx1 -v -N4 "$f" 2>/dev/null | tr -d ' \n')
    if [ "$magica" != "7f454c46" ]; then
        printf 'o resultado nao comeca com a magica ELF \\x7fELF (comeca com 0x%s)' \
            "${magica:-<vazio>}"
        return
    fi
    classe=$(_u_le "$f" 4 1) && dados=$(_u_le "$f" 5 1) || {
        printf 'o cabecalho ELF nao tem nem os 6 primeiros bytes: o arquivo esta truncado'
        return
    }
    if [ "$classe" != 2 ] || [ "$dados" != 1 ]; then
        printf 'ELF de classe=%s ordem=%s; esta conferencia so sabe validar ELF64 little-endian, entao a INTEGRIDADE nao foi apurada e o numero nao pode ser publicado' \
            "$classe" "$dados"
        return
    fi
    shoff=$(_u_le "$f" 40 8) && shentsize=$(_u_le "$f" 58 2) && shnum=$(_u_le "$f" 60 2) || {
        printf 'o cabecalho ELF tem menos de 64 bytes: o arquivo esta truncado'
        return
    }
    # A aritmetica do shell e de 64 bits COM SINAL: um e_shoff corrompido com o
    # byte alto >= 0x80 daria negativo, e um `fim` negativo passaria calado pela
    # comparacao "cabe no arquivo" -- de novo um numero falso publicado. Valor
    # negativo aqui e impossivel num ELF valido, entao vira defeito nomeado.
    if [ "$shoff" -lt 0 ] || [ "$shentsize" -lt 0 ] || [ "$shnum" -lt 0 ]; then
        printf 'cabecalho ELF incoerente (e_shoff=%s, e_shentsize=%s, e_shnum=%s): nenhum desses campos pode ser negativo, entao o arquivo nao e um modulo integro' \
            "$shoff" "$shentsize" "$shnum"
        return
    fi
    if [ "$shoff" -eq 0 ] || [ "$shnum" -eq 0 ]; then
        printf 'ELF sem tabela de cabecalhos de secao (e_shoff=%s, e_shnum=%s): nao ha simbolos para o nm ler, e "zero simbolos" aqui nao significa "driver sem suporte"' \
            "$shoff" "$shnum"
        return
    fi
    fim=$(( shoff + shentsize * shnum ))
    if [ "$fim" -lt 0 ]; then
        printf 'cabecalho ELF incoerente: e_shoff + e_shentsize * e_shnum estourou a aritmetica de 64 bits (%s + %s * %s)' \
            "$shoff" "$shentsize" "$shnum"
        return
    fi
    if [ "$fim" -gt "$tamanho" ]; then
        # A causa e HIPOTESE e esta escrita como hipotese. A versao anterior
        # afirmava "(descompressao incompleta -- TMPDIR sem espaco?)" e, na
        # regressao do `stat`, mandava o leitor caçar espaco em disco quando o
        # que faltava era um binario. O FATO e a aritmetica; a causa provavel
        # vem depois dele, nomeada como provavel.
        printf 'ELF TRUNCADO: a tabela de secoes termina no byte %s e o arquivo tem so %s bytes, entao falta ELF. Causa mais comum: descompressao interrompida (TMPDIR sem espaco); modulo corrompido tambem produz isto' \
            "$fim" "$tamanho"
    fi
}

# _nm_conta <arquivo> <flag do nm> <padrao grep>  ->  contagem em stdout
#
# Devolve rc!=0 e preenche _NM_ERRO quando NAO foi possivel contar -- que e
# coisa diferente de contar zero. `grep -c` sai com 1 quando nao ha casamento
# (informacao legitima: o numero e zero) e com 2 quando ha erro; so o segundo
# invalida a contagem.
_NM_ERRO=""
_NM_CONTA=0
_nm_conta() {
    local saida rc_nm conta rc_grep msg
    _NM_ERRO=""; _NM_CONTA=0
    saida=$(nm "$2" "$1" 2>/dev/null)
    rc_nm=$?
    if [ "$rc_nm" -ne 0 ]; then
        # A guarda do rc ja estava aqui; o que faltava era a FRASE. O nm diz
        # exatamente o que houve ("formato de ficheiro nao reconhecido") e o
        # relatorio nomeava so QUE falhou, nao O QUE falhou -- meia violacao
        # da regra "se precisar continuar apesar do erro, DIGA qual erro foi",
        # e inconsistente com o descompressor deste mesmo arquivo, que captura
        # o stderr de proposito. O segundo `nm` roda SO no caminho de erro:
        # capturar stderr no caminho normal misturaria avisos com simbolos, e
        # e justamente um `nm` que avisa em stderr e sai 0 que produziu o
        # numero falso do incidente fundador.
        msg=$(nm "$2" "$1" 2>&1 >/dev/null | tr '\n' ' ')
        _NM_ERRO="nm $2 saiu com codigo $rc_nm (${msg:-sem mensagem no stderr}); a contagem de simbolos nao foi apurada"
        return 1
    fi
    conta=$(printf '%s\n' "$saida" | grep -c "$3")
    rc_grep=$?
    if [ "$rc_grep" -gt 1 ]; then
        _NM_ERRO="grep saiu com codigo $rc_grep ao contar \"$3\"; a contagem nao foi apurada"
        return 1
    fi
    _NM_CONTA=$conta
}

inspecionar_modulo() {
    local drv=$1 module="" tmp defeito="" par rc_modinfo=0 erro_modinfo=""
    _MOD_ERRO=""; _MOD_CAMINHO=""; _MOD_XDP=0; _MOD_CHAMADAS=0; _MOD_PROPRIOS=0

    if [ "$drv" = "desconhecido/virtual" ]; then
        _MOD_ERRO="APURADO: sysfs foi lido e nao ha driver associado a este dispositivo (interface virtual)"
        return 1
    fi
    # O nome vem da coleta acima, que ja separou "li o sysfs e nao ha driver"
    # de "nao consegui ler o sysfs". A segunda chega aqui com o motivo pronto.
    if [ "$drv" = "$_DRIVER_NAO_APURADO" ]; then
        _MOD_ERRO="NAO APURADO: $_DRIVER_MOTIVO"
        return 1
    fi
    if ! command -v modinfo >/dev/null 2>&1; then
        _MOD_ERRO="NAO APURADO: modinfo nao encontrado (Debian/Ubuntu: apt install kmod)"
        return 1
    fi
    # O `|| true` que estava aqui descartava o rc do modinfo, e com ele a
    # unica diferenca entre "esse driver nao existe" e "nao consegui olhar".
    # O rc sozinho tambem nao basta -- modinfo sai 1 nos dois casos --, por
    # isso a frase dele e capturada e entra no relatorio.
    module=$(modinfo -n "$drv" 2>/dev/null)
    rc_modinfo=$?
    if [ -z "$module" ] || [ "$rc_modinfo" -ne 0 ]; then
        erro_modinfo=$(modinfo -n "$drv" 2>&1 >/dev/null | tr '\n' ' ')
        # Mesmo incidente de motivo_lib_modules(): `modinfo` responde
        # "Module X not found" com rc=1 tanto para nome inexistente quanto
        # para arvore que ele nao conseguiu percorrer. A frase muda so quando
        # da para provar qual dos dois e.
        defeito=$(motivo_lib_modules)
        if [ -n "$defeito" ]; then
            _MOD_ERRO="NAO APURADO: $defeito, entao nao da para dizer se o modulo de \"$drv\" existe"
        else
            _MOD_ERRO="APURADO: a arvore de modulos foi percorrida e nao ha modulo para \"$drv\"${erro_modinfo:+ ($erro_modinfo)}"
        fi
        return 1
    fi
    if [ "$module" = "(builtin)" ]; then
        # Caso comum em VM (virtio_net). Nao ha arquivo para o nm ler, e isso
        # nao e falha de permissao -- dizer qual dos dois e importa.
        _MOD_ERRO="driver incorporado ao kernel; nao ha modulo separado para inspecionar"
        return 1
    fi
    # INCIDENTE: o defeito fundador AO CONTRARIO -- "nao sei por que" saindo
    # como "FALTA DE PRIVILEGIO". O teste era so `[ ! -r "$module" ]`, e ele e
    # verdadeiro tanto para "existe e nao posso ler" quanto para NAO EXISTE
    # (ENOENT); a frase entao afirmava as duas coisas que ninguem conferiu --
    # "$module EXISTE (modo ?) e o uid N nao pode le-lo" -- e mandava o leitor
    # atras de um sudo que nao ia encontrar arquivo nenhum. O gatilho e real e
    # dispensa stub: modules.dep dessincronizado dos .ko (imagem de container
    # que traz a metadata do /lib/modules do host sem os modulos, ou remocao
    # de linux-modules-extra sem depmod). Medido: com o diretorio do .ko
    # esvaziado e modules.dep intacto, `modinfo -n r8169` responde o caminho
    # com rc=0 e o arquivo nao esta la.
    if [ ! -e "$module" ]; then
        _MOD_ERRO="NAO APURADO: modinfo aponta para $module e esse arquivo NAO existe (modules.dep dessincronizado dos .ko?). Nao e falta de privilegio: nem root o encontraria"
        return 1
    fi
    if [ ! -r "$module" ]; then
        _MOD_ERRO="NAO APURADO por falta de PRIVILEGIO: $module existe ($(modo_de "$module")) e o uid $(id -u) nao pode le-lo"
        return 1
    fi
    if ! command -v nm >/dev/null 2>&1; then
        _MOD_ERRO="NAO APURADO: nm nao encontrado; instale binutils para a inspecao do modulo"
        return 1
    fi

    tmp=$(mktemp) || { _MOD_ERRO="NAO APURADO: mktemp falhou (TMPDIR=${TMPDIR:-/tmp} cheio ou sem permissao?)"; return 1; }
    _MOD_TMP=$tmp

    # A DESCOMPRESSAO E A RAZAO DE ESTE SCRIPT EXISTIR. A versao fundadora
    # rodava `nm -D .../r8169.ko.zst | grep -c xsk_` e devolvia 0 para TODO
    # driver, inclusive os que tem suporte: o nm recusa o arquivo comprimido, o
    # grep -c engole o erro e responde 0 -- a mesma resposta de um driver
    # realmente sem suporte. Perder este passo ressuscita o bug fundador.
    #
    # SEGUNDO INCIDENTE, MEDIDO, E ELE E O MESMO BUG POR OUTRA PORTA. Ter o
    # passo da descompressao nao basta: ela pode rodar PELA METADE. Com
    #     unshare -Urm -- bash -c 'mount -t tmpfs -o size=4M none /tmp/t &&
    #        TMPDIR=/tmp/t ./scripts/xdp-zerocopy.sh i40e mlx5_core'
    # a tabela saia assim:
    #     i40e        37   7  13  XDP + zero-copy      <- correto
    #     mlx5_core    0   0   0  sem XDP nenhum       <- FALSO, e sem aviso
    # O mlx5_core tem 6.627.105 bytes descomprimidos e nao cabia nos 4 MiB.
    # Tres engolimentos em serie produziam o numero falso:
    #   (1) `zstd -dcq ... 2>/dev/null || true` descartava o rc=70 (write
    #       error) do zstd;
    #   (2) a conferencia de ELF lia so os QUATRO bytes da magica, e um
    #       arquivo cortado ao meio ainda comeca com \x7fELF;
    #   (3) `nm` num ELF truncado sai com rc=0 dizendo "nenhum simbolo"
    #       (medido: ele so reclama em stderr, via plugin bfd), e
    #       `grep -c ... || true` devolvia 0 -- de novo a mesma resposta de um
    #       driver sem suporte.
    # O caso insidioso e justamente o PARCIAL: uma unica linha falsa dentro de
    # uma tabela que parece sadia, e essa tabela e publicada. As tres portas
    # estao fechadas abaixo, uma a uma: rc do descompressor, integridade
    # ESTRUTURAL do ELF (nao so a magica) e rc do nm. Quando qualquer uma
    # falha a funcao devolve 1, e a celula da tabela sai como "-" com o motivo
    # ao lado -- NUNCA 0/0/0.
    local descompressor="" erro_desc="" rc_desc=0
    case "$module" in
        *.zst) descompressor=zstd ;;
        *.xz)  descompressor=xz ;;
        *.gz)  descompressor=gzip ;;
    esac
    if [ -n "$descompressor" ]; then
        if ! command -v "$descompressor" >/dev/null 2>&1; then
            rm -f "$tmp"; _MOD_TMP=""
            _MOD_ERRO="NAO APURADO: $module esta comprimido e \"$descompressor\" nao esta instalado"
            return 1
        fi
        # Sem -q, e com stderr capturado em vez de descartado: a frase do
        # descompressor e a unica pista de POR QUE nao deu (disco cheio,
        # arquivo corrompido, formato inesperado).
        erro_desc=$("$descompressor" -dc "$module" 2>&1 >"$tmp")
        rc_desc=$?
    else
        erro_desc=$(cp "$module" "$tmp" 2>&1)
        rc_desc=$?
        descompressor=cp
    fi
    if [ "$rc_desc" -ne 0 ]; then
        rm -f "$tmp"; _MOD_TMP=""
        _MOD_ERRO="NAO APURADO: \"$descompressor\" saiu com codigo $rc_desc ao abrir $module${erro_desc:+ ($erro_desc)}"
        return 1
    fi

    defeito=$(_elf_defeito "$tmp")
    if [ -n "$defeito" ]; then
        rm -f "$tmp"; _MOD_TMP=""
        _MOD_ERRO="NAO APURADO: $defeito (origem: $module; TMPDIR=${TMPDIR:-/tmp})"
        return 1
    fi

    # ATENCAO AO PADRAO. A versao anterior usava
    #     grep -E '(^|[^[:alnum:]_])xsk_[[:alnum:]_]*'
    # e devolvia ZERO para todo driver, inclusive os que tem suporte -- o
    # mesmo sintoma do bug que este script veio substituir. Causa: no ERE do
    # GNU grep, o `^` dentro de um grupo de alternancia faz a expressao
    # inteira parar de casar. Verificado: `[^[:alnum:]_]xsk_` casa 1 na
    # mesma linha em que `(^|[^[:alnum:]_])xsk_` casa 0.
    #
    # `\<xsk_` (fronteira de palavra) faz o que se queria e funciona: casa
    # `U xsk_get_pool_from_qid`, nao casa `i40e_xsk_any_rx_ring_enabled`.
    #
    # A ASSIMETRIA ENTRE OS DOIS GREPS E DELIBERADA, e parece descuido. O de
    # `chamadas` tem `\<`, o de `proprios` NAO tem. Medido no i40e:
    #     nm -u            | grep -c '\<xsk_'  ->  7
    #     nm --defined-only| grep -c 'xsk_'    -> 13
    #     nm --defined-only| grep -c '\<xsk_'  ->  0   <- "uniformizar" zera
    # A razao esta nos simbolos reais: os indefinidos tem prefixo nu
    # (`xsk_tx_completed`); os definidos sao prefixados pelo driver
    # (`i40e_xsk_wakeup`). Acrescentar `\<` ao segundo destruiria a coluna
    # "codigo XSK do driver" da tabela publicada.
    #
    # Os tres numeros dizem coisas diferentes:
    #   chamadas ao nucleo XSK -> o driver USA a infraestrutura de zero-copy
    #   codigo XSK do driver   -> o driver IMPLEMENTA caminhos XSK proprios
    #   simbolos xdp_          -> separa "sem XDP nenhum" de "XDP sem zero-copy"
    # Medido nesta maquina: r8169 = 0 simbolos xdp_; i40e = 37.
    #
    # RESSALVA DE HONESTIDADE, e ela nao esta corrigida de proposito: "codigo
    # XSK do driver" SUPER-CONTA. Dos 13 do i40e, 6 sao thunks `__pfx_` de CFI
    # e 1 e uma variante `.cold`; sobram 6 funcoes reais. Filtrar seria mais
    # honesto e reescreveria quatro linhas de tabela ja publicada -- mudar
    # numero publicado e decisao editorial, nao de refatoracao. O vies e o
    # mesmo para todos os drivers, e o numero e usado como comparativo.
    #
    # O `|| true` sumiu dos tres contadores: ele transformava QUALQUER falha do
    # nm em "0", que e um numero publicavel e indistinguivel de um driver sem
    # suporte. `_nm_conta` separa "contei zero" de "nao consegui contar", e
    # aqui a segunda hipotese aborta a linha inteira.
    for par in "-u|\\<xsk_" "--defined-only|xsk_" "-a|xdp_"; do
        if ! _nm_conta "$tmp" "${par%%|*}" "${par#*|}"; then
            rm -f "$tmp"; _MOD_TMP=""
            _MOD_ERRO="NAO APURADO: $_NM_ERRO (origem: $module)"
            return 1
        fi
        case "${par%%|*}" in
            -u)             _MOD_CHAMADAS=$_NM_CONTA ;;
            --defined-only) _MOD_PROPRIOS=$_NM_CONTA ;;
            -a)             _MOD_XDP=$_NM_CONTA ;;
        esac
    done
    _MOD_CAMINHO=$module
    rm -f "$tmp"
    _MOD_TMP=""
    return 0
}

# --- coleta: capacidade anunciada pelo netdev --------------------------------
#
# Preenche _CAP_CLASSE (vocabulario de lib-xdp.sh) e _CAP_MOTIVO.
_CAP_CLASSE=""
_CAP_MOTIVO=""

# acrescentar_motivo <frase>  --  encadeia motivos em _CAP_MOTIVO
#
# Existe para eliminar o `[ -n "$_CAP_MOTIVO" ] && _CAP_MOTIVO="$_CAP_MOTIVO,
# e ..."` que aparecia tres vezes. Aquele guarda parecia protecao contra uma
# virgula solta no comeco da frase, e na pratica fazia o contrario do que o
# arquivo promete: quando o motivo ainda estava vazio, a frase era DESCARTADA
# em silencio -- e "inconclusivo" saia sem dizer o que faltou. Aqui a primeira
# frase inicia o motivo e as seguintes se encadeiam; nenhuma se perde.
acrescentar_motivo() {
    if [ -n "$_CAP_MOTIVO" ]; then
        _CAP_MOTIVO="$_CAP_MOTIVO, e $1"
    else
        _CAP_MOTIVO=$1
    fi
}

consultar_netdev() {
    local alvo=$1 bloco="" rc=127 v nomes

    if ! command -v python3 >/dev/null 2>&1; then
        rc=127
    elif [ ! -e "$HELPER" ]; then
        # Esta frase e publicada byte a byte em trilha/04-projeto-final e nao
        # pode mudar: ela e o exemplo de "o script nomeia o que faltou".
        echo "  scripts/xdp-features.py nao encontrado ao lado deste script."
        rc=126
    elif [ ! -r "$HELPER" ]; then
        # ...e este ramo existe porque o teste anterior era so `[ ! -r ]`, que
        # e verdadeiro tambem para ENOENT: "existe e nao posso ler" saia como
        # "nao esta ao lado do script", mandando o leitor copiar um arquivo
        # que ja estava la.
        printf '  scripts/xdp-features.py esta ao lado deste script (%s) e este processo (uid=%s) nao pode le-lo.\n' \
            "$(modo_de "$HELPER")" "$(id -u)"
        rc=125
    else
        bloco=$(python3 "$HELPER" "$alvo" 2>&1)
        rc=$?
    fi

    if [ "$rc" -eq 0 ]; then
        _CAP_CLASSE=$(xdp_valor VEREDITO "$bloco")
        # INCIDENTE: A INVARIANTE DO MOTIVO, QUEBRADA PELA PORTA AO LADO.
        # A correcao anterior fechou o caminho em que `classe_de_xdploader`
        # devolve "inconclusivo". Mas o guarda do fallback, la embaixo, e
        #     [ -n "$_CAP_CLASSE" ] && [ "$_CAP_CLASSE" != "sem-atributo" ]
        # e QUALQUER string nao vazia diferente de "sem-atributo" fechava o
        # veredito -- inclusive uma que `texto_veredito` nao conhece. Medido,
        # com um helper que grafa a classe como "no-xdp" (o cenario que o
        # AVISO abaixo ja antecipava, "xdp-features.py de outra versao"), a
        # saida era: "(nao foi preciso o fallback)" -- falso, o fallback era
        # exatamente o que faltava --, seguido de "Resultado INCONCLUSIVO"
        # SEM a linha "O que faltou", porque _CAP_MOTIVO ficava vazio.
        # Nenhum ponto do fluxo conferia se a classe pertencia ao vocabulario
        # de cinco palavras que scripts/lib-xdp.sh publica. Agora confere, e a
        # classe desconhecida e tratada como o que ela e: nao-apuracao.
        if [ -n "$_CAP_CLASSE" ] && ! classe_conhecida "$_CAP_CLASSE"; then
            printf '  AVISO: a consulta respondeu (codigo 0) com VEREDITO="%s", que NAO\n' "$_CAP_CLASSE"
            echo "         pertence ao vocabulario de classes deste script. Tratado como"
            echo "         nao-apuracao; o relatorio segue para o fallback."
            acrescentar_motivo "a consulta netlink respondeu (codigo 0) com VEREDITO=\"$_CAP_CLASSE\", classe que este script nao conhece (scripts/xdp-features.py de outra versao?)"
            _CAP_CLASSE=""
        elif [ -z "$_CAP_CLASSE" ]; then
            echo "  AVISO: a consulta respondeu (codigo 0) e o bloco veio SEM a chave"
            echo "         VEREDITO. O relatorio segue para o fallback."
            acrescentar_motivo "a consulta netlink respondeu (codigo 0) e o bloco nao trouxe a chave VEREDITO (scripts/xdp-features.py de outra versao?)"
        fi
        echo "  fonte ........ netlink generico, familia \"netdev\", NETDEV_CMD_DEV_GET"
        echo "  privilegio ... nenhum (uid=$(id -u)); o kernel declara este comando livre"
        v=$(xdp_valor XDP_FEATURES "$bloco")
        nomes=$(xdp_valor XDP_FEATURES_NOMES "$bloco")
        printf '  xdp_features . %s  %s\n' "${v:-(nao anunciado)}" \
            "${nomes:-(nenhuma capacidade anunciada)}"
        # `${v:-(nao anunciado)}` nas TRES linhas, e nao so na primeira: na
        # classe `sem-atributo` o helper devolve string vazia de proposito, e
        # um campo em branco num relatorio de diagnostico le-se como "a
        # ferramenta nao conseguiu" -- exatamente a confusao que este arquivo
        # existe para desfazer. Vazio aqui significa "o kernel nao anunciou".
        v=$(xdp_valor XDP_BASIC "$bloco")
        printf '  BASIC ........ %s\n' "${v:-(nao anunciado)}"
        v=$(xdp_valor XDP_ZEROCOPY "$bloco")
        printf '  XSK_ZEROCOPY . %s\n' "${v:-(nao anunciado)}"

        # Os campos abaixo o `xdp-loader features` NAO mostra -- o binario so
        # contem os sete nomes NETDEV_XDP_ACT_*. Sao impressos apenas quando
        # carregam informacao: uma linha "rx_metadata=0x0 (nenhuma)" numa placa
        # sem XDP e ruido, e ruido some do relatorio.
        v=$(xdp_valor XDP_ZC_MAX_SEGS "$bloco")
        if [ -n "$v" ]; then
            printf '  zc_max_segs .. %s  (segmentos por pacote no caminho zero-copy)\n' "$v"
        fi
        nomes=$(xdp_valor XDP_RX_METADATA_NOMES "$bloco")
        if [ -n "$nomes" ]; then
            printf '  rx_metadata .. %s\n' "$nomes"
            echo "                 responde se bpf_xdp_metadata_rx_timestamp/hash/vlan"
            echo "                 tem dado real nesta placa, ou devolvem -EOPNOTSUPP."
        fi
        nomes=$(xdp_valor XSK_FEATURES_NOMES "$bloco")
        if [ -n "$nomes" ]; then
            printf '  xsk_features . %s\n' "$nomes"
            echo "                 o analogo no TX: timestamp, checksum e launch time."
        fi
    else
        _CAP_MOTIVO=$(motivo_netlink "$rc")
        printf '  fonte primaria (netlink) nao respondeu: %s.\n' "$_CAP_MOTIVO"
        [ -n "$bloco" ] && printf '%s\n' "$bloco" | sed 's/^/    /'
    fi

    # O fallback so entra quando a fonte primaria nao fechou o veredito.
    if [ -n "$_CAP_CLASSE" ] && [ "$_CAP_CLASSE" != "sem-atributo" ]; then
        echo "  (nao foi preciso o fallback: o xdp-loader le o MESMO atributo, e exige root)"
        return 0
    fi

    echo ""
    echo "  Fallback: xdp-loader features"

    # INCIDENTE 1 -- A CONTRADICAO DENTRO DA MESMA SAIDA. `sem-atributo` caia
    # no bloco generico logo abaixo, que so sabe dizer "xdp-loader exige
    # root", e o relatorio entao imprimia
    #     Se quiser conferir mesmo assim: sudo ./scripts/xdp-zerocopy.sh enp8s0
    # e, OITO LINHAS DEPOIS, no veredito:
    #     Como o 'xdp-loader features' le o MESMO atributo, ele nao responderia melhor.
    # Ou seja: mandava o leitor sem privilegio atras de sudo para obter uma
    # informacao que root comprovadamente NAO produz. E a mesma confusao entre
    # "faltou privilegio" e "nao da para saber" que esta reescrita veio matar,
    # so que invertida -- e o comentario que estava aqui descrevia uma mensagem
    # que nao existia em lugar nenhum do codigo. Agora ela existe, e vem ANTES
    # do bloco generico.
    if [ "$_CAP_CLASSE" = "sem-atributo" ]; then
        echo "  Nao se aplica, e root NAO mudaria a resposta: o xdp-loader le o"
        echo "  MESMO atributo xdp_features que a consulta acima ja fez, e este"
        echo "  kernel respondeu SEM esse atributo. Nao ha nada a mais para a"
        echo "  ferramenta privilegiada ler -- por isso nenhuma linha de sudo e"
        echo "  oferecida neste caso."
        return 0
    fi

    if ! command -v xdp-loader >/dev/null 2>&1; then
        echo "  xdp-loader nao encontrado (Debian/Ubuntu: apt install xdp-tools)."
        acrescentar_motivo "xdp-loader nao esta instalado"
        return 0
    fi
    if [ "$(id -u)" -ne 0 ]; then
        # Dito explicitamente: sem esta frase o leitor nao descobre que a
        # exigencia e da FERRAMENTA e nao do dado -- foi assim que a versao
        # anterior transformou "faltou privilegio" em "inconclusivo".
        echo "  xdp-loader exige root, e a exigencia e DA FERRAMENTA: ele carrega"
        echo "  eBPF e abre mapa BPF. O dado em si e livre -- e por isso que a"
        echo "  fonte primaria acima nao pediu privilegio nenhum."
        printf '  Se quiser conferir mesmo assim: sudo %s %s\n' "$0" "$alvo"
        acrescentar_motivo "o fallback xdp-loader exige root"
        return 0
    fi

    local saida rc_loader zc basico nova
    saida=$(xdp-loader features "$alvo" 2>&1)
    rc_loader=$?
    printf '%s\n' "$saida" | sed 's/^/    /'
    if [ "$rc_loader" -ne 0 ]; then
        acrescentar_motivo "xdp-loader saiu com codigo $rc_loader"
        return 0
    fi
    zc=$(resposta_xdploader "$(campo_xdploader NETDEV_XDP_ACT_XSK_ZEROCOPY "$saida")")
    basico=$(resposta_xdploader "$(campo_xdploader NETDEV_XDP_ACT_BASIC "$saida")")

    # INCIDENTE 2 -- O FALLBACK APAGANDO UM VEREDITO MELHOR, E EMUDECENDO O
    # RESTO. A linha era `_CAP_CLASSE=$(classe_de_xdploader "$zc" "$basico")`,
    # sem condicao nenhuma. Medido, com um xdp-loader que sai com rc=0 e texto
    # que o parser nao reconhece (e uid=0), a saida era:
    #     classe pelo fallback: inconclusivo
    #     ...
    #     Resultado INCONCLUSIVO -- e isto NAO significa 'a placa nao suporta'.
    #     Sem uma fonte que responda, [...]
    # sem a linha "O que faltou", porque _CAP_MOTIVO ficava VAZIO: neste
    # caminho rc=0 e as tres atribuicoes de motivo eram guardadas por
    # `[ -n "$_CAP_MOTIVO" ]`, entao nenhuma disparava. scripts/lib-xdp.sh
    # declara que o motivo "e OBRIGATORIO na pratica" -- e a invariante nao se
    # quebrava na funcao pura (que o teste L1 cobre), e sim AQUI, no ponto de
    # composicao. Duas regras a partir de agora:
    #   1. a classe do fallback so e aceita quando e MELHOR que a que ja se
    #      tem; 'inconclusivo' nunca sobrescreve nada;
    #   2. o motivo e alimentado por acrescentar_motivo(), sem guarda, para
    #      que 'inconclusivo' jamais saia mudo.
    nova=$(classe_de_xdploader "$zc" "$basico")
    if [ "$nova" = "inconclusivo" ]; then
        acrescentar_motivo "o xdp-loader respondeu (codigo 0) e a saida nao trouxe nenhuma linha NETDEV_XDP_ACT_* reconhecivel (ZEROCOPY=$zc, BASIC=$basico)"
        printf '  classe pelo fallback: NAO APURADA (saida nao reconhecida); mantida a classe anterior: %s\n' \
            "${_CAP_CLASSE:-nenhuma}"
        return 0
    fi
    _CAP_CLASSE=$nova
    printf '  classe pelo fallback: %s\n' "$_CAP_CLASSE"
}

# --- relatorio ---------------------------------------------------------------

if [ "$modo" = "comparacao" ]; then
    printf '\n== AF_XDP zero-copy: comparacao de DRIVERS ==\n'
    printf '  kernel ....... %s\n' "$(uname -r)"

    printf '\n-- Infraestrutura do kernel --\n'
    infraestrutura_do_kernel

    printf '\n-- Heuristica do modulo (evidencia secundaria) --\n'
    printf '  %-14s %6s %9s %9s  %s\n' \
        driver 'xdp_' chamadas proprios diagnostico
    for d in "${drivers[@]}"; do
        if inspecionar_modulo "$d"; then
            printf '  %-14s %6s %9s %9s  %s\n' "$d" \
                "$_MOD_XDP" "$_MOD_CHAMADAS" "$_MOD_PROPRIOS" \
                "$(diagnostico_modulo "$_MOD_XDP" "$_MOD_CHAMADAS" "$_MOD_PROPRIOS")"
        else
            printf '  %-14s %6s %9s %9s  %s\n' "$d" - - - "$_MOD_ERRO"
        fi
    done
    echo ""
    echo "  xdp_      simbolos xdp_ no modulo: separa 'sem XDP' de 'XDP sem zero-copy'"
    echo "  chamadas  simbolos INDEFINIDOS xsk_: o driver USA o nucleo XSK"
    echo "  proprios  simbolos DEFINIDOS xsk_: o driver IMPLEMENTA caminhos XSK"

    printf '\n-- Veredito --\n'
    echo "  Este modo compara MODULOS, nao interfaces. Nenhuma linha acima e"
    echo "  veredito operacional: simbolo no modulo e evidencia indireta, e a"
    echo "  capacidade real depende do netdev daquela placa naquele kernel."
    echo "  Para o veredito de uma placa presente, rode com o nome da interface."

    cat <<EOF

-- Prova funcional --
  Nao se aplica: este modo inspeciona modulos de drivers que podem nem estar
  presentes nesta maquina. A prova exige a placa e uma interface ativa; rode
  entao "$0 <interface>" na maquina que a tiver.
EOF
    exit 0
fi

if [ "$modo" = "driver" ]; then
    printf '\n== AF_XDP zero-copy: inspecao do DRIVER ==\n'
else
    printf '\n== AF_XDP zero-copy: diagnostico da INTERFACE ==\n'
fi
printf '  kernel ....... %s\n' "$(uname -r)"
[ "$modo" = "driver" ] || printf '  interface .... %s\n' "$iface"
printf '  driver ....... %s\n' "$driver"
printf '  dispositivo .. %s\n' "$pci"

if [ "$modo" = "interface" ]; then
    # `|| echo "?"` nas duas linhas: a falha de leitura saia com a MESMA cara
    # de um valor lido, e "?" no lugar de operstate ainda caia no ramo de
    # baixo, que AFIRMA "a interface nao esta ativa". Estado nao apurado nao e
    # estado down. (Nota: carrier ilegivel e comum e LEGITIMO -- o kernel
    # devolve EINVAL para interface administrativamente fora do ar --, e por
    # isso a frase nomeia o erro em vez de sugerir defeito.)
    operstate=$(cat "$SYSFS_NET/$iface/operstate" 2>&1) || { erro_op=$operstate; operstate=""; }
    carrier=$(cat "$SYSFS_NET/$iface/carrier" 2>&1)     || { erro_car=$carrier; carrier=""; }
    printf '  estado ....... %s (carrier=%s)\n' \
        "${operstate:-NAO APURADO}" "${carrier:-NAO APURADO}"
    [ -n "$carrier" ] || printf '                 carrier NAO APURADO: %s\n' "${erro_car:-sem mensagem}"
    if [ -z "$operstate" ]; then
        printf '  AVISO: o estado do link NAO FOI APURADO: %s\n' "${erro_op:-sem mensagem}"
        printf '         Isso NAO significa que a interface esteja fora do ar.\n'
    elif [ "$operstate" != "up" ]; then
        # CONTROLE JA EXECUTADO, e ele muda o peso deste aviso: um veth DOWN
        # reporta xdp_features=0x23 igual ao veth UP. Ou seja, link caido NAO
        # suprime a capacidade anunciada -- o "0x00" desta placa nao vem do
        # NO-CARRIER. O aviso fica porque outras consultas (contadores, taxa)
        # ficam mesmo incompletas com o link fora.
        printf '  AVISO: a interface nao esta ativa. Isso NAO invalida a secao\n'
        printf '         "capacidade anunciada": medido em veth, a bitmask e a\n'
        printf '         mesma com o link em cima ou embaixo.\n'
    fi
fi

printf '\n-- Infraestrutura do kernel --\n'
infraestrutura_do_kernel

printf '\n-- Capacidade anunciada pelo netdev --\n'
if [ "$modo" = "driver" ]; then
    echo "  consulta por DRIVER: nao ha netdev para interrogar."
    echo "  So a inspecao do modulo abaixo se aplica neste modo."
else
    consultar_netdev "$iface"
fi

printf '\n-- Heuristica do modulo (evidencia secundaria) --\n'
if inspecionar_modulo "$driver"; then
    printf '  modulo ....... %s\n' "$_MOD_CAMINHO"
    printf '  simbolos xdp_ (XDP nativo) %s\n' "$_MOD_XDP"
    printf '  chamadas ao nucleo XSK ... %s\n' "$_MOD_CHAMADAS"
    printf '  codigo XSK do driver ..... %s\n' "$_MOD_PROPRIOS"
    printf '  diagnostico do modulo .... %s\n' \
        "$(diagnostico_modulo "$_MOD_XDP" "$_MOD_CHAMADAS" "$_MOD_PROPRIOS")"
    printf '  interpretacao: %s\n' "$(interpretar_heuristica "$_MOD_CHAMADAS")"
else
    printf '  %s\n' "$_MOD_ERRO"
fi

printf '\n-- Veredito --\n'
if [ "$modo" = "driver" ]; then
    echo "  Este modo inspeciona um MODULO, nao uma interface. O diagnostico do"
    echo "  modulo acima e evidencia indireta, e nao substitui o que o netdev da"
    echo "  placa anuncia. Rode com o nome da interface para ter veredito."
else
    texto_veredito "$_CAP_CLASSE" "$_CAP_MOTIVO"
fi

if [ "$modo" = "driver" ]; then
    cat <<EOF

-- Prova funcional --
  Nao se aplica: este modo inspeciona o modulo de um driver que pode nem estar
  presente nesta maquina. A prova exige a placa e uma interface ativa; rode
  entao "$0 <interface>" na maquina que a tiver.
EOF
else
    cat <<EOF

-- Prova funcional (executar separadamente) --
  Use uma ferramenta que force XDP_ZEROCOPY; nao aceite fallback silencioso.
  Com o exemplo xdpsock, a forma tipica para RX/queue 0 e:

    sudo xdpsock -i $iface -q 0 -N -z -r

  -N forca XDP nativo; -z forca zero-copy. Se o driver nao suportar o caminho,
  o bind deve falhar. Rodar sem -z nao prova zero-copy, pois ha fallback
  automatico para copy mode.

  Esta e a UNICA etapa que exige privilegio de verdade, e nao ha versao
  parcial dela: medido, socket(AF_XDP) sem CAP_NET_RAW falha com EPERM antes
  de qualquer bind. Tudo acima roda sem root; isto aqui, nao.
EOF
fi
